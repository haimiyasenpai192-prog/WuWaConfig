package com.wuwaconfig.app;
interface IUserService {
    void destroy() = 16777114;
    int exec(String command) = 1;
}
