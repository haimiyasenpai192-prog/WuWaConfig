package com.wuwaconfig.app

import kotlin.system.exitProcess

/** Berjalan di proses Shizuku (uid shell). */
class UserService : IUserService.Stub() {
    override fun destroy() { exitProcess(0) }
    override fun exec(command: String): Int = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
        p.inputStream.readBytes(); p.errorStream.readBytes()
        p.waitFor()
    } catch (e: Throwable) { -1 }
}
