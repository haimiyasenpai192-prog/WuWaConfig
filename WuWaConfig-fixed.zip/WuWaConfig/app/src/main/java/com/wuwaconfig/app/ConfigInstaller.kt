package com.wuwaconfig.app

import android.content.Context
import android.util.Base64

enum class Preset(val key: String) { FLAGSHIP("flagship"), BALANCED("balanced") }
enum class Quality(val key: String) { HIGH("high"), MEDIUM("medium") }

/**
 * Semua operasi di folder config WuWa Global lewat Shizuku:
 * install preset (menimpa file yang ada), install manual (file pilihan sendiri),
 * dan hapus config (Engine.ini + DeviceProfiles.ini).
 */
object ConfigInstaller {
    private const val PKG = "com.kurogame.wutheringwaves.global"
    private const val BASE = "/storage/emulated/0/Android/data/$PKG"
    private const val CONFIG_DIR = "$BASE/files/UE4Game/Client/Client/Saved/Config/Android"
    val FILES = listOf("Engine.ini", "DeviceProfiles.ini")

    fun assetDir(p: Preset, q: Quality) = "configs/${p.key}_${q.key}"

    fun isAvailable(ctx: Context, p: Preset, q: Quality): Boolean =
        ctx.assets.list("configs")?.contains("${p.key}_${q.key}") == true

    /** Tulis file dalam potongan kecil supaya aman untuk file besar. */
    private fun writeFile(svc: IUserService, name: String, bytes: ByteArray): Boolean {
        val target = "$CONFIG_DIR/$name"
        if (svc.exec(": > '$target'") != 0) return false
        val chunk = 48_000 // kelipatan 3 -> base64 per potongan tetap valid
        var i = 0
        while (i < bytes.size) {
            val end = minOf(i + chunk, bytes.size)
            val b64 = Base64.encodeToString(bytes, i, end - i, Base64.NO_WRAP)
            if (svc.exec("echo '$b64' | base64 -d >> '$target'") != 0) return false
            i = end
        }
        return svc.exec("[ \"$(wc -c < '$target')\" -eq ${bytes.size} ]") == 0
    }

    /** Install preset: file asli HARUS sudah ada, lalu ditimpa. */
    fun install(ctx: Context, svc: IUserService, p: Preset, q: Quality): Result<Unit> {
        if (svc.exec("[ -d '$BASE' ]") != 0)
            return fail("WuWa Global tidak ditemukan. Pasang gamenya dulu.")
        for (f in FILES) if (svc.exec("[ -f '$CONFIG_DIR/$f' ]") != 0)
            return fail("$f asli tidak ditemukan. Buka game sekali dulu, lalu coba lagi.")
        for (f in FILES) {
            val bytes = ctx.assets.open("${assetDir(p, q)}/$f").use { it.readBytes() }
            if (!writeFile(svc, f, bytes)) return fail("Gagal menulis $f.")
        }
        return Result.success(Unit)
    }

    /** Install manual: file pilihan sendiri; dibuat kalau belum ada (folder config dibuat bila perlu). */
    fun installManual(svc: IUserService, files: Map<String, ByteArray>): Result<Unit> {
        if (files.isEmpty()) return fail("Pilih file Engine.ini dan/atau DeviceProfiles.ini.")
        if (svc.exec("[ -d '$BASE' ]") != 0)
            return fail("WuWa Global tidak ditemukan. Pasang gamenya dulu.")
        svc.exec("mkdir -p '$CONFIG_DIR'")
        for ((name, bytes) in files) if (!writeFile(svc, name, bytes)) return fail("Gagal menulis $name.")
        return Result.success(Unit)
    }

    /** Hapus Engine.ini dan DeviceProfiles.ini. */
    fun deleteConfig(svc: IUserService): Result<Unit> {
        if (svc.exec("[ -d '$BASE' ]") != 0)
            return fail("WuWa Global tidak ditemukan. Pasang gamenya dulu.")
        for (f in FILES) svc.exec("rm -f '$CONFIG_DIR/$f'")
        for (f in FILES) if (svc.exec("[ ! -e '$CONFIG_DIR/$f' ]") != 0)
            return fail("Gagal menghapus $f.")
        return Result.success(Unit)
    }

    private fun fail(msg: String) = Result.failure<Unit>(IllegalStateException(msg))
}
