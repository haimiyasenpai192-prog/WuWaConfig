package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File

/** Menyimpan wallpaper latar aplikasi. Gambar disalin ke penyimpanan internal, jadi tidak
 *  bergantung pada izin galeri dan tetap ada walau file aslinya dihapus. */
object WallpaperStore {
    private const val MAX_SIDE = 1600   // sisi terpanjang setelah diperkecil, hemat RAM
    private const val PREFS = "pulse"
    private const val KEY_DIM = "dim"

    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")

    fun save(c: Context, uri: Uri): Boolean = runCatching {
        // ImageDecoder otomatis memutar gambar sesuai EXIF dan mendukung downsample
        val src = ImageDecoder.createSource(c.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE   // bitmap hardware tidak bisa di-compress
            var sample = 1
            while (maxOf(info.size.width, info.size.height) / sample > MAX_SIDE) sample *= 2
            if (sample > 1) decoder.setTargetSampleSize(sample)
        }
        val tmp = File(c.filesDir, "wallpaper.tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        check(tmp.renameTo(file(c)) || (file(c).delete() && tmp.renameTo(file(c))))
    }.isSuccess

    fun load(c: Context): Bitmap? = file(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun clear(c: Context) { file(c).delete() }

    fun dim(c: Context): Float = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_DIM, 0.6f)

    fun saveDim(c: Context, v: Float) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_DIM, v).apply()
    }
}
