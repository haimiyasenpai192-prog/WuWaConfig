# PulseMonitor (FPS / CPU / GPU / Suhu)
1. Buka folder ini di Android Studio (Koala+), tunggu Gradle sync, lalu Run di HP Android 10+.
2. Pilih akses: aktifkan Shizuku (lalu tekan "Beri izin Shizuku") atau pakai HP root.
3. Nyalakan "Overlay mengambang" (akan diminta izin tampil di atas aplikasi lain).
Catatan: kode belum dikompilasi/diuji. GPU hanya terbaca di Adreno (kgsl). Tanpa izin INTERNET.

## Perubahan v0.1.1 (stabilisasi)
- Minta izin POST_NOTIFICATIONS saat start (Android 13+), supaya notifikasi overlay muncul.
- Overlay: cek izin tampil-di-atas-aplikasi, tangani addView/removeView gagal, tipe FGS specialUse hanya di API 34+.
- Sampler: hindari crash saat data frame kosong; kegagalan baca FPS tidak lagi menggagalkan CPU/GPU/RAM/suhu.
- Belum ada Gradle wrapper di zip ini: Android Studio akan menawarkan membuatnya saat sync (butuh Gradle 8.7+ untuk AGP 8.5.2).

## v0.2.2: Ikon aplikasi
- Ikon adaptive: latar gelap + garis denyut cyan, plus versi monokrom untuk ikon bertema (Android 13+). Semua berupa vektor XML di res/, tanpa PNG.

## v0.2.1: GPU MediaTek
- Sampler mencoba beberapa jalur GPU berurutan: Adreno (kgsl), MediaTek (GED), Mali lama. Jalur pertama yang terbaca dipakai; jika tidak ada, tampil "-".
- Belum diuji di perangkat MediaTek. Jalur GED bisa berbeda/tertutup di beberapa chipset.

## v0.2.0: Wallpaper
- Kartu "Wallpaper" di layar utama: pilih gambar dari galeri (Photo Picker, tanpa izin storage), ganti, hapus.
- Gambar disalin ke penyimpanan internal aplikasi (maks 1600 px, JPEG) lewat WallpaperStore.kt.
- Slider "Redupkan latar" (20-90%) agar teks tetap terbaca; nilainya tersimpan.
