# WuWa Config (Shizuku)

Proyek Android Studio (Kotlin + Jetpack Compose). Buka folder ini di Android Studio, Sync, lalu Run.

Syarat HP: Android 11+, Shizuku berjalan atau HP di-root, Wuthering Waves terpasang.

Yang perlu kamu isi/ubah:
- `DISCORD_URL` di MainActivity.kt (sudah diisi: https://discord.gg/EFaCxujTcC)
- Isi preset di Presets.kt (contoh konservatif, silakan ganti dengan config andalanmu)
- Untuk wallpaper bawaan: pilih "Ganti" di tab Tampilan

Preset: Flagship High/Medium dan Balanced High/Medium ada di `app/src/main/assets/`.
Tombol Install menimpa Engine.ini + DeviceProfiles.ini di `Android/data/<paket game>/files/UE4Game/Client/Client/Saved/Config/Android` lewat Shizuku.

Notifikasi: setelah config berhasil dipasang, muncul notifikasi dan suara dari `res/raw/notif_install.ogg` (diputar penuh lewat `Notifier.kt`).
Wallpaper bawaan (opsional): taruh gambar di `app/src/main/assets/wallpaper_default.jpg`.

Akses: di Settings, ketuk baris Shizuku/Root untuk memilih metode (Shizuku atau Root). Root memakai `su -c` (Magisk, KernelSU, APatch).

Animasi: pindah tab (ketuk navigasi atau geser layar kiri/kanan) memakai transisi geser + fade; ikon navigasi memantul saat dipilih.
