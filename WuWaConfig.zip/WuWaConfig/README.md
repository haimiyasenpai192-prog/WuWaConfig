# WuWa Config

Aplikasi Android 12+ (Kotlin + Jetpack Compose) untuk memasang config WuWa Global langsung ke folder game.

## Cara kerja
- Beri akses ke folder Android/data/com.kurogame.wutheringwaves.global SEKALI (Settings > Beri akses, lalu "Gunakan folder ini"); izin tersimpan permanen. Cara ini jalan di Android 12/12L; Android 13+ memblokir pemilihan folder Android/data lewat aplikasi biasa.
- Install MENIMPA Engine.ini dan DeviceProfiles.ini di
  /storage/emulated/0/Android/data/com.kurogame.wutheringwaves.global/files/UE4Game/Client/Client/Saved/Config/Android/
  Kalau file belum ada (game belum pernah dibuka), pemasangan gagal.
- "Hapus config" (Beranda) langsung menghapus kedua file itu (ada notifikasi + suara); game membuatnya ulang saat dibuka.
- "Install manual" (Beranda): pilih Engine.ini dan/atau DeviceProfiles.ini dari folder Download, lalu langsung terpasang ke folder config (dibuat kalau belum ada).
- Notifikasi berhasil memakai suara res/raw/notif_success.ogg.
- Tab Tampilan: warna aksen, wallpaper (foto/preset), redup, blur.

## Menambah preset
Folder app/src/main/assets/configs/<preset>_<kualitas>/ berisi Engine.ini dan DeviceProfiles.ini.
Preset: flagship, balanced. Kualitas: high, medium. Tersedia sekarang: flagship_high, balanced_high.

## Build lewat GitHub
Upload isi folder ini (termasuk .github), build jalan di tab Actions, unduh artifact WuWaConfig-release.

## Ukuran kecil
Build release memakai R8 (kode & resource dibuang), ikon milik sendiri (Ic.kt), dan hanya bahasa en/id. APK ditandatangani dengan app/wuwa-release.jks (kunci tetap, repo publik).
