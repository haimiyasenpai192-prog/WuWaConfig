# Wave Config (Shizuku)

Proyek Android Studio (Kotlin + Jetpack Compose). Buka folder ini di Android Studio, Sync, lalu Run.

Syarat HP: Android 11+, Shizuku berjalan atau HP di-root, Wuthering Waves terpasang.

Yang perlu kamu isi/ubah:
- `DISCORD_URL` di MainActivity.kt (sudah diisi: https://discord.gg/EFaCxujTcC)
- Isi preset di Presets.kt (contoh konservatif, silakan ganti dengan config andalanmu)
- Untuk wallpaper bawaan: pilih "Ganti" di tab Tampilan

Config bawaan: `app/src/main/assets/presets/c1.bin` (zip config v1.2 yang dienkripsi AES, didekripsi di memori lewat `Vault.kt`; daftar nama di `Presets.ENCRYPTED`) (Ultra, High, Medium; tiap tingkat berisi Engine.ini, file ketiga, dan DeviceProfiles.ini kecuali Ultra) ikut terbawa di APK. File ketiga dari preset dipasang ke folder Engine game dan ditulis terakhir; namanya tidak ditampilkan di daftar hasil dan log. Selain itu, config lain bisa diimpor dari HP.

Preset:  Di Beranda ketuk kartu **Config**, pilih **Impor zip** untuk menambah config dari HP (config hasil impor bisa dihapus lewat ikon sampah). Setelah itu pilih versi, lalu pilih Flagship/Balanced, pilih tingkat kualitasnya, lalu Install.
Satu zip = satu versi config (nama file = nama versi, contoh `v1.0.zip`; kalau mau membawa config bawaan lagi, taruh zip di `app/src/main/assets/presets/`). Dua gaya susunan folder yang dikenali:
- Bernomor: `[ 1 ] Flagship/`, `[ 2 ] Mid~range/`, `Balanced/[ 1 ] High/`, `Balanced/[ 2 ] Medium/` (nomor = urutan, teks = label tombol kualitas)
- Biasa: `flagship/`, `mid-range/`, `balanced/high/`, `balanced/medium/` (urutan otomatis)
Tiap folder berisi file config: `Engine.ini`, `DeviceProfiles.ini`, `Scalability.ini`, dan/atau `GameUserSettings.ini` (semua yang ada ikut terpasang). Zip dengan susunan bebas (file .ini langsung di folder biasa atau di root) juga diterima. Versi yang isinya hanya folder tingkat (mis. `ultra/`, `high/`) tanpa folder flagship/balanced tidak menampilkan pilihan Flagship/Balanced di Beranda; tingkat kualitasnya langsung muncul. Tombol Hapus config (di Beranda, di samping Bersihkan) menghapus Engine, DeviceProfiles, dan Scalability; GameUserSettings tidak ikut dihapus. Mode Balanced dikenali dari folder yang namanya mengandung "balanc", mode Flagship dari folder "flagship" atau "mid...". Format lama (`flagship_high`, dst.) juga masih terbaca.
Tanpa rebuild, zip juga bisa ditambah dari HP lewat dialog Config -> "Impor zip".
Tombol Install menimpa Engine.ini + DeviceProfiles.ini di `Android/data/<paket game>/files/UE4Game/Client/Client/Saved/Config/Android` lewat Shizuku.

Notifikasi: setelah config berhasil dipasang, muncul notifikasi dan suara dari `res/raw/notif_install.ogg` (diputar penuh lewat `Notifier.kt`).
Wallpaper bawaan (opsional): taruh gambar di `app/src/main/assets/wallpaper_default.jpg`.

Akses: di Settings, ketuk baris Shizuku/Root untuk memilih metode (Shizuku atau Root). Root memakai `su -c` (Magisk, KernelSU, APatch).

Kartu dan tombol memakai warna setengah transparan (CARD dan CHIP di MainActivity.kt, alpha 0.5) supaya wallpaper terlihat; ubah alpha di sana kalau mau lebih pekat atau lebih bening.

Animasi: pindah tab (ketuk navigasi atau geser layar kiri/kanan) memakai transisi geser + fade; ikon navigasi memantul saat dipilih.

Ukuran APK: untuk APK kecil, build varian release (Build > Generate Signed Bundle / APK, atau `./gradlew assembleRelease`; hasil: `app/build/outputs/apk/release/app-release.apk`). Release memakai R8 (minify + shrink resources) dan memakai keystore yang sama dengan debug, jadi bisa dipasang menimpa. APK debug dari tombol Run memang besar karena tidak diperkecil. Aturan R8 ada di `app/proguard-rules.pro` (menjaga Shizuku yang dipanggil lewat reflection).

Build di GitHub: file `.github/workflows/build-apk.yml` membuat APK release otomatis setiap push ke `main` (atau jalankan manual lewat tab Actions, Run workflow). Hasilnya ada di bagian Artifacts pada run tersebut (`WaveConfig-apk`). Kalau repo sudah punya workflow lama bernama "Build APK", hapus yang lama supaya tidak dobel.

Config bawaan APK: v1.2 release. Config lain bisa diimpor dari HP lewat kartu Config di Beranda.

Log: kalau pasang config gagal, ketuk ikon dokumen kuning di kartu status Beranda, atau buka Settings > Log. Isinya riwayat aksi (pasang, hapus, impor, akses), pesan error asli dari shell, dan diagnosa otomatis (id proses, SELinux, izin folder game & Config, ruang kosong) plus petunjuk penyebab paling mungkin. Tombol Salin / Bagikan menyertakan info perangkat. Log disimpan di `filesDir/wave_log.txt` (maks sekitar 200 KB, otomatis dipangkas) lewat `AppLog.kt`.

Wireless ADB (pairing port + kode 6 digit): di Settings ketuk baris akses, pilih **Wireless ADB**. Ikuti 3 langkah di kartu (Developer options -> Wireless debugging -> Pair device with pairing code, isi port dan kode). Tombol **Via notifikasi** menampilkan notifikasi dengan kolom balasan supaya kode bisa diketik dari bayangan notifikasi. Setelah pairing, koneksi dibuat otomatis tiap aplikasi dibuka (Wireless Debugging harus menyala dan HP terhubung Wi-Fi). Memakai libadb-android lewat JitPack (sudah ditambahkan di settings.gradle.kts). Kode di `AdbPair.kt`, `PairUi.kt`, `PairReplyReceiver.kt`.


DEX2OAT: di Beranda ada tombol **DEX2OAT** di samping Cek status. Ketuk, pilih mode (speed-profile disarankan, atau speed) atau Reset. Game dikompilasi ulang lewat `cmd package compile` memakai Shizuku/Root/Wireless ADB, dengan langkah sesuai versi Android (14+: bersihkan profil lama, compile penuh, dexopt latar; 12-13: compile + secondary dex; 11: compile biasa). Dialog menampilkan status kompilasi game saat ini, dan hasilnya (mode, status, waktu) tampil di kotak hasil Beranda di bawah tombol. Prosesnya bisa beberapa menit; langkah dan error tercatat di Log (tag DEX2OAT). Kode di `ShizukuShell.dexopt()`.

Bersihkan: tombol **Bersihkan** di Beranda (di bawah Cek status / DEX2OAT) berisi dua aksi: Hapus shader (cache pipeline/PSO) dan Hapus laporan crash. Pencarian dibatasi di folder data game, tidak menyentuh folder Config, dan hasilnya (jumlah file, ukuran) tampil di kotak hasil Beranda serta tercatat di Log (tag Bersih). Kode di `ShizukuShell.sweep()`.
