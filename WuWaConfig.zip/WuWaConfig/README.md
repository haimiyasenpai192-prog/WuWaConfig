# Wavetune (Shizuku)

Proyek Android Studio (Kotlin + Jetpack Compose). Buka folder ini di Android Studio, Sync, lalu Run.

Syarat HP: Android 11+, Shizuku berjalan atau HP di-root, Wuthering Waves terpasang.

Yang perlu kamu isi/ubah:
- `DISCORD_URL` di MainActivity.kt (sudah diisi: https://discord.gg/EFaCxujTcC)
- Isi preset di Presets.kt (contoh konservatif, silakan ganti dengan config andalanmu)
- Untuk wallpaper bawaan: pilih "Ganti" di tab Tampilan

Preset: aplikasi tidak lagi membawa config bawaan. Di Beranda ketuk kartu **Config**, pilih **Impor zip** untuk menambah config dari HP (config hasil impor bisa dihapus lewat ikon sampah). Setelah itu pilih versi, lalu pilih Flagship/Balanced, pilih tingkat kualitasnya, lalu Install.
Satu zip = satu versi config (nama file = nama versi, contoh `v1.0.zip`; kalau mau membawa config bawaan lagi, taruh zip di `app/src/main/assets/presets/`). Dua gaya susunan folder yang dikenali:
- Bernomor: `[ 1 ] Flagship/`, `[ 2 ] Mid~range/`, `Balanced/[ 1 ] High/`, `Balanced/[ 2 ] Medium/` (nomor = urutan, teks = label tombol kualitas)
- Biasa: `flagship/`, `mid-range/`, `balanced/high/`, `balanced/medium/` (urutan otomatis)
Tiap folder berisi file config: `Engine.ini`, `DeviceProfiles.ini`, `Scalability.ini`, dan/atau `GameUserSettings.ini` (semua yang ada ikut terpasang). Zip dengan susunan bebas (file .ini langsung di folder biasa atau di root) juga diterima. Versi yang isinya hanya folder tingkat (mis. `ultra/`, `high/`) tanpa folder flagship/balanced tidak menampilkan pilihan Flagship/Balanced di Beranda; tingkat kualitasnya langsung muncul. Tombol Hapus config menghapus Engine, DeviceProfiles, dan Scalability; GameUserSettings tidak ikut dihapus. Mode Balanced dikenali dari folder yang namanya mengandung "balanc", mode Flagship dari folder "flagship" atau "mid...". Format lama (`flagship_high`, dst.) juga masih terbaca.
Tanpa rebuild, zip juga bisa ditambah dari HP lewat dialog Config -> "Impor zip".
Tombol Install menimpa Engine.ini + DeviceProfiles.ini di `Android/data/<paket game>/files/UE4Game/Client/Client/Saved/Config/Android` lewat Shizuku.

Notifikasi: setelah config berhasil dipasang, muncul notifikasi dan suara dari `res/raw/notif_install.ogg` (diputar penuh lewat `Notifier.kt`).
Wallpaper bawaan (opsional): taruh gambar di `app/src/main/assets/wallpaper_default.jpg`.

Akses: di Settings, ketuk baris Shizuku/Root untuk memilih metode (Shizuku atau Root). Root memakai `su -c` (Magisk, KernelSU, APatch).

Animasi: pindah tab (ketuk navigasi atau geser layar kiri/kanan) memakai transisi geser + fade; ikon navigasi memantul saat dipilih.

Ukuran APK: untuk APK kecil, build varian release (Build > Generate Signed Bundle / APK, atau `./gradlew assembleRelease`; hasil: `app/build/outputs/apk/release/app-release.apk`). Release memakai R8 (minify + shrink resources) dan memakai keystore yang sama dengan debug, jadi bisa dipasang menimpa. APK debug dari tombol Run memang besar karena tidak diperkecil. Aturan R8 ada di `app/proguard-rules.pro` (menjaga Shizuku yang dipanggil lewat reflection).

Build di GitHub: file `.github/workflows/build-apk.yml` membuat APK release otomatis setiap push ke `main` (atau jalankan manual lewat tab Actions, Run workflow). Hasilnya ada di bagian Artifacts pada run tersebut (`Wavetune-apk`). Kalau repo sudah punya workflow lama bernama "Build APK", hapus yang lama supaya tidak dobel.
