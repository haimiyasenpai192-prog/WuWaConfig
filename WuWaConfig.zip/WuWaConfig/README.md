# WuWa Config

Aplikasi Android 12 ke atas (Kotlin + Jetpack Compose) untuk memasang config WuWa Global lewat Shizuku.

## Build lewat GitHub
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder .github).
2. Buka tab Actions, workflow "Build APK" jalan otomatis tiap push (atau klik Run workflow).
3. Setelah hijau, buka run-nya, unduh artifact "WuWaConfig-debug" (isinya APK), ekstrak, lalu pasang.

## Cara build lokal
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Run di HP, atau Build > Build APK.

## Cara kerja
- Aplikasi hanya aktif kalau Shizuku jalan dan izin diberikan. Kalau tidak, semua kontrol dan tombol Install nonaktif.
- Install MENIMPA Engine.ini dan DeviceProfiles.ini di:
  /storage/emulated/0/Android/data/com.kurogame.wutheringwaves.global/files/UE4Game/Client/Client/Saved/Config/Android/
  Kalau file asli belum ada (game belum pernah dibuka), pemasangan gagal.
- Backup file asli ke /storage/emulated/0/WuWaConfig/backup/ (sekali saja, supaya yang tersimpan tetap file asli).
- Notifikasi berhasil memakai suara app/src/main/res/raw/notif_success.ogg.

## Menambah preset
Taruh folder di app/src/main/assets/configs/<preset>_<kualitas>/ berisi Engine.ini dan DeviceProfiles.ini.
Preset: flagship, balanced. Kualitas: tinggi, sedang.
Yang tersedia sekarang: flagship_tinggi, balanced_tinggi. Pilihan "Sedang" aktif otomatis kalau foldernya ditambahkan.
