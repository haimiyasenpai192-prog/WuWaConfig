# WuWa Config (Shizuku)

Proyek Android Studio (Kotlin + Jetpack Compose). Buka folder ini di Android Studio, Sync, lalu Run.

Syarat HP: Android 11+, Shizuku berjalan, Wuthering Waves terpasang.

Yang perlu kamu isi/ubah:
- `DISCORD_URL` di MainActivity.kt
- Isi preset di Presets.kt (contoh konservatif, silakan ganti dengan config andalanmu)
- Untuk wallpaper bawaan: pilih "Ganti" di tab Tampilan
