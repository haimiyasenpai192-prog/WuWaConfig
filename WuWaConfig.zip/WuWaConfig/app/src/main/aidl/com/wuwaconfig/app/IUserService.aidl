package com.wuwaconfig.app;
interface IUserService {
    void destroy() = 16777114;
    int exec(String command) = 1;
    String execOut(String command) = 2;
    // Menjalankan perintah, mengembalikan "<kode keluar>\n<keluaran gabungan stdout+stderr>"
    String run(String command) = 3;
    // Menulis byte langsung ke path (tanpa base64/echo). Mengembalikan "" jika sukses, selain itu pesan error.
    String writeFile(String path, in byte[] data) = 4;
}
