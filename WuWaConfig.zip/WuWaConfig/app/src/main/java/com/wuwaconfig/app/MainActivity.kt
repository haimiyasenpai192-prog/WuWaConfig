package com.wuwaconfig.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { WuWaApp(vm) }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh() // cek ulang izin folder game tiap kembali ke aplikasi
    }
}
