package com.wuwaconfig.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class ShizukuStatus { NOT_RUNNING, NO_PERMISSION, READY }

object ShizukuHelper {
    fun status(): ShizukuStatus = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> ShizukuStatus.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuStatus.READY
            else -> ShizukuStatus.NO_PERMISSION
        }
    } catch (e: Throwable) { ShizukuStatus.NOT_RUNNING }
}
