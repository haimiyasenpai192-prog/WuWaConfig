package com.wuwaconfig.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.provider.DocumentsContract
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF000000)
private val Card = Color(0xFF0F0F14)
private val CardLine = Color(0xFF24242B)
private val Muted = Color(0xFF9A9AA3)
private val Warn = Color(0xFFE8C27A)
private val Ok = Color(0xFF5ED39A)
private val Danger = Color(0xFFE5737F)
// Teks di atas wallpaper: warna lebih terang + bayangan gelap supaya tetap terbaca.
private val Soft = Color(0xFFDADAE2)
private val TextShadow = Shadow(Color.Black.copy(alpha = 0.9f), Offset(0f, 2f), 12f)
private val ShadowStyle = TextStyle(shadow = TextShadow)

private const val DISCORD = "https://discord.gg/EFaCxujTcC"

private val ACCENTS = listOf(
    Color(0xFF6B5CE0), Color(0xFF378ADD), Color(0xFF1D9E75),
    Color(0xFFD4537E), Color(0xFFD85A30), Color(0xFFBA7517)
)

private class Pal(
    val accent: Color, val soft: Color, val sel: Color, val navSel: Color,
    val card: Color, val inner: Color, val field: Color
)

private val LocalPal = compositionLocalOf {
    Pal(ACCENTS[0], Color(0xFF9C90F5), Color(0xFF14103A), Color(0xFF1C1850), Card, Color(0xFF17171D), Card)
}

@Composable
fun WuWaApp(vm: MainVm) {
    var tab by remember { mutableIntStateOf(0) }
    val accent = ACCENTS[vm.accentIdx.coerceIn(0, ACCENTS.lastIndex)]
    val hasWp = vm.wallpaper != "none" && !(vm.wallpaper == "photo" && vm.photo == null)
    // Semua tab memakai panel hitam pekat seperti Beranda.
    val translucent = false
    val pal = Pal(
        accent = accent,
        soft = lerp(accent, Color.White, 0.35f),
        sel = lerp(Color.Black, accent, 0.13f),
        navSel = lerp(Color.Black, accent, 0.22f),
        card = when {
            translucent -> Card.copy(alpha = 0.62f)
            hasWp -> Color.Black.copy(alpha = 0.92f)
            else -> Card
        },
        inner = if (translucent) Color.White.copy(alpha = 0.09f) else Color(0xFF17171D),
        field = if (translucent) Color.Black.copy(alpha = 0.35f) else Card
    )
    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = Bg, surface = Card, onSurface = Color.White)) {
            val snack = remember { SnackbarHostState() }
            LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
            Box(Modifier.fillMaxSize().background(Bg)) {
                when (vm.wallpaper) {
                    "photo" -> vm.photo?.let {
                        Image(it, null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().then(
                                if (vm.blur) Modifier.blur(24.dp, BlurredEdgeTreatment.Unbounded) else Modifier))
                    }
                    "violet" -> Box(Modifier.fillMaxSize().background(Color(0xFF1C1850)))
                    "blue" -> Box(Modifier.fillMaxSize().background(Color(0xFF0C2A3D)))
                }
                if (hasWp) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = vm.dim)))
                // Gradasi gelap di bagian atas supaya judul selalu jelas.
                if (hasWp) Box(Modifier.fillMaxWidth().height(260.dp).background(
                    Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent))))
                val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
                Scaffold(
                    containerColor = Color.Transparent,
                    snackbarHost = { SnackbarHost(snack) },
                    bottomBar = { if (!(tab == 1 && imeOpen)) NavBar(tab) { tab = it } }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        AnimatedContent(
                            targetState = tab,
                            transitionSpec = {
                                val dir = if (targetState > initialState) 1 else -1
                                (slideInHorizontally(tween(300)) { it * dir / 5 } + fadeIn(tween(300))) togetherWith
                                    (slideOutHorizontally(tween(220)) { -it * dir / 5 } + fadeOut(tween(160)))
                            },
                            label = "tab"
                        ) { t ->
                            when (t) {
                                0 -> HomeScreen(vm)
                                1 -> EditScreen(vm)
                                2 -> LookScreen(vm)
                                else -> SettingsScreen(vm)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Kerangka semua layar: judul di atas, wallpaper terlihat di tengah, panel konten menempel di bawah. */
@Composable
private fun SheetScreen(
    title: String, sub: String, showHeader: Boolean = true, ime: Boolean = false,
    trailing: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit
) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier.fillMaxSize().then(if (ime) Modifier.imePadding() else Modifier)
            .padding(start = 20.dp, end = 20.dp, top = if (showHeader) 20.dp else 32.dp)
    ) {
        if (showHeader) Header(title, sub, trailing)
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.fillMaxWidth()
                    .background(pal.card, shape)
                    .border(BorderStroke(0.5.dp, CardLine), shape)
                    .clip(shape)
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                content = content
            )
        }
    }
}

@Composable
private fun Header(title: String, sub: String, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Medium, color = Color.White, style = ShadowStyle)
            Text(sub, fontSize = 14.sp, color = Soft, style = ShadowStyle)
        }
        trailing()
    }
}

@Composable
private fun ShizukuChip(ready: Boolean) {
    val c = if (ready) Ok else Warn
    Row(
        Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
            .border(BorderStroke(0.5.dp, CardLine), CircleShape).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(c, CircleShape))
        Spacer(Modifier.width(7.dp))
        Text("Shizuku", color = c, fontSize = 13.sp)
    }
}

/** Pemilih file multi-pilih yang langsung membuka folder Download. */
private class OpenFromDownloads : ActivityResultContracts.OpenMultipleDocuments() {
    override fun createIntent(context: Context, input: Array<String>): Intent =
        super.createIntent(context, input).putExtra(
            DocumentsContract.EXTRA_INITIAL_URI,
            Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload"))
}

@Composable
private fun HomeScreen(vm: MainVm) {
    val pal = LocalPal.current
    val ready = vm.ready
    val pickFiles = rememberLauncherForActivityResult(OpenFromDownloads()) { uris ->
        if (uris.isNotEmpty()) vm.installManual(uris)
    }

    SheetScreen("WuWa Config", "Pilih, lalu install config", trailing = { ShizukuChip(ready) }) {
        Column(Modifier.alpha(if (ready) 1f else 0.5f)) {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PresetCard(Modifier.weight(1f).fillMaxHeight(), Icons.Outlined.DesktopWindows, "Flagship", "Visual stabil",
                    vm.preset == Preset.FLAGSHIP, ready) { vm.preset = Preset.FLAGSHIP }
                PresetCard(Modifier.weight(1f).fillMaxHeight(), Icons.Outlined.Balance, "Balanced", "Balanced stabil",
                    vm.preset == Preset.BALANCED, ready) { vm.preset = Preset.BALANCED }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Tune, null, tint = pal.soft)
                Spacer(Modifier.width(14.dp))
                Text("Kualitas", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Row(Modifier.background(pal.inner, RoundedCornerShape(12.dp)).padding(3.dp)) {
                    QualityChip("High", vm.quality == Quality.HIGH, ready) {
                        if (vm.isAvailable(vm.preset, Quality.HIGH)) vm.quality = Quality.HIGH
                        else vm.messages.tryEmit("Config High belum tersedia.")
                    }
                    QualityChip("Medium", vm.quality == Quality.MEDIUM, ready) {
                        if (vm.isAvailable(vm.preset, Quality.MEDIUM)) vm.quality = Quality.MEDIUM
                        else vm.messages.tryEmit("Config Medium belum tersedia.")
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionBtn(Modifier.weight(1f), Icons.Outlined.Folder, Warn, "Install manual", ready && !vm.busy) {
                    vm.messages.tryEmit("Tahan lama satu file, lalu pilih file kedua (Engine.ini + DeviceProfiles.ini).")
                    pickFiles.launch(arrayOf("*/*"))
                }
                ActionBtn(Modifier.weight(1f), Icons.Outlined.Delete, Danger, "Hapus config", ready && !vm.busy) { vm.deleteConfig() }
            }
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { vm.install() },
            enabled = ready && !vm.busy,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = pal.accent, contentColor = Color.White,
                disabledContainerColor = pal.accent.copy(alpha = 0.35f), disabledContentColor = Color.White.copy(alpha = 0.6f))
        ) {
            if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("Install", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
        if (!ready) {
            Spacer(Modifier.height(10.dp))
            Text("Hubungkan Shizuku dulu untuk mengaktifkan pemasangan.", color = Muted, fontSize = 13.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun ActionBtn(m: Modifier, icon: ImageVector, tint: Color, label: String, enabled: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        m.alpha(if (enabled) 1f else 0.5f).background(pal.inner, shape)
            .border(BorderStroke(0.5.dp, CardLine), shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 8.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable
private fun MiniBtn(label: String, enabled: Boolean, m: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        m.alpha(if (enabled) 1f else 0.5f).background(pal.inner, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 4.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center) }
}

@Composable
private fun EditScreen(vm: MainVm) {
    val pal = LocalPal.current
    val ready = vm.ready
    // Dialog "Buka dengan": pilih aplikasi manajer file apa saja (ZArchiver, MT Manager, Files, dll).
    val pickTxt = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        val uri = d?.data ?: d?.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        if (r.resultCode == Activity.RESULT_OK && uri != null) vm.loadTxt(uri)
    }
    val openWith = {
        val get = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_LOCAL_ONLY, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        pickTxt.launch(Intent.createChooser(get, "Buka dengan"))
    }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    SheetScreen("Edit", "Tulis atau tempel tweak config.", showHeader = !imeOpen, ime = true) {
        Row(Modifier.fillMaxWidth().background(pal.inner, RoundedCornerShape(14.dp)).padding(3.dp)) {
            ConfigInstaller.FILES.forEach { f ->
                QualityChip(f, vm.editFile == f, true, Modifier.weight(1f)) { vm.switchEditFile(f) }
            }
        }
        if (!imeOpen) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniBtn("Preset", !vm.busy, Modifier.weight(1f).fillMaxHeight()) { vm.loadPreset() }
                MiniBtn("Buka file", !vm.busy, Modifier.weight(1f).fillMaxHeight()) { openWith() }
                MiniBtn("Simpan", vm.editText.isNotBlank(), Modifier.weight(1f).fillMaxHeight()) { vm.saveToDownload(false) }
                MiniBtn("Simpan semua", true, Modifier.weight(1f).fillMaxHeight()) { vm.saveToDownload(true) }
            }
        }
        Spacer(Modifier.height(8.dp))
        TextField(
            value = vm.editText,
            onValueChange = { vm.updateEditText(it) },
            modifier = Modifier.fillMaxWidth().height(if (imeOpen) 200.dp else 150.dp)
                .clip(RoundedCornerShape(16.dp)),
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.White),
            placeholder = {
                Text("[/Script/Engine.RendererSettings]\nr.ScreenPercentage=100", color = Muted,
                    fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = pal.field, unfocusedContainerColor = pal.field,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent, cursorColor = pal.soft,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).background(pal.inner, CircleShape)
                    .clickable(enabled = vm.editText.isNotEmpty()) { vm.clearEdit() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Outlined.Delete, null, tint = Danger) }
            Button(
                onClick = { vm.installEdited() },
                enabled = ready && !vm.busy && vm.editText.isNotBlank(),
                modifier = Modifier.weight(1f).height(52.dp),
                shape = CircleShape,
                // Biru untuk tombol Pasang (berlaku untuk Engine.ini dan DeviceProfiles.ini).
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF378ADD), contentColor = Color.White,
                    disabledContainerColor = Color(0xFF378ADD).copy(alpha = 0.35f), disabledContentColor = Color.White.copy(alpha = 0.6f))
            ) {
                if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                else Text("Pasang ${vm.editFile}", fontSize = 17.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun PresetCard(m: Modifier, icon: ImageVector, title: String, sub: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(18.dp)
    Row(
        m.background(if (selected) pal.sel else pal.inner, shape)
            .border(BorderStroke(if (selected) 1.5.dp else 0.5.dp, if (selected) pal.accent else CardLine), shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) pal.soft else Color(0xFF5AA9E6), modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QualityChip(label: String, selected: Boolean, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.background(if (selected) pal.accent else Color.Transparent, RoundedCornerShape(11.dp))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (selected) Color.White else Muted, fontSize = 14.sp) }
}

@Composable
private fun SheetLabel(t: String) {
    Text(t, color = Soft, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 8.dp))
}

@Composable
private fun LookScreen(vm: MainVm) {
    val pal = LocalPal.current
    val hasWp = vm.wallpaper != "none" && !(vm.wallpaper == "photo" && vm.photo == null)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickPhoto(uri)
    }
    SheetScreen("Tampilan", "Atur warna dan wallpaper.") {
        SheetLabel("Warna aksen")
        Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            ACCENTS.forEachIndexed { i, c ->
                val sel = vm.accentIdx == i
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(c)
                        .then(if (sel) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                        .clickable { vm.setAccent(i) },
                    contentAlignment = Alignment.Center
                ) { if (sel) Icon(Icons.Outlined.Check, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }

        Spacer(Modifier.height(14.dp))
        SheetLabel("Wallpaper")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WallTile(Modifier.weight(1f), "Tanpa", vm.wallpaper == "none", Color.Black) { vm.applyWallpaper("none") }
            val photoSel = vm.wallpaper == "photo" && vm.photo != null
            WallTile(
                Modifier.weight(1f), if (photoSel) "Ganti" else "Foto",
                photoSel, Color(0xFF17171D), photo = vm.photo,
                icon = if (vm.photo == null) Icons.Outlined.AddPhotoAlternate else null
            ) {
                if (vm.photo != null && vm.wallpaper != "photo") vm.applyWallpaper("photo")
                else picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            WallTile(Modifier.weight(1f), "Ungu", vm.wallpaper == "violet", Color(0xFF1C1850)) { vm.applyWallpaper("violet") }
            WallTile(Modifier.weight(1f), "Biru", vm.wallpaper == "blue", Color(0xFF0C2A3D)) { vm.applyWallpaper("blue") }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp).alpha(if (hasWp) 1f else 0.5f), verticalAlignment = Alignment.CenterVertically) {
            Text("Redup", color = Color.White, fontSize = 15.sp)
            Slider(
                value = vm.dim, onValueChange = vm::applyDim, onValueChangeFinished = vm::saveDim,
                valueRange = 0f..0.9f, enabled = hasWp, modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = pal.accent, inactiveTrackColor = CardLine)
            )
            Text("${(vm.dim * 100).toInt()}%", color = Muted, fontSize = 14.sp)
        }
        val canBlur = vm.wallpaper == "photo" && vm.photo != null
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp).alpha(if (canBlur) 1f else 0.5f), verticalAlignment = Alignment.CenterVertically) {
            Text("Blur wallpaper", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Switch(vm.blur, { vm.applyBlur(it) }, enabled = canBlur,
                colors = SwitchDefaults.colors(checkedTrackColor = pal.accent, checkedThumbColor = Color.White))
        }
    }
}

@Composable
private fun WallTile(m: Modifier, label: String, selected: Boolean, bg: Color, photo: ImageBitmap? = null,
                     icon: ImageVector? = null, onClick: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(14.dp)
    Box(
        m.height(66.dp).clip(shape).background(bg)
            .border(BorderStroke(if (selected) 1.5.dp else 0.5.dp, if (selected) pal.accent else CardLine), shape)
            .clickable(onClick = onClick)
    ) {
        if (photo != null) Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (icon != null) Icon(icon, null, tint = pal.soft, modifier = Modifier.align(Alignment.Center).size(24.dp))
        Text(label, color = Color.White, fontSize = 12.sp, style = ShadowStyle,
            modifier = Modifier.align(Alignment.BottomStart).padding(horizontal = 9.dp, vertical = 7.dp))
    }
}

@Composable
private fun SettingsScreen(vm: MainVm) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }

    SheetScreen("Settings", "Atur akses dan aplikasi.") {
        val (stText, stColor, btn) = when (vm.status) {
            ShizukuStatus.READY -> Triple("Terhubung", Ok, null)
            ShizukuStatus.NO_PERMISSION -> Triple("Izin belum diberikan", Warn, "Beri izin")
            ShizukuStatus.NOT_RUNNING -> Triple("Belum terhubung", Warn, "Hubungkan")
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(pal.navSel, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Power, null, tint = pal.soft)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Shizuku", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Text(stText, color = stColor, fontSize = 14.sp)
            }
            if (btn != null) Button(onClick = { vm.connect() }, colors = ButtonDefaults.buttonColors(containerColor = pal.accent), shape = CircleShape) {
                Text(btn, fontSize = 15.sp)
            }
        }
        Divider0()
        Item(Icons.Outlined.SportsEsports, pal.soft, "Gabung Discord", null, external = true) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD)))
        }
        Divider0()
        Item(Icons.Outlined.Language, pal.soft, "Bahasa", "Indonesia") {}
        Divider0()
        Item(Icons.Outlined.Refresh, Color(0xFF5AA9E6), "Cek pembaruan", null) {
            vm.messages.tryEmit("Cek pembaruan belum tersedia.")
        }
        Divider0()
        Item(Icons.Outlined.Info, Ok, "Tentang aplikasi", "v1.0") { dialog = "about" }
    }

    when (dialog) {
        "about" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("WuWa Config v1.0") },
            text = { Text("Memasang config WuWa Global lewat Shizuku. Install menimpa Engine.ini dan DeviceProfiles.ini di folder game. Install manual memasang file pilihanmu dari folder Download. Hapus config menghapus keduanya.") },
            confirmButton = { TextButton({ dialog = null }) { Text("Tutup") } })
    }
}

@Composable private fun Divider0() =
    HorizontalDivider(Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = CardLine)

@Composable
private fun Item(icon: ImageVector, tint: Color, label: String, value: String?, external: Boolean = false,
                 enabled: Boolean = true, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clickable(enabled = enabled, onClick = onClick)
        .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        if (value != null) { Text(value, color = Muted, fontSize = 15.sp); Spacer(Modifier.width(6.dp)) }
        Icon(if (external) Icons.Outlined.OpenInNew else Icons.Outlined.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    val items = listOf(Triple("Beranda", Icons.Outlined.Home, 0), Triple("Edit", Icons.Outlined.Edit, 1), Triple("Tampilan", Icons.Outlined.Palette, 2), Triple("Settings", Icons.Outlined.Settings, 3))
    Row(Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth()
        .background(pal.card, RoundedCornerShape(26.dp)).border(BorderStroke(0.5.dp, CardLine), RoundedCornerShape(26.dp)).padding(6.dp)) {
        items.forEach { (label, icon, i) ->
            val sel = selected == i
            val navBlue = Color(0xFF378ADD)
            val bg by animateColorAsState(if (sel) lerp(Color.Black, navBlue, 0.22f) else Color.Transparent, tween(250), label = "bg")
            val fg by animateColorAsState(if (sel) lerp(navBlue, Color.White, 0.35f) else Muted, tween(250), label = "fg")
            Column(Modifier.weight(1f).background(bg, RoundedCornerShape(20.dp))
                .clickable { onSelect(i) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = fg)
                Text(label, color = fg, fontSize = 12.sp)
            }
        }
    }
}
