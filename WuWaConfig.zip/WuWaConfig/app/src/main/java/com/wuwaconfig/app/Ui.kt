package com.wuwaconfig.app

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF000000)
private val Card = Color(0xFF0F0F14)
private val CardLine = Color(0xFF24242B)
private val Accent = Color(0xFF6B5CE0)
private val AccentSoft = Color(0xFF9C90F5)
private val SelCard = Color(0xFF14103A)
private val Muted = Color(0xFF9A9AA3)
private val Warn = Color(0xFFE8C27A)
private val Ok = Color(0xFF5ED39A)
private const val DISCORD = "https://discord.gg/EFaCxujTcC"

@Composable
fun WuWaApp(vm: MainVm) {
    val scheme = darkColorScheme(primary = Accent, background = Bg, surface = Card, onSurface = Color.White)
    MaterialTheme(colorScheme = scheme) {
        var tab by remember { mutableIntStateOf(0) }
        val snack = remember { SnackbarHostState() }
        LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
        Scaffold(
            containerColor = Bg,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = { NavBar(tab) { tab = it } }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(vm)
                    1 -> LookScreen()
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
private fun Header(title: String, sub: String, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Medium, color = Color.White)
            Text(sub, fontSize = 14.sp, color = Muted)
        }
        trailing()
    }
}

@Composable
private fun ShizukuChip(ready: Boolean) {
    val c = if (ready) Ok else Warn
    Row(
        Modifier.border(BorderStroke(0.5.dp, CardLine), CircleShape).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(c, CircleShape))
        Spacer(Modifier.width(7.dp))
        Text("Shizuku", color = c, fontSize = 13.sp)
    }
}

@Composable
private fun HomeScreen(vm: MainVm) {
    val ready = vm.ready
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Header("WuWa Config", "Pilih, lalu pasang.") { ShizukuChip(ready) }
        Spacer(Modifier.height(20.dp))

        Column(Modifier.alpha(if (ready) 1f else 0.5f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PresetCard(Modifier.weight(1f), Icons.Outlined.DesktopWindows, "Flagship", "Config visual stabil",
                    vm.preset == Preset.FLAGSHIP, ready) { vm.preset = Preset.FLAGSHIP }
                PresetCard(Modifier.weight(1f), Icons.Outlined.Balance, "Balanced", "Config balanced stabil",
                    vm.preset == Preset.BALANCED, ready) { vm.preset = Preset.BALANCED }
            }
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp))
                .border(BorderStroke(0.5.dp, CardLine), RoundedCornerShape(20.dp))) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Tune, null, tint = AccentSoft)
                    Spacer(Modifier.width(14.dp))
                    Text("Kualitas", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Row(Modifier.background(Color(0xFF17171D), RoundedCornerShape(12.dp)).padding(3.dp)) {
                        QualityChip("Tinggi", vm.quality == Quality.TINGGI && vm.isAvailable(vm.preset, Quality.TINGGI), ready) {
                            vm.quality = Quality.TINGGI
                        }
                        QualityChip("Sedang", vm.quality == Quality.SEDANG, ready) {
                            if (vm.isAvailable(vm.preset, Quality.SEDANG)) vm.quality = Quality.SEDANG
                            else vm.messages.tryEmit("Config Sedang belum tersedia.")
                        }
                    }
                }
                HorizontalDivider(color = CardLine, thickness = 0.5.dp)
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Schedule, null, tint = Color(0xFF5AA9E6))
                    Spacer(Modifier.width(14.dp))
                    Text("Backup otomatis", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Switch(vm.autoBackup, { vm.autoBackup = it }, enabled = ready,
                        colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.White))
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { vm.install() },
            enabled = ready && !vm.busy,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White,
                disabledContainerColor = Accent.copy(alpha = 0.35f), disabledContentColor = Color.White.copy(alpha = 0.6f))
        ) {
            if (vm.busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("Install", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
        if (!ready) {
            Spacer(Modifier.height(12.dp))
            Text("Hubungkan Shizuku dulu untuk mengaktifkan pemasangan.", color = Muted, fontSize = 13.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun PresetCard(m: Modifier, icon: ImageVector, title: String, sub: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        m.height(130.dp)
            .background(if (selected) SelCard else Card, shape)
            .border(BorderStroke(if (selected) 1.5.dp else 0.5.dp, if (selected) Accent else CardLine), shape)
            .clickable(enabled = enabled, onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.size(40.dp).background(if (selected) Color(0xFF241F58) else Color(0xFF12232E), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (selected) AccentSoft else Color(0xFF5AA9E6))
        }
        Column {
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun QualityChip(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.background(if (selected) Accent else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(label, color = if (selected) Color.White else Muted, fontSize = 14.sp) }
}

@Composable
private fun LookScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Header("Tampilan", "Atur tema aplikasi.")
        Spacer(Modifier.height(24.dp))
        Text("Segera hadir.", color = Muted, fontSize = 15.sp)
    }
}

@Composable
private fun SettingsScreen(vm: MainVm) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Header("Settings", "Atur akses dan backup.")
        Spacer(Modifier.height(18.dp))

        val (stText, stColor, btn) = when (vm.status) {
            ShizukuStatus.READY -> Triple("Terhubung", Ok, null)
            ShizukuStatus.NO_PERMISSION -> Triple("Izin belum diberikan", Warn, "Beri izin")
            ShizukuStatus.NOT_RUNNING -> Triple("Belum terhubung", Warn, "Hubungkan")
        }
        Row(Modifier.fillMaxWidth().background(SelCard, RoundedCornerShape(22.dp))
            .border(BorderStroke(1.5.dp, Accent), RoundedCornerShape(22.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Color(0xFF1C1850), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Power, null, tint = AccentSoft)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Shizuku", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(stColor, CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text(stText, color = stColor, fontSize = 14.sp)
                }
            }
            if (btn != null) Button(onClick = { vm.connect() }, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = CircleShape) {
                Text(btn, fontSize = 15.sp)
            }
        }

        Section("Backup")
        Group {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Schedule, null, tint = Color(0xFF5AA9E6))
                Spacer(Modifier.width(14.dp))
                Text("Backup otomatis", color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                Switch(vm.autoBackup, { vm.autoBackup = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = Accent, checkedThumbColor = Color.White))
            }
            Divider0()
            Item(Icons.Outlined.Restore, Ok, "Pulihkan config asli", null, enabled = vm.ready && !vm.busy) { dialog = "restore" }
            Divider0()
            Item(Icons.Outlined.FolderOpen, Warn, "Lokasi backup", "Internal") { dialog = "location" }
        }

        Section("Komunitas")
        Group {
            Item(Icons.Outlined.SportsEsports, AccentSoft, "Gabung Discord", null, external = true) {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD)))
            }
        }

        Section("Umum")
        Group {
            Item(Icons.Outlined.Translate, AccentSoft, "Bahasa", "Indonesia") {}
            Divider0()
            Item(Icons.Outlined.Sync, Color(0xFF5AA9E6), "Cek pembaruan", null) {
                vm.messages.tryEmit("Cek pembaruan belum tersedia.")
            }
            Divider0()
            Item(Icons.Outlined.Info, Ok, "Tentang aplikasi", "v1.0") { dialog = "about" }
        }
        Spacer(Modifier.height(12.dp))
    }

    when (dialog) {
        "restore" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Pulihkan config asli?") },
            text = { Text("Engine.ini dan DeviceProfiles.ini akan dikembalikan dari backup.") },
            confirmButton = { TextButton({ dialog = null; vm.restore() }) { Text("Pulihkan") } },
            dismissButton = { TextButton({ dialog = null }) { Text("Batal") } })
        "location" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Lokasi backup") },
            text = { Text(ConfigInstaller.BACKUP_DIR) },
            confirmButton = { TextButton({ dialog = null }) { Text("Tutup") } })
        "about" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("WuWa Config v1.0") },
            text = { Text("Memasang config WuWa Global lewat Shizuku. Config menimpa file asli di folder game, dan file asli di-backup lebih dulu.") },
            confirmButton = { TextButton({ dialog = null }) { Text("Tutup") } })
    }
}

@Composable private fun Section(t: String) {
    Text(t, color = Muted, fontSize = 15.sp, modifier = Modifier.padding(start = 4.dp, top = 22.dp, bottom = 8.dp))
}

@Composable private fun Group(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp))
        .border(BorderStroke(0.5.dp, CardLine), RoundedCornerShape(20.dp)), content = content)
}

@Composable private fun Divider0() = HorizontalDivider(color = CardLine, thickness = 0.5.dp)

@Composable
private fun Item(icon: ImageVector, tint: Color, label: String, value: String?, external: Boolean = false,
                 enabled: Boolean = true, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.5f).clickable(enabled = enabled, onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint)
        Spacer(Modifier.width(14.dp))
        Text(label, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (value != null) { Text(value, color = Muted, fontSize = 15.sp); Spacer(Modifier.width(6.dp)) }
        Icon(if (external) Icons.Outlined.OpenInNew else Icons.Outlined.ChevronRight, null, tint = Muted)
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(Triple("Beranda", Icons.Outlined.Home, 0), Triple("Tampilan", Icons.Outlined.Palette, 1), Triple("Settings", Icons.Outlined.Settings, 2))
    Row(Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth()
        .background(Card, RoundedCornerShape(26.dp)).border(BorderStroke(0.5.dp, CardLine), RoundedCornerShape(26.dp)).padding(6.dp)) {
        items.forEach { (label, icon, i) ->
            val sel = selected == i
            Column(Modifier.weight(1f).background(if (sel) Color(0xFF1C1850) else Color.Transparent, RoundedCornerShape(20.dp))
                .clickable { onSelect(i) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = if (sel) AccentSoft else Muted)
                Text(label, color = if (sel) AccentSoft else Muted, fontSize = 12.sp)
            }
        }
    }
}
