package com.wuwaconfig.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** Ikon garis kecil milik sendiri (menggantikan library ikon Material yang besar). */
private fun line(name: String, vararg paths: String): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
        paths.forEach {
            addPath(
                addPathNodes(it), stroke = SolidColor(Color.Black), strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round
            )
        }
    }.build()

object Ic {
    val Desktop by lazy { line("desktop", "M5,4 H19 a2,2 0 0 1 2,2 V14 a2,2 0 0 1 -2,2 H5 a2,2 0 0 1 -2,-2 V6 a2,2 0 0 1 2,-2 z", "M8,20 H16 M12,16 V20") }
    val Scale by lazy { line("scale", "M7,20 H17 M6,6 l6,-1 l6,1 M12,3 V20 M9,12 l-3,-6 l-3,6 a3,3 0 0 0 6,0 M21,12 l-3,-6 l-3,6 a3,3 0 0 0 6,0") }
    val Tune by lazy { line("tune", "M16,6 a2,2 0 1 1 -4,0 a2,2 0 1 1 4,0 M4,6 H12 M16,6 H20", "M8,12 a2,2 0 1 1 -4,0 a2,2 0 1 1 4,0 M8,12 H20", "M19,18 a2,2 0 1 1 -4,0 a2,2 0 1 1 4,0 M4,18 H15 M19,18 H20") }
    val Trash by lazy { line("trash", "M4,7 H20 M10,11 V17 M14,11 V17", "M5,7 l1,12 a2,2 0 0 0 2,2 h8 a2,2 0 0 0 2,-2 l1,-12", "M9,7 V4 a1,1 0 0 1 1,-1 h4 a1,1 0 0 1 1,1 V7") }
    val Folder by lazy { line("folder", "M3,7 a2,2 0 0 1 2,-2 h4 l2,2 h8 a2,2 0 0 1 2,2 v8 a2,2 0 0 1 -2,2 H5 a2,2 0 0 1 -2,-2 z") }
    val Edit by lazy { line("edit", "M4,20 h4 l10.5,-10.5 a2.828,2.828 0 1 0 -4,-4 l-10.5,10.5 v4", "M13.5,6.5 l4,4") }
    val Chevron by lazy { line("chevron", "M9,6 l6,6 l-6,6") }
    val Home by lazy { line("home", "M5,12 H3 L12,3 L21,12 H19", "M5,12 V19 a2,2 0 0 0 2,2 h10 a2,2 0 0 0 2,-2 V12", "M9,21 V15 a2,2 0 0 1 2,-2 h2 a2,2 0 0 1 2,2 V21") }
    val Palette by lazy { line("palette", "M12,21 a9,9 0 0 1 0,-18 c4.97,0 9,3.582 9,8 c0,1.06 -0.474,2.078 -1.318,2.828 c-0.844,0.75 -1.989,1.172 -3.182,1.172 h-2.5 a2,2 0 0 0 -1,3.75 A1.3,1.3 0 0 1 12,21", "M8.5,10.5 h0.01 M12,7.5 h0.01 M15.5,10.5 h0.01") }
    val Plug by lazy { line("plug", "M9.785,6 l8.215,8.215 l-2.054,2.054 a5.81,5.81 0 1 1 -8.215,-8.215 l2.054,-2.054 z", "M4,20 l3.5,-3.5 M15,4 l-3.5,3.5 M20,9 l-3.5,3.5") }
    val Gamepad by lazy { line("gamepad", "M12,5 h3.5 a5,5 0 0 1 0,10 h-5.5 l-4.015,4.227 a2.3,2.3 0 0 1 -3.923,-2.035 l1.634,-8.173 a5,5 0 0 1 4.904,-4.019 h3.4 z", "M14,15 l4.07,4.284 a2.3,2.3 0 0 0 3.925,-2.023 l-1.6,-8.232", "M8,9 v2 M7,10 h2 M14,10 h2") }
    val Language by lazy { line("language", "M4,5 h7 M9,3 v2 c0,4.418 -2.239,8 -5,8", "M5,9 c0,2.144 2.952,3.908 6.7,4", "M12,20 l4,-9 l4,9 M19.1,18 h-6.2") }
    val External by lazy { line("external", "M12,6 h-6 a2,2 0 0 0 -2,2 v10 a2,2 0 0 0 2,2 h10 a2,2 0 0 0 2,-2 v-6", "M11,13 l9,-9 M15,4 h5 v5") }
    val PhotoPlus by lazy { line("photoplus", "M15,8 h0.01", "M12.5,21 h-6.5 a3,3 0 0 1 -3,-3 v-12 a3,3 0 0 1 3,-3 h12 a3,3 0 0 1 3,3 v6.5", "M3,16 l5,-5 c0.928,-0.893 2.072,-0.893 3,0 l4,4", "M16,19 h6 M19,16 v6") }
}
