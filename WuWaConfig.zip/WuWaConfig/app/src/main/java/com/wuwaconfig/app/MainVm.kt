package com.wuwaconfig.app

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.os.IBinder
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.io.File

class MainVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("prefs", 0)

    var status by mutableStateOf(ShizukuStatus.NOT_RUNNING); private set
    var preset by mutableStateOf(Preset.FLAGSHIP)
    var quality by mutableStateOf(Quality.HIGH)
    var busy by mutableStateOf(false); private set
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 4)

    // Pengaturan yang disimpan
    var accentIdx by mutableIntStateOf(prefs.getInt("accent", 0)); private set
    var wallpaper by mutableStateOf(prefs.getString("wp", "none") ?: "none"); private set
    var dim by mutableFloatStateOf(prefs.getFloat("dim", 0.4f)); private set
    var blur by mutableStateOf(prefs.getBoolean("blur", false)); private set
    var photo by mutableStateOf<ImageBitmap?>(null); private set

    fun setAccent(i: Int) { accentIdx = i; prefs.edit().putInt("accent", i).apply() }
    fun setWallpaper(w: String) { wallpaper = w; prefs.edit().putString("wp", w).apply() }
    fun setDim(v: Float) { dim = v }
    fun saveDim() { prefs.edit().putFloat("dim", dim).apply() }
    fun setBlur(v: Boolean) { blur = v; prefs.edit().putBoolean("blur", v).apply() }

    val ready get() = status == ShizukuStatus.READY
    private val ctx get() = getApplication<Application>()
    private var service: IUserService? = null
    private val photoFile get() = File(ctx.filesDir, "wallpaper.jpg")

    private val args = Shizuku.UserServiceArgs(
        ComponentName(app.packageName, UserService::class.java.name)
    ).daemon(false).processNameSuffix("svc").version(1)

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, b: IBinder?) {
            service = if (b != null && b.pingBinder()) IUserService.Stub.asInterface(b) else null
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null }
    }

    private val onBinder = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener { service = null; refresh() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    init {
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh()
        viewModelScope.launch(Dispatchers.IO) { loadPhoto() }
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    private fun loadPhoto() {
        val f = photoFile
        if (!f.exists()) return
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        photo = bmp?.asImageBitmap()
    }

    fun pickPhoto(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(uri)!!.use { i -> photoFile.outputStream().use { o -> i.copyTo(o) } }
                loadPhoto()
                setWallpaper("photo")
            }.onFailure { messages.tryEmit("Foto tidak bisa dibuka.") }
        }
    }

    fun refresh() {
        status = ShizukuHelper.status()
        if (status == ShizukuStatus.READY) {
            if (service == null) runCatching { Shizuku.bindUserService(args, conn) }
        } else service = null
    }

    fun connect() {
        refresh()
        when (status) {
            ShizukuStatus.READY -> Unit
            ShizukuStatus.NO_PERMISSION -> runCatching { Shizuku.requestPermission(100) }
            ShizukuStatus.NOT_RUNNING -> {
                val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                messages.tryEmit("Jalankan Shizuku dulu, lalu kembali ke sini.")
            }
        }
    }

    fun isAvailable(p: Preset, q: Quality) = ConfigInstaller.isAvailable(ctx, p, q)

    private suspend fun awaitService(): IUserService? {
        repeat(25) { service?.let { return it }; delay(120) }
        return service
    }

    fun install() {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val svc = awaitService()
            val r = if (svc == null) Result.failure(IllegalStateException("Shizuku tidak merespons."))
            else runCatching { ConfigInstaller.install(ctx, svc, preset, quality).getOrThrow() }
            val ok = r.isSuccess
            Notifier.show(ctx, ok, if (ok) "Pemasangan berhasil" else "Pemasangan gagal",
                r.exceptionOrNull()?.message ?: if (ok) "Config WuWa sudah terpasang." else "Config tidak bisa dipasang.")
            messages.tryEmit(if (ok) "Pemasangan berhasil" else "Pemasangan gagal")
            busy = false
        }
    }

    fun deleteConfig() {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val svc = awaitService()
            val r = if (svc == null) Result.failure(IllegalStateException("Shizuku tidak merespons."))
            else runCatching { ConfigInstaller.deleteConfig(svc).getOrThrow() }
            val ok = r.isSuccess
            Notifier.show(ctx, ok, if (ok) "Config dihapus" else "Gagal menghapus config",
                r.exceptionOrNull()?.message ?: if (ok) "Engine.ini dan DeviceProfiles.ini sudah dihapus." else "Config tidak bisa dihapus.")
            messages.tryEmit(if (ok) "Config dihapus" else "Gagal menghapus config")
            busy = false
        }
    }

    private fun displayName(uri: Uri): String? =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    /** Install manual: file dipilih dari folder Download (nama berisi "engine" / "deviceprofiles"). */
    fun installManual(uris: List<Uri>) {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val files = linkedMapOf<String, ByteArray>()
            for (u in uris) {
                val n = displayName(u)?.lowercase() ?: continue
                val target = when {
                    "deviceprofile" in n -> "DeviceProfiles.ini"
                    "engine" in n -> "Engine.ini"
                    else -> continue
                }
                runCatching { ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() } }
                    .onSuccess { files[target] = it }
            }
            val svc = awaitService()
            val r = if (svc == null) Result.failure(IllegalStateException("Shizuku tidak merespons."))
            else runCatching { ConfigInstaller.installManual(svc, files).getOrThrow() }
            val ok = r.isSuccess
            Notifier.show(ctx, ok, if (ok) "Pemasangan berhasil" else "Pemasangan gagal",
                r.exceptionOrNull()?.message ?: "Terpasang: ${files.keys.joinToString(", ")}")
            messages.tryEmit(if (ok) "Pemasangan berhasil" else "Pemasangan gagal")
            busy = false
        }
    }
}
