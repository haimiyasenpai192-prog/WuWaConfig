package com.wuwaconfig.app

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

class MainVm(app: Application) : AndroidViewModel(app) {
    var status by mutableStateOf(ShizukuStatus.NOT_RUNNING); private set
    var preset by mutableStateOf(Preset.FLAGSHIP)
    var quality by mutableStateOf(Quality.TINGGI)
    var autoBackup by mutableStateOf(true)
    var busy by mutableStateOf(false); private set
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 4)

    val ready get() = status == ShizukuStatus.READY
    private val ctx get() = getApplication<Application>()
    private var service: IUserService? = null

    private val args = Shizuku.UserServiceArgs(
        ComponentName(app.packageName, UserService::class.java.name)
    ).daemon(false).processNameSuffix("svc").version(1)

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, b: IBinder?) {
            service = if (b != null && b.pingBinder()) IUserService.Stub.asInterface(b) else null
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null }
    }

    private val onBinder = Shizuku.OnBinderReceivedListener { refresh() }
    private val onDead = Shizuku.OnBinderDeadListener { service = null; refresh() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    init {
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
        refresh()
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
    }

    fun refresh() {
        status = ShizukuHelper.status()
        if (status == ShizukuStatus.READY) {
            if (service == null) runCatching { Shizuku.bindUserService(args, conn) }
        } else service = null
    }

    fun connect() {
        refresh()
        when (status) {
            ShizukuStatus.READY -> Unit
            ShizukuStatus.NO_PERMISSION -> runCatching { Shizuku.requestPermission(100) }
            ShizukuStatus.NOT_RUNNING -> {
                val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                messages.tryEmit("Jalankan Shizuku dulu, lalu kembali ke sini.")
            }
        }
    }

    fun isAvailable(p: Preset, q: Quality) = ConfigInstaller.isAvailable(ctx, p, q)

    private suspend fun awaitService(): IUserService? {
        repeat(25) { service?.let { return it }; delay(120) }
        return service
    }

    fun install() {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val svc = awaitService()
            val r = if (svc == null) Result.failure(IllegalStateException("Shizuku tidak merespons."))
            else runCatching { ConfigInstaller.install(ctx, svc, preset, quality, autoBackup).getOrThrow() }
            Notifier.show(ctx, r.isSuccess, r.exceptionOrNull()?.message)
            messages.tryEmit(if (r.isSuccess) "Pemasangan berhasil" else "Pemasangan gagal")
            busy = false
        }
    }

    fun restore() {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val svc = awaitService()
            val r = if (svc == null) Result.failure(IllegalStateException("Shizuku tidak merespons."))
            else runCatching { ConfigInstaller.restore(svc).getOrThrow() }
            messages.tryEmit(if (r.isSuccess) "Config asli dipulihkan" else (r.exceptionOrNull()?.message ?: "Gagal memulihkan"))
            busy = false
        }
    }
}
