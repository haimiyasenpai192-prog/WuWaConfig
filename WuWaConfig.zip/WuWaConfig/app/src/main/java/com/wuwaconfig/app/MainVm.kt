package com.wuwaconfig.app

import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.os.Environment
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import java.io.File

enum class AccessStatus { NO_ACCESS, READY }

class MainVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("prefs", 0)

    var status by mutableStateOf(AccessStatus.NO_ACCESS); private set
    var preset by mutableStateOf(Preset.FLAGSHIP)
    var quality by mutableStateOf(Quality.HIGH)
    var busy by mutableStateOf(false); private set
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 4)

    // Pengaturan yang disimpan
    var accentIdx by mutableIntStateOf(prefs.getInt("accent", 0)); private set
    var wallpaper by mutableStateOf(prefs.getString("wp", "none") ?: "none"); private set
    var dim by mutableFloatStateOf(prefs.getFloat("dim", 0.4f)); private set
    var blur by mutableStateOf(prefs.getBoolean("blur", false)); private set
    var photo by mutableStateOf<ImageBitmap?>(null); private set

    // Editor tweak (draf disimpan per file)
    var editFile by mutableStateOf(ConfigInstaller.FILES[0]); private set
    var editText by mutableStateOf(prefs.getString("draft_" + ConfigInstaller.FILES[0], "") ?: ""); private set

    fun updateEditText(t: String) {
        editText = t
        prefs.edit().putString("draft_$editFile", t).apply()
    }
    fun switchEditFile(name: String) {
        if (name == editFile) return
        editFile = name
        editText = prefs.getString("draft_$name", "") ?: ""
    }
    fun clearEdit() { updateEditText("") }

    fun setAccent(i: Int) { accentIdx = i; prefs.edit().putInt("accent", i).apply() }
    fun applyWallpaper(w: String) { wallpaper = w; prefs.edit().putString("wp", w).apply() }
    fun applyDim(v: Float) { dim = v }
    fun saveDim() { prefs.edit().putFloat("dim", dim).apply() }
    fun applyBlur(v: Boolean) { blur = v; prefs.edit().putBoolean("blur", v).apply() }

    // Nama lama tetap ada (dengan nama JVM berbeda) supaya Ui.kt versi lama/baru sama-sama jalan.
    @JvmName("setWallpaperCompat") fun setWallpaper(w: String) = applyWallpaper(w)
    @JvmName("setDimCompat") fun setDim(v: Float) = applyDim(v)
    @JvmName("setBlurCompat") fun setBlur(v: Boolean) = applyBlur(v)

    val ready get() = status == AccessStatus.READY
    private val ctx get() = getApplication<Application>()
    private val photoFile get() = File(ctx.filesDir, "wallpaper.jpg")

    /** Izin folder game yang tersimpan (null = belum diberi). */
    private var tree: Uri? = prefs.getString("game_tree", null)?.let(Uri::parse)

    /** Diminta UI untuk membuka pemilih folder. */
    val grantRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    init {
        refresh()
        viewModelScope.launch(Dispatchers.IO) { loadPhoto() }
    }

    private fun loadPhoto() {
        val f = photoFile
        if (!f.exists()) return
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        photo = bmp?.asImageBitmap()
    }

    fun pickPhoto(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(uri)!!.use { i -> photoFile.outputStream().use { o -> i.copyTo(o) } }
                loadPhoto()
                applyWallpaper("photo")
            }.onFailure { messages.tryEmit("Foto tidak bisa dibuka.") }
        }
    }

    /** Cek apakah izin folder game masih berlaku. */
    fun refresh() {
        val t = tree
        val ok = t != null && ctx.contentResolver.persistedUriPermissions.any {
            it.uri == t && it.isReadPermission && it.isWritePermission
        }
        status = if (ok) AccessStatus.READY else AccessStatus.NO_ACCESS
    }

    /** Minta pengguna memilih folder game (sekali saja). */
    fun connect() { grantRequests.tryEmit(Unit) }

    /** Hasil pemilih folder. */
    fun onTreePicked(uri: Uri?) {
        if (uri == null) return
        if (!ConfigInstaller.isGameTree(uri)) {
            messages.tryEmit("Folder salah. Pilih folder Android/data/${ConfigInstaller.PKG} lalu tekan \"Gunakan folder ini\".")
            return
        }
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }.onFailure { messages.tryEmit("Izin folder tidak bisa disimpan."); return }
        tree = uri
        prefs.edit().putString("game_tree", uri.toString()).apply()
        refresh()
        messages.tryEmit("Akses folder game diberikan.")
    }

    private val noAccessMsg = "Folder game belum diberi akses."

    /** Tampilkan notifikasi; kalau gagal, sebutkan alasannya dan putar suara dari aplikasi. */
    private var notifSettingsShown = false
    private fun notifyResult(ok: Boolean, title: String, text: String) {
        val reason = Notifier.show(ctx, ok, title, text)
        if (reason != null) {
            messages.tryEmit("Notifikasi gagal: $reason")
            if (ok) Notifier.playSound(ctx)
            if ((reason.startsWith("izin") || reason.startsWith("mati")) && !notifSettingsShown) {
                notifSettingsShown = true
                runCatching {
                    ctx.startActivity(
                        Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
        }
    }

    fun loadFromGame() {
        if (!ready || busy) return
        busy = true
        val name = editFile
        viewModelScope.launch(Dispatchers.IO) {
            val t = tree
            val r = if (t == null) Result.failure<String>(IllegalStateException(noAccessMsg))
            else runCatching { ConfigInstaller.readInstalled(ctx, t, name).getOrThrow() }
            r.onSuccess {
                if (name == editFile) updateEditText(it) else prefs.edit().putString("draft_$name", it).apply()
                messages.tryEmit("$name dimuat dari game.")
            }.onFailure { messages.tryEmit(it.message ?: "Gagal membaca $name.") }
            busy = false
        }
    }

    fun loadPreset() {
        if (busy) return
        val name = editFile
        if (!isAvailable(preset, quality)) { messages.tryEmit("Preset ini belum tersedia."); return }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { ConfigInstaller.presetText(ctx, preset, quality, name) }
                .onSuccess {
                    if (name == editFile) updateEditText(it) else prefs.edit().putString("draft_$name", it).apply()
                    messages.tryEmit("Preset dimuat ke $name.")
                }
                .onFailure { messages.tryEmit("Preset tidak bisa dibaca.") }
        }
    }

    /** Buka file .txt/.ini: kalau editor kosong diganti, kalau tidak ditambahkan di bawahnya. */
    fun loadTxt(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                require(bytes.size <= 512 * 1024)
                String(bytes, Charsets.UTF_8).replace("\r\n", "\n")
            }.onSuccess {
                val cur = editText
                updateEditText(if (cur.isBlank()) it else cur.trimEnd('\n') + "\n" + it)
                messages.tryEmit(if (cur.isBlank()) "File dimuat." else "File ditambahkan ke editor.")
            }.onFailure { messages.tryEmit("File tidak bisa dibuka.") }
        }
    }

    /** Simpan draf editor ke folder Download (Engine.ini / DeviceProfiles.ini). */
    fun saveToDownload(both: Boolean) {
        val names = if (both) ConfigInstaller.FILES else listOf(editFile)
        val toSave = names.associateWith { prefs.getString("draft_$it", "") ?: "" }.filterValues { it.isNotBlank() }
        if (toSave.isEmpty()) { messages.tryEmit("Editor masih kosong."); return }
        viewModelScope.launch(Dispatchers.IO) {
            val done = toSave.filter { (n, t) -> saveDownloadFile(n, t) }.keys
            messages.tryEmit(
                if (done.size == toSave.size) "Tersimpan di Download: ${done.joinToString(", ")}"
                else "Gagal menyimpan ke Download."
            )
        }
    }

    private fun saveDownloadFile(name: String, text: String): Boolean = try {
        val cr = ctx.contentResolver
        val coll = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val bytes = text.toByteArray(Charsets.UTF_8)
        // Timpa file lama buatan aplikasi ini kalau ada; kalau tidak, buat baru.
        val old = cr.query(
            coll, arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
            arrayOf(name, "Download%"), null
        )?.use { if (it.moveToFirst()) ContentUris.withAppendedId(coll, it.getLong(0)) else null }
        val wrote = old != null && runCatching { cr.openOutputStream(old, "wt")!!.use { it.write(bytes) } }.isSuccess
        if (!wrote) {
            val uri = cr.insert(coll, ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            })!!
            cr.openOutputStream(uri, "wt")!!.use { it.write(bytes) }
        }
        true
    } catch (e: Throwable) { false }

    fun installEdited() {
        if (!ready || busy) return
        val name = editFile
        val text = editText
        if (text.isBlank()) { messages.tryEmit("Editor masih kosong."); return }
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val t = tree
            val r = if (t == null) Result.failure(IllegalStateException(noAccessMsg))
            else runCatching { ConfigInstaller.installManual(ctx, t, mapOf(name to text.toByteArray(Charsets.UTF_8))).getOrThrow() }
            val ok = r.isSuccess
            notifyResult(ok, if (ok) "Pemasangan berhasil" else "Pemasangan gagal",
                r.exceptionOrNull()?.message ?: "Terpasang: $name")
            messages.tryEmit(if (ok) "Pemasangan berhasil" else "Pemasangan gagal")
            busy = false
        }
    }

    fun isAvailable(p: Preset, q: Quality) = ConfigInstaller.isAvailable(ctx, p, q)

    fun install() {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val t = tree
            val r = if (t == null) Result.failure(IllegalStateException(noAccessMsg))
            else runCatching { ConfigInstaller.install(ctx, t, preset, quality).getOrThrow() }
            val ok = r.isSuccess
            notifyResult( ok, if (ok) "Pemasangan berhasil" else "Pemasangan gagal",
                r.exceptionOrNull()?.message ?: if (ok) "Config WuWa sudah terpasang." else "Config tidak bisa dipasang.")
            messages.tryEmit(if (ok) "Pemasangan berhasil" else "Pemasangan gagal")
            busy = false
        }
    }

    fun deleteConfig() {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val t = tree
            val r = if (t == null) Result.failure(IllegalStateException(noAccessMsg))
            else runCatching { ConfigInstaller.deleteConfig(ctx, t).getOrThrow() }
            val ok = r.isSuccess
            notifyResult( ok, if (ok) "Config dihapus" else "Gagal menghapus config",
                r.exceptionOrNull()?.message ?: if (ok) "Engine.ini dan DeviceProfiles.ini sudah dihapus." else "Config tidak bisa dihapus.")
            messages.tryEmit(if (ok) "Config dihapus" else "Gagal menghapus config")
            busy = false
        }
    }

    private fun displayName(uri: Uri): String? =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    /** Install manual: file dipilih dari folder Download (nama berisi "engine" / "deviceprofiles"). */
    fun installManual(uris: List<Uri>) {
        if (!ready || busy) return
        busy = true
        viewModelScope.launch(Dispatchers.IO) {
            val files = linkedMapOf<String, ByteArray>()
            for (u in uris) {
                val n = displayName(u)?.lowercase() ?: continue
                val target = when {
                    "deviceprofile" in n -> "DeviceProfiles.ini"
                    "engine" in n -> "Engine.ini"
                    else -> continue
                }
                runCatching { ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() } }
                    .onSuccess { files[target] = it }
            }
            val t = tree
            val r = if (t == null) Result.failure(IllegalStateException(noAccessMsg))
            else runCatching { ConfigInstaller.installManual(ctx, t, files).getOrThrow() }
            val ok = r.isSuccess
            notifyResult( ok, if (ok) "Pemasangan berhasil" else "Pemasangan gagal",
                r.exceptionOrNull()?.message ?: "Terpasang: ${files.keys.joinToString(", ")}")
            messages.tryEmit(if (ok) "Pemasangan berhasil" else "Pemasangan gagal")
            busy = false
        }
    }
}
