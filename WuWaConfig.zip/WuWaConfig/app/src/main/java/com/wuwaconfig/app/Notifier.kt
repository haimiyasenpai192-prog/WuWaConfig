package com.wuwaconfig.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    // Suara channel dikunci Android setelah dibuat, jadi id diberi versi.
    private const val CH_OK = "install_ok_v2"
    private const val CH_FAIL = "install_fail_v2"

    private fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val sound = Uri.parse("android.resource://${ctx.packageName}/${R.raw.notif_success}")
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(
            NotificationChannel(CH_OK, "Pemasangan berhasil", NotificationManager.IMPORTANCE_HIGH)
                .apply { setSound(sound, attrs) })
        nm.createNotificationChannel(
            NotificationChannel(CH_FAIL, "Pemasangan gagal", NotificationManager.IMPORTANCE_HIGH))
    }

    /** Putar suara langsung dari aplikasi (cadangan kalau notifikasi gagal tampil). */
    fun playSound(ctx: Context) {
        runCatching {
            val mp = MediaPlayer.create(
                ctx, R.raw.notif_success,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
                android.media.AudioManager.AUDIO_SESSION_ID_GENERATE
            ) ?: return
            mp.setOnCompletionListener { it.release() }
            mp.start()
        }
    }

    /** Mengembalikan null kalau sukses, atau alasan gagal (teks singkat). */
    fun show(ctx: Context, success: Boolean, title: String, text: String): String? {
        try {
            ensureChannels(ctx)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                return "izin notifikasi ditolak"
            if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return "mati: notifikasi aplikasi dimatikan"
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val chId = if (success) CH_OK else CH_FAIL
            if (nm.getNotificationChannel(chId)?.importance == NotificationManager.IMPORTANCE_NONE)
                return "mati: kategori dimatikan"
            val n = NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(if (success) R.drawable.ic_notif_ok else R.drawable.ic_notif_fail)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            nm.notify(if (success) 1 else 2, n)
            return null
        } catch (e: Throwable) {
            return "error ${e.javaClass.simpleName}: ${e.message?.take(60)}"
        }
    }
}
