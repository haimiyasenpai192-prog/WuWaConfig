package com.wuwaconfig.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

object Notifier {
    // Suara channel dikunci Android setelah dibuat, jadi id diberi versi.
    private const val CH_OK = "install_ok_v1"
    private const val CH_FAIL = "install_fail_v1"

    private fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val sound = Uri.parse("android.resource://${ctx.packageName}/${R.raw.notif_success}")
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(
            NotificationChannel(CH_OK, "Pemasangan berhasil", NotificationManager.IMPORTANCE_HIGH)
                .apply { setSound(sound, attrs) })
        nm.createNotificationChannel(
            NotificationChannel(CH_FAIL, "Pemasangan gagal", NotificationManager.IMPORTANCE_HIGH))
    }

    fun show(ctx: Context, success: Boolean, text: String? = null) {
        ensureChannels(ctx)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val n = NotificationCompat.Builder(ctx, if (success) CH_OK else CH_FAIL)
            .setSmallIcon(if (success) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (success) "Pemasangan berhasil" else "Pemasangan gagal")
            .setContentText(text ?: if (success) "Config WuWa sudah terpasang." else "Config tidak bisa dipasang.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(if (success) 1 else 2, n)
    }
}
