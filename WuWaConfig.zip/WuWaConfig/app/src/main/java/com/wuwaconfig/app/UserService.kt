package com.wuwaconfig.app

import kotlin.system.exitProcess

/** Berjalan di proses Shizuku (uid shell). */
class UserService : IUserService.Stub() {
    override fun destroy() { exitProcess(0) }

    /** Jalankan perintah sh; stderr digabung ke stdout supaya tidak ada deadlock buffer. */
    private fun sh(command: String, vararg args: String): Pair<Int, String> {
        val p = ProcessBuilder(listOf("sh", "-c", command, "sh") + args)
            .redirectErrorStream(true).start()
        p.outputStream.close()
        val out = String(p.inputStream.readBytes(), Charsets.UTF_8)
        return p.waitFor() to out
    }

    override fun exec(command: String): Int = try { sh(command).first } catch (e: Throwable) { -1 }

    override fun execOut(command: String): String = try {
        val p = ProcessBuilder("sh", "-c", command).redirectError(ProcessBuilder.Redirect.DISCARD).start()
        p.outputStream.close()
        val out = String(p.inputStream.readBytes(), Charsets.UTF_8)
        p.waitFor()
        out
    } catch (e: Throwable) { "" }

    override fun run(command: String): String = try {
        val (code, out) = sh(command)
        "$code\n${out.trim()}"
    } catch (e: Throwable) { "-1\n${e}" }

    override fun writeFile(path: String, data: ByteArray): String = try {
        // "cat >" menimpa isi file yang ada (pemilik & izin file tetap), path dikirim sebagai argumen ($1).
        val p = ProcessBuilder("sh", "-c", "cat > \"\$1\"", "sh", path)
            .redirectErrorStream(true).start()
        p.outputStream.use { it.write(data) }
        val out = String(p.inputStream.readBytes(), Charsets.UTF_8).trim()
        val code = p.waitFor()
        if (code != 0) "kode $code: $out"
        else {
            val (_, len) = sh("wc -c < \"\$1\"", path)
            val size = len.trim().toLongOrNull()
            if (size == data.size.toLong()) "" else "ukuran tidak cocok (tertulis $size dari ${data.size} byte)"
        }
    } catch (e: Throwable) { e.toString() }
}
