package com.wuwaconfig.app

import android.content.Context

enum class Preset(val key: String) { FLAGSHIP("flagship"), BALANCED("balanced") }
enum class Quality(val key: String) { HIGH("high"), MEDIUM("medium") }

/**
 * Semua operasi di folder config WuWa Global lewat Shizuku:
 * install preset (menimpa file yang ada), install manual (file pilihan sendiri),
 * dan hapus config (Engine.ini + DeviceProfiles.ini).
 */
object ConfigInstaller {
    private const val PKG = "com.kurogame.wutheringwaves.global"
    private const val BASE = "/storage/emulated/0/Android/data/$PKG"
    private const val CONFIG_DIR = "$BASE/files/UE4Game/Client/Client/Saved/Config/Android"
    val FILES = listOf("Engine.ini", "DeviceProfiles.ini")

    fun assetDir(p: Preset, q: Quality) = "configs/${p.key}_${q.key}"

    fun isAvailable(ctx: Context, p: Preset, q: Quality): Boolean =
        ctx.assets.list("configs")?.contains("${p.key}_${q.key}") == true

    /** Jalankan perintah; kembalikan (kode keluar, keluaran). */
    private fun sh(svc: IUserService, cmd: String): Pair<Int, String> {
        val r = svc.run(cmd)
        val nl = r.indexOf('\n')
        val code = (if (nl < 0) r else r.substring(0, nl)).trim().toIntOrNull() ?: -1
        return code to (if (nl < 0) "" else r.substring(nl + 1))
    }

    /** Tulis file langsung dari proses Shizuku. Mengembalikan null kalau sukses, atau pesan error. */
    private fun writeFile(svc: IUserService, name: String, bytes: ByteArray): String? {
        val err = svc.writeFile("$CONFIG_DIR/$name", bytes)
        return if (err.isEmpty()) null else err
    }

    /** Cek folder game; pesan error menyertakan alasan asli dari shell. */
    private fun checkGame(svc: IUserService): Result<Unit>? {
        val (code, out) = sh(svc, "[ -d '$BASE' ] || ls -ld '$BASE' 2>&1")
        if (code == 0) return null
        return fail("WuWa Global tidak ditemukan atau folder Android/data tidak bisa diakses." +
            if (out.isNotBlank()) " ($out)" else " Pasang gamenya dulu.")
    }

    /** Install preset: file asli HARUS sudah ada, lalu ditimpa. */
    fun install(ctx: Context, svc: IUserService, p: Preset, q: Quality): Result<Unit> {
        checkGame(svc)?.let { return it }
        for (f in FILES) if (svc.exec("[ -f '$CONFIG_DIR/$f' ]") != 0)
            return fail("$f asli tidak ditemukan. Buka game sekali dulu, lalu coba lagi.")
        for (f in FILES) {
            val bytes = ctx.assets.open("${assetDir(p, q)}/$f").use { it.readBytes() }
            writeFile(svc, f, bytes)?.let { return fail("Gagal menulis $f: $it") }
        }
        return Result.success(Unit)
    }

    /** Install manual: file pilihan sendiri; dibuat kalau belum ada (folder config dibuat bila perlu). */
    fun installManual(svc: IUserService, files: Map<String, ByteArray>): Result<Unit> {
        if (files.isEmpty()) return fail("Pilih file Engine.ini dan/atau DeviceProfiles.ini.")
        checkGame(svc)?.let { return it }
        val (mk, mkOut) = sh(svc, "mkdir -p '$CONFIG_DIR' 2>&1")
        if (mk != 0) return fail("Folder config tidak bisa dibuat: $mkOut")
        for ((name, bytes) in files) writeFile(svc, name, bytes)?.let { return fail("Gagal menulis $name: $it") }
        return Result.success(Unit)
    }

    /** Hapus Engine.ini dan DeviceProfiles.ini. */
    fun deleteConfig(svc: IUserService): Result<Unit> {
        checkGame(svc)?.let { return it }
        for (f in FILES) svc.exec("rm -f '$CONFIG_DIR/$f'")
        for (f in FILES) if (svc.exec("[ ! -e '$CONFIG_DIR/$f' ]") != 0)
            return fail("Gagal menghapus $f.")
        return Result.success(Unit)
    }

    /** Isi file preset dari assets (untuk editor). */
    fun presetText(ctx: Context, p: Preset, q: Quality, name: String): String =
        ctx.assets.open("${assetDir(p, q)}/$name").use { it.readBytes() }
            .toString(Charsets.UTF_8).replace("\r\n", "\n")

    /** Baca file config yang sedang terpasang di game (untuk editor). */
    fun readInstalled(svc: IUserService, name: String): Result<String> {
        checkGame(svc)?.let { return Result.failure(it.exceptionOrNull()!!) }
        if (svc.exec("[ -f '$CONFIG_DIR/$name' ]") != 0)
            return Result.failure(IllegalStateException("$name belum ada di game. Buka game sekali dulu."))
        return Result.success(svc.execOut("cat '$CONFIG_DIR/$name'").replace("\r\n", "\n"))
    }

    private fun fail(msg: String) = Result.failure<Unit>(IllegalStateException(msg))
}
