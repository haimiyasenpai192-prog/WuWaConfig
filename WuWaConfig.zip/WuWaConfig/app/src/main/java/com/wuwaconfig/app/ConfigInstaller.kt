package com.wuwaconfig.app

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile

enum class Preset(val key: String) { FLAGSHIP("flagship"), BALANCED("balanced") }
enum class Quality(val key: String) { HIGH("high"), MEDIUM("medium") }

/**
 * Semua operasi di folder config WuWa Global lewat izin folder (Storage Access Framework):
 * install preset (menimpa file yang ada), install manual (file pilihan sendiri),
 * dan hapus config (Engine.ini + DeviceProfiles.ini).
 *
 * Pengguna memberi izin SEKALI untuk folder Android/data/<paket game>; URI-nya disimpan permanen.
 */
object ConfigInstaller {
    const val PKG = "com.kurogame.wutheringwaves.global"
    private const val AUTH = "com.android.externalstorage.documents"
    private const val GAME_DOC_ID = "primary:Android/data/$PKG"
    private val CONFIG_PATH = listOf("files", "UE4Game", "Client", "Client", "Saved", "Config", "Android")
    val FILES = listOf("Engine.ini", "DeviceProfiles.ini")

    /** Lokasi awal pemilih folder: langsung ke folder game (jalan di Android 11-12). */
    val initialUri: Uri get() = DocumentsContract.buildDocumentUriUsingTree(
        DocumentsContract.buildTreeDocumentUri(AUTH, "primary:Android/data"),
        GAME_DOC_ID
    )

    /** True kalau URI yang dipilih memang folder game. */
    fun isGameTree(uri: Uri): Boolean =
        runCatching { DocumentsContract.getTreeDocumentId(uri) == GAME_DOC_ID }.getOrDefault(false)

    fun assetDir(p: Preset, q: Quality) = "configs/${p.key}_${q.key}"

    fun isAvailable(ctx: Context, p: Preset, q: Quality): Boolean =
        ctx.assets.list("configs")?.contains("${p.key}_${q.key}") == true

    // ---------- helper SAF ----------

    private fun root(ctx: Context, tree: Uri): DocumentFile? =
        DocumentFile.fromTreeUri(ctx, tree)?.takeIf { it.exists() }

    private fun configDir(root: DocumentFile, create: Boolean): DocumentFile? {
        var d = root
        for (n in CONFIG_PATH) {
            val next = d.findFile(n)?.takeIf { it.isDirectory }
                ?: (if (create) d.createDirectory(n) else null)
                ?: return null
            d = next
        }
        return d
    }

    /** Tulis file (timpa kalau ada, buat kalau belum). Mengembalikan null kalau sukses, atau pesan error. */
    private fun writeFile(ctx: Context, dir: DocumentFile, name: String, bytes: ByteArray): String? {
        return try {
            val f = dir.findFile(name) ?: dir.createFile("application/octet-stream", name)
                ?: return "file tidak bisa dibuat"
            if (f.name != name) { f.delete(); return "nama file berubah menjadi ${f.name}" }
            ctx.contentResolver.openOutputStream(f.uri, "wt")!!.use { it.write(bytes) }
            val size = dir.findFile(name)?.length()
            if (size == bytes.size.toLong()) null else "ukuran tidak cocok (tertulis $size dari ${bytes.size} byte)"
        } catch (e: Throwable) { e.message ?: e.toString() }
    }

    private fun noAccess() = fail("Folder game belum diberi akses. Buka Settings lalu beri akses, dan pastikan WuWa Global sudah terpasang.")

    // ---------- operasi ----------

    /** Install preset: file asli HARUS sudah ada, lalu ditimpa. */
    fun install(ctx: Context, tree: Uri, p: Preset, q: Quality): Result<Unit> {
        val r = root(ctx, tree) ?: return noAccess()
        val dir = configDir(r, create = false)
        for (f in FILES) if (dir?.findFile(f)?.isFile != true)
            return fail("$f asli tidak ditemukan. Buka game sekali dulu, lalu coba lagi.")
        for (f in FILES) {
            val bytes = ctx.assets.open("${assetDir(p, q)}/$f").use { it.readBytes() }
            writeFile(ctx, dir!!, f, bytes)?.let { return fail("Gagal menulis $f: $it") }
        }
        return Result.success(Unit)
    }

    /** Install manual: file pilihan sendiri; dibuat kalau belum ada (folder config dibuat bila perlu). */
    fun installManual(ctx: Context, tree: Uri, files: Map<String, ByteArray>): Result<Unit> {
        if (files.isEmpty()) return fail("Pilih file Engine.ini dan/atau DeviceProfiles.ini.")
        val r = root(ctx, tree) ?: return noAccess()
        val dir = configDir(r, create = true) ?: return fail("Folder config tidak bisa dibuat.")
        for ((name, bytes) in files) writeFile(ctx, dir, name, bytes)?.let { return fail("Gagal menulis $name: $it") }
        return Result.success(Unit)
    }

    /** Hapus Engine.ini dan DeviceProfiles.ini. */
    fun deleteConfig(ctx: Context, tree: Uri): Result<Unit> {
        val r = root(ctx, tree) ?: return noAccess()
        val dir = configDir(r, create = false)
        for (f in FILES) dir?.findFile(f)?.delete()
        for (f in FILES) if (dir?.findFile(f) != null) return fail("Gagal menghapus $f.")
        return Result.success(Unit)
    }

    /** Isi file preset dari assets (untuk editor). */
    fun presetText(ctx: Context, p: Preset, q: Quality, name: String): String =
        ctx.assets.open("${assetDir(p, q)}/$name").use { it.readBytes() }
            .toString(Charsets.UTF_8).replace("\r\n", "\n")

    /** Baca file config yang sedang terpasang di game (untuk editor). */
    fun readInstalled(ctx: Context, tree: Uri, name: String): Result<String> {
        val r = root(ctx, tree) ?: return Result.failure(noAccess().exceptionOrNull()!!)
        val f = configDir(r, create = false)?.findFile(name)?.takeIf { it.isFile }
            ?: return Result.failure(IllegalStateException("$name belum ada di game. Buka game sekali dulu."))
        return runCatching {
            ctx.contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }
                .toString(Charsets.UTF_8).replace("\r\n", "\n")
        }
    }

    private fun fail(msg: String) = Result.failure<Unit>(IllegalStateException(msg))
}
