package com.wuwaconfig.app

import android.content.Context
import android.util.Base64

enum class Preset(val key: String) { FLAGSHIP("flagship"), BALANCED("balanced") }
enum class Quality(val key: String) { TINGGI("tinggi"), SEDANG("sedang") }

/**
 * Menimpa Engine.ini dan DeviceProfiles.ini milik WuWa Global.
 * File asli HARUS sudah ada (tidak membuat file baru).
 */
object ConfigInstaller {
    private const val PKG = "com.kurogame.wutheringwaves.global"
    private const val BASE = "/storage/emulated/0/Android/data/$PKG"
    private const val CONFIG_DIR = "$BASE/files/UE4Game/Client/Client/Saved/Config/Android"
    const val BACKUP_DIR = "/storage/emulated/0/WuWaConfig/backup"
    private val FILES = listOf("Engine.ini", "DeviceProfiles.ini")

    fun assetDir(p: Preset, q: Quality) = "configs/${p.key}_${q.key}"

    /** Preset tersedia kalau foldernya ada di assets. */
    fun isAvailable(ctx: Context, p: Preset, q: Quality): Boolean =
        ctx.assets.list("configs")?.contains("${p.key}_${q.key}") == true

    fun install(ctx: Context, svc: IUserService, p: Preset, q: Quality, backup: Boolean): Result<Unit> {
        if (svc.exec("[ -d '$BASE' ]") != 0)
            return fail("WuWa Global tidak ditemukan. Pasang gamenya dulu.")
        for (f in FILES) if (svc.exec("[ -f '$CONFIG_DIR/$f' ]") != 0)
            return fail("$f asli tidak ditemukan. Buka game sekali dulu, lalu coba lagi.")

        if (backup) {
            svc.exec("mkdir -p '$BACKUP_DIR'")
            for (f in FILES) {
                // Backup hanya sekali, supaya yang tersimpan tetap file asli.
                if (svc.exec("[ -e '$BACKUP_DIR/$f.orig' ]") != 0) {
                    svc.exec("cat '$CONFIG_DIR/$f' > '$BACKUP_DIR/$f.orig'")
                    if (svc.exec("[ -s '$BACKUP_DIR/$f.orig' ]") != 0)
                        return fail("Backup $f gagal dibuat.")
                }
            }
        }

        for (f in FILES) {
            val bytes = ctx.assets.open("${assetDir(p, q)}/$f").use { it.readBytes() }
            val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            val target = "$CONFIG_DIR/$f"
            svc.exec("echo '$b64' | base64 -d > '$target'")
            if (svc.exec("[ \"$(wc -c < '$target')\" -eq ${bytes.size} ]") != 0)
                return fail("Gagal menulis $f.")
        }
        return Result.success(Unit)
    }

    fun restore(svc: IUserService): Result<Unit> {
        for (f in FILES) if (svc.exec("[ -f '$BACKUP_DIR/$f.orig' ]") != 0)
            return fail("Belum ada backup config asli.")
        for (f in FILES) {
            if (svc.exec("cat '$BACKUP_DIR/$f.orig' > '$CONFIG_DIR/$f'") != 0)
                return fail("Gagal memulihkan $f.")
        }
        return Result.success(Unit)
    }

    private fun fail(msg: String) = Result.failure<Unit>(IllegalStateException(msg))
}
