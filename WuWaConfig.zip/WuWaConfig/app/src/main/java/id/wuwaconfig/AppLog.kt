package id.wuwaconfig

import android.content.Context
import android.os.Build
import androidx.compose.runtime.mutableStateOf
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log aktivitas aplikasi (pasang / hapus config, akses Shizuku/Root) yang disimpan di file internal.
 * Tujuannya: kalau pemasangan gagal, pengguna bisa buka log, salin / bagikan, lalu penyebabnya ketahuan.
 * Ukuran file dibatasi supaya tidak membengkak.
 */
object AppLog {
    private const val FILE = "wave_log.txt"
    private const val MAX_BYTES = 200_000L
    private const val KEEP_BYTES = 120_000

    private var file: File? = null
    private val lock = Any()
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US)

    /** Naik setiap ada entri baru, supaya layar log bisa memuat ulang. */
    val version = mutableStateOf(0)

    fun init(ctx: Context) {
        if (file == null) file = File(ctx.applicationContext.filesDir, FILE)
    }

    fun i(tag: String, msg: String) = add("I", tag, msg)
    fun w(tag: String, msg: String) = add("W", tag, msg)
    fun e(tag: String, msg: String) = add("E", tag, msg)

    /** Entri banyak baris (mis. hasil diagnosa): baris berikutnya diberi indentasi. */
    private fun add(level: String, tag: String, msg: String) {
        val f = file ?: return
        try {
            synchronized(lock) {
                if (f.exists() && f.length() > MAX_BYTES) {
                    val t = f.readText()
                    f.writeText("... (log lama dipangkas)\n" + t.takeLast(KEEP_BYTES).substringAfter('\n'))
                }
                val lines = msg.trimEnd().lines()
                val sb = StringBuilder()
                sb.append(fmt.format(Date())).append(' ').append(level).append('/').append(tag).append(": ").append(lines.firstOrNull() ?: "").append('\n')
                lines.drop(1).forEach { sb.append("    ").append(it).append('\n') }
                f.appendText(sb.toString())
            }
            version.value = version.value + 1
        } catch (_: Throwable) {}
    }

    fun read(): String = try {
        synchronized(lock) { file?.takeIf { it.exists() }?.readText().orEmpty() }
    } catch (_: Throwable) { "" }

    fun clear() {
        try { synchronized(lock) { file?.delete() } } catch (_: Throwable) {}
        version.value = version.value + 1
    }

    /** Info perangkat & aplikasi, ditaruh di atas log saat disalin / dibagikan. */
    fun header(ctx: Context): String {
        val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "?" }
        val game = try { ShizukuShell.installedPackage(ctx) } catch (_: Throwable) { null }
        return buildString {
            appendLine("== Wave Config log ==")
            appendLine("App      : $ver")
            appendLine("Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android  : ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("Akses    : ${ShizukuShell.modeName()} (status ${ShizukuShell.status.value})")
            appendLine("Game     : ${game ?: "tidak ditemukan"}")
            appendLine("======================")
        }
    }
}
