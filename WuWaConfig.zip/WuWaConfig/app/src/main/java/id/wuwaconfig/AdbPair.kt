package id.wuwaconfig

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import io.github.muntashirakon.adb.AdbStream
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/**
 * Akses lewat Wireless Debugging bawaan Android (tanpa Shizuku, tanpa root).
 * Alur: pairing sekali (port + kode 6 digit dari "Pair device with pairing code"),
 * lalu connect otomatis ke port Wireless Debugging. Kunci disimpan di filesDir supaya tidak perlu pairing ulang.
 */
object AdbPair {
    enum class Step { IDLE, PAIRING, PAIRED, CONNECTING, CONNECTED, FAILED }

    val step = mutableStateOf(Step.IDLE)
    val message = mutableStateOf("")

    private var mgr: Manager? = null

    private class Manager(ctx: Context) : AbsAdbConnectionManager() {
        private val dir = ctx.filesDir
        private var priv: PrivateKey
        private var cert: Certificate

        init {
            api = 30
            val kf = File(dir, "adb_key.pk8"); val cf = File(dir, "adb_cert.der")
            if (kf.exists() && cf.exists()) {
                priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
                cert = CertificateFactory.getInstance("X.509").generateCertificate(cf.inputStream())
            } else {
                val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
                val name = X500Name("CN=WaveConfig")
                val b = JcaX509v3CertificateBuilder(name, BigInteger.valueOf(System.nanoTime()),
                    Date(System.currentTimeMillis() - 86_400_000L), Date(System.currentTimeMillis() + 10L * 365 * 86_400_000L),
                    name, kp.public)
                val signer = JcaContentSignerBuilder("SHA512withRSA").build(kp.private)
                priv = kp.private
                cert = JcaX509CertificateConverter().getCertificate(b.build(signer))
                kf.writeBytes(priv.encoded); cf.writeBytes(cert.encoded)
            }
        }

        override fun getPrivateKey(): PrivateKey = priv
        override fun getCertificate(): Certificate = cert
        override fun getDeviceName(): String = "WaveConfig"
    }

    private fun m(ctx: Context) = mgr ?: Manager(ctx.applicationContext).also { mgr = it }

    /** Jalankan di thread background. Mengembalikan null kalau berhasil, atau pesan error. */
    fun pair(ctx: Context, port: Int, code: String): String? = try {
        step.value = Step.PAIRING; message.value = "Memasangkan…"
        val ok = m(ctx).pair("127.0.0.1", port, code)
        if (!ok) fail("Kode atau port salah. Kode berubah tiap dialog pairing dibuka ulang.")
        else { step.value = Step.PAIRED; message.value = "Berhasil dipasangkan"; AppLog.i("ADB", "Pairing OK"); null }
    } catch (e: Throwable) {
        fail("Pairing gagal: ${e.message ?: e.javaClass.simpleName}")
    }

    /** Sambung ke layanan Wireless Debugging yang sedang aktif (port dicari otomatis lewat mDNS). */
    fun connect(ctx: Context): String? = try {
        step.value = Step.CONNECTING; message.value = "Menyambung…"
        val ok = m(ctx).autoConnect(ctx.applicationContext, 8000)
        if (!ok) fail("Wireless Debugging belum menyala atau HP tidak terhubung Wi-Fi.")
        else {
            step.value = Step.CONNECTED; message.value = "Terhubung"; AppLog.i("ADB", "Connect OK")
            // Seperti Brevent: matikan batas waktu otorisasi Wireless Debugging (best effort, butuh uid shell).
            one("settings put global adb_allowed_connection_time 0").let { AppLog.i("ADB", "adb_allowed_connection_time=0 -> exit ${it.first}") }
            // Cek akses ke Android/data sebagai shell, hasilnya masuk log untuk diagnosa.
            one("id; ls -ld /storage/emulated/0/Android/data").let { AppLog.i("ADB", "uji Android/data: ${it.second.replace('\n', ' | ')}") }
            null
        }
    } catch (e: Throwable) {
        fail("Gagal menyambung: ${e.message ?: e.javaClass.simpleName}")
    }

    fun isConnected(): Boolean = try { mgr?.isConnected == true } catch (_: Throwable) { false }

    /** Satu panggilan exec: (tanpa PTY, tanpa echo). Mengembalikan Pair(kode keluar, keluaran). */
    private fun one(cmd: String): Pair<Int, String> {
        val mm = mgr ?: return 255 to "ADB belum terhubung"
        return try {
            val s: AdbStream = mm.openStream("exec:{ $cmd ; } 2>&1; echo __EXIT:\$?")
            val text = s.openInputStream().bufferedReader().readText()
            s.close()
            val i = text.lastIndexOf("__EXIT:")
            if (i < 0) 255 to text
            else (text.substring(i + 7).trim().toIntOrNull() ?: 255) to text.substring(0, i).trimEnd('\n', '\r')
        } catch (e: Throwable) { 255 to (e.message ?: "Error") }
    }

    /**
     * Jalankan perintah lewat ADB. Kalau ada [stdin], data dikirim per potongan base64 kecil ke file sementara
     * (batas panjang satu perintah ADB), lalu didekode dan dialirkan ke perintah tersebut.
     */
    fun exec(cmd: String, stdin: ByteArray? = null): Pair<Int, String> {
        if (stdin == null) return one(cmd)
        val tmp = "/data/local/tmp/wuwa_in.b64"
        val b64 = android.util.Base64.encodeToString(stdin, android.util.Base64.NO_WRAP)
        one(": > $tmp").let { if (it.first != 0) return it }
        for (c in b64.chunked(2000)) one("echo -n '$c' >> $tmp").let { if (it.first != 0) return it }
        val r = one("base64 -d $tmp | { $cmd ; }")
        one("rm -f $tmp")
        return r
    }

    fun disconnect() { try { mgr?.disconnect() } catch (_: Throwable) {}; step.value = Step.IDLE; message.value = "" }

    private fun fail(msg: String): String {
        step.value = Step.FAILED; message.value = msg; AppLog.e("ADB", msg); return msg
    }
}
