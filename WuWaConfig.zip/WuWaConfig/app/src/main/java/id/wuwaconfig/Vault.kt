package id.wuwaconfig

import android.content.Context
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Config bawaan disimpan terenkripsi (AES-256-CBC) di assets/presets sebagai file .bin (format: 16 byte IV + data),
 * supaya isi APK tidak memperlihatkan zip config. Didekripsi di memori saat dibutuhkan, tidak pernah ditulis ke disk.
 * Ini perlindungan dasar: orang yang membongkar kode aplikasi masih bisa menemukan kuncinya.
 */
object Vault {
    private val A = listOf(
        "5f5d25c546c5cd84",
        "534aa9c90e102b7a",
        "477c06f42227baae",
        "d107ac10a7f6d8b9")
    private val B = listOf(
        "9a26d84081085093",
        "cc2d609e9d4f1ea3",
        "087b18f459558dbd",
        "cb357af9c11cdd65")

    private fun hex(parts: List<String>): ByteArray {
        val s = parts.joinToString("")
        return ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    private fun key(): ByteArray {
        val a = hex(A); val b = hex(B)
        return ByteArray(a.size) { (a[it].toInt() xor b[it].toInt()).toByte() }
    }

    /** Baca dan dekripsi assets/[path]. Mengembalikan null kalau file tidak ada atau gagal didekripsi. */
    fun open(ctx: Context, path: String): ByteArray? = try {
        val raw = ctx.assets.open(path).use { it.readBytes() }
        val c = Cipher.getInstance("AES/CBC/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key(), "AES"), IvParameterSpec(raw.copyOfRange(0, 16)))
        c.doFinal(raw, 16, raw.size - 16)
    } catch (_: Throwable) { null }
}
