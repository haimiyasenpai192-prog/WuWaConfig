package id.wuwaconfig

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

/**
 * Notifikasi "Pair" dengan kolom balasan (RemoteInput), supaya kode 6 digit bisa diketik
 * dari bayangan notifikasi sementara layar Pengaturan Wireless Debugging terbuka (mode split / floating).
 * Port pairing diambil dari yang terakhir diisi di aplikasi.
 */
object PairNotif {
    const val CH = "adb_pair"
    const val ID = 77
    const val KEY = "code"
    const val ACTION = "id.wuwaconfig.PAIR_REPLY"

    fun show(ctx: Context, port: Int, text: String = "Ketik kode 6 digit dari layar Pairing.") {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Pairing Wireless Debugging", NotificationManager.IMPORTANCE_HIGH))
        val ri = RemoteInput.Builder(KEY).setLabel("Kode 6 digit").build()
        val pi = PendingIntent.getBroadcast(ctx, 0,
            Intent(ACTION).setPackage(ctx.packageName).setClass(ctx, PairReplyReceiver::class.java).putExtra("port", port),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_send), "Balas kode", pi)
            .addRemoteInput(ri).build()
        nm.notify(ID, Notification.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Pairing nirkabel (port $port)")
            .setContentText(text)
            .setOngoing(true)
            .addAction(act).build())
    }

    fun cancel(ctx: Context) = ctx.getSystemService(NotificationManager::class.java).cancel(ID)
}

class PairReplyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val code = RemoteInput.getResultsFromIntent(i)?.getCharSequence(PairNotif.KEY)?.toString()?.filter { it.isDigit() } ?: return
        val port = i.getIntExtra("port", 0)
        val app = ctx.applicationContext
        if (code.length != 6 || port == 0) { PairNotif.show(app, port, "Kode harus 6 digit. Coba lagi."); return }
        val pending = goAsync()
        Thread {
            val err = ShizukuShell.pairAdb(app, port, code)
            if (err == null) {
                PairNotif.cancel(app); Notifier.accessSelected(app, "Wireless ADB")
            } else PairNotif.show(app, port, err)
            pending.finish()
        }.start()
    }
}
