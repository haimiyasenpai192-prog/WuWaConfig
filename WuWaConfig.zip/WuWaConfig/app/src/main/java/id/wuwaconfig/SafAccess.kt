package id.wuwaconfig

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import java.io.File

/**
 * Akses folder config game lewat Storage Access Framework (picker folder), tanpa Shizuku/root.
 * Ini jalur yang dipakai file manager (mis. ZArchiver) saat shell ditolak ROM: yang mengakses file
 * adalah provider sistem (externalstorage), bukan uid shell.
 */
object SafAccess {
    private const val KEY = "saf_tree"
    private const val AUTH = "com.android.externalstorage.documents"
    private const val SUB = "files/UE4Game/Client/Client/Saved/Config/Android"
    private const val BASE = "Android/data"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun uri(ctx: Context): Uri? = prefs(ctx).getString(KEY, null)?.let { Uri.parse(it) }

    fun granted(ctx: Context): Boolean {
        val u = uri(ctx) ?: return false
        return ctx.contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission }
    }

    /** Intent picker folder, langsung diarahkan ke Android/data/<pkg>. Pengguna tinggal tekan "Gunakan folder ini". */
    fun intent(pkg: String?): Intent {
        val doc = "primary:$BASE" + (pkg?.let { "/$it" } ?: "")
        return Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildDocumentUri(AUTH, doc))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        }
    }

    /** Simpan folder pilihan. Return pesan error, atau null kalau berhasil. */
    fun onResult(ctx: Context, u: Uri, pkg: String?): String? {
        val id = try { DocumentsContract.getTreeDocumentId(u) } catch (_: Throwable) { return "Folder tidak valid." }
        val segs = id.removePrefix("primary:").split("/").filter { it.isNotEmpty() }
        val want = listOf("Android", "data") + listOfNotNull(pkg) + SUB.split("/")
        // Boleh Android/data, Android/data/<pkg>, atau lebih dalam sampai folder Android (config), asal searah jalur target.
        val ok = id.startsWith("primary:") && segs.size >= 2 && segs.zip(want).all { (a, b) -> a == b }
        if (!ok) return "Pilih folder Android/data/${pkg ?: "<game>"} (bukan folder lain)."
        return try {
            ctx.contentResolver.takePersistableUriPermission(u,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs(ctx).edit().putString(KEY, u.toString()).apply()
            AppLog.i("SAF", "Folder diizinkan: $id")
            null
        } catch (e: Throwable) {
            AppLog.e("SAF", "Gagal menyimpan izin folder: ${e.message}")
            "Gagal menyimpan izin folder: ${e.message}"
        }
    }

    fun revoke(ctx: Context) {
        uri(ctx)?.let { try { ctx.contentResolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Throwable) {} }
        prefs(ctx).edit().remove(KEY).apply()
    }

    /** Folder config game (Config/Android). Dibuat kalau [create]. */
    private fun configDir(ctx: Context, pkg: String, create: Boolean): DocumentFile? {
        val u = uri(ctx) ?: return null
        val root = DocumentFile.fromTreeUri(ctx, u) ?: return null
        val id = DocumentsContract.getTreeDocumentId(u)
        val have = id.removePrefix("primary:").split("/").filter { it.isNotEmpty() }
        val full = listOf("Android", "data", pkg) + SUB.split("/")
        if (have.size > full.size || have.zip(full).any { (a, b) -> a != b }) return null
        var d: DocumentFile = root
        for (seg in full.drop(have.size)) {
            val next = d.findFile(seg)
            d = if (next != null && next.isDirectory) next
                else if (create) (d.createDirectory(seg) ?: return null) else return null
        }
        return d
    }

    fun write(ctx: Context, pkg: String, name: String, text: String): String? {
        return try {
            val dir = configDir(ctx, pkg, true) ?: return "Folder config tidak bisa diakses lewat SAF. Izinkan ulang folder Android/data/$pkg."
            val f = dir.findFile(name) ?: dir.createFile("application/octet-stream", name)
                ?: return "Gagal membuat $name lewat SAF."
            val out = ctx.contentResolver.openOutputStream(f.uri, "wt") ?: return "Gagal membuka $name untuk ditulis (SAF)."
            out.use { it.write(text.toByteArray()) }
            AppLog.i("Tulis", "OK $name (${text.length} karakter) via SAF")
            null
        } catch (e: Throwable) {
            AppLog.e("Tulis", "SAF EXCEPTION $name | ${e.javaClass.simpleName}: ${e.message}")
            e.message ?: "Error SAF"
        }
    }

    fun read(ctx: Context, pkg: String, name: String): String? = try {
        val f = configDir(ctx, pkg, false)?.findFile(name)
        f?.let { ctx.contentResolver.openInputStream(it.uri)?.use { s -> s.bufferedReader().readText() } }
    } catch (_: Throwable) { null }

    fun names(ctx: Context, pkg: String): List<String>? = try {
        configDir(ctx, pkg, false)?.listFiles()?.mapNotNull { it.name }
    } catch (_: Throwable) { null }

    fun delete(ctx: Context, pkg: String, names: List<String>): String? = try {
        val d = configDir(ctx, pkg, false)
        names.forEach { n -> d?.findFile(n)?.delete() }
        AppLog.i("Hapus", "OK via SAF ${names.joinToString()}")
        null
    } catch (e: Throwable) {
        AppLog.e("Hapus", "SAF EXCEPTION ${e.javaClass.simpleName}: ${e.message}")
        e.message ?: "Error SAF"
    }
}
