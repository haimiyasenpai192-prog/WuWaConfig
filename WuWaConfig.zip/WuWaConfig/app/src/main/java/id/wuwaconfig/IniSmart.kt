package id.wuwaconfig

/**
 * Parser ringan untuk file .ini (Engine.ini / DeviceProfiles.ini).
 * Item yang dimatikan tidak dihapus, tapi diberi awalan ";off:" supaya menjadi komentar
 * (diabaikan game) dan bisa dinyalakan lagi tanpa kehilangan isinya.
 */
object IniSmart {
    const val OFF = ";off:"

    data class Item(val line: Int, val text: String, val on: Boolean)
    data class Section(val name: String, val header: Int, val items: List<Item>) {
        val activeCount: Int get() = items.count { it.on }
    }

    private fun isHeader(t: String) = t.length >= 2 && t.startsWith("[") && t.endsWith("]")

    fun parse(text: String): List<Section> {
        val out = mutableListOf<Section>()
        var name = "(tanpa section)"
        var header = -1
        var items = mutableListOf<Item>()
        fun flush() { if (header >= 0 || items.isNotEmpty()) out.add(Section(name, header, items.toList())) }
        text.split("\n").forEachIndexed { i, raw ->
            val t = raw.trim()
            val offHeader = t.startsWith(OFF) && isHeader(t.removePrefix(OFF).trim())
            when {
                isHeader(t) || offHeader -> {
                    flush()
                    name = (if (offHeader) t.removePrefix(OFF).trim() else t).removeSurrounding("[", "]")
                    header = i
                    items = mutableListOf()
                }
                t.startsWith(OFF) -> items.add(Item(i, t.removePrefix(OFF).trim(), false))
                t.isEmpty() || t.startsWith(";") || t.startsWith("#") -> {}
                else -> items.add(Item(i, t, true))
            }
        }
        flush()
        return out
    }

    private fun toggleLine(raw: String, enable: Boolean): String {
        val t = raw.trim()
        if (t.isEmpty()) return raw
        val lead = raw.substring(0, raw.length - raw.trimStart().length)
        val cr = if (raw.endsWith("\r")) "\r" else ""
        return if (enable) {
            if (t.startsWith(OFF)) lead + t.removePrefix(OFF).trim() + cr else raw
        } else {
            if (!t.startsWith(OFF)) lead + OFF + t + cr else raw
        }
    }

    /** Nyalakan / matikan baris-baris tertentu, lalu rapikan header section-nya. */
    fun setItems(text: String, lineIdx: Set<Int>, enable: Boolean): String {
        val lines = text.split("\n").toMutableList()
        lineIdx.forEach { i -> if (i in lines.indices) lines[i] = toggleLine(lines[i], enable) }
        return fixHeaders(lines.joinToString("\n"))
    }

    /** Header section ikut mati bila semua itemnya mati, dan menyala lagi bila ada yang aktif. */
    fun fixHeaders(text: String): String {
        val lines = text.split("\n").toMutableList()
        parse(text).forEach { s ->
            if (s.header >= 0 && s.items.isNotEmpty()) lines[s.header] = toggleLine(lines[s.header], s.activeCount > 0)
        }
        return lines.joinToString("\n")
    }

    /** Daftar bagian standar untuk Engine.ini. */
    val ENGINE_SECTIONS = listOf(
        "/Script/Engine.RendererSettings",
        "/Script/Engine.RendererOverrideSettings",
        "/Script/Engine.AnimationSettings",
        "PrecomputedVisibility/Runtime",
        "ConsoleVariables",
        "/Script/Engine.StreamingSettings",
        "SystemSettings"
    )

    private fun headerName(raw: String): String? {
        val t = raw.trim()
        return if (isHeader(t)) t.removeSurrounding("[", "]").trim() else null
    }

    private fun findSection(lines: List<String>, name: String): IntRange? {
        val start = lines.indexOfFirst { headerName(it)?.equals(name, ignoreCase = true) == true }
        if (start < 0) return null
        var end = lines.size
        for (i in start + 1 until lines.size) if (headerName(lines[i]) != null) { end = i; break }
        return start..(end - 1)
    }

    /** Isi (tanpa header) dari satu bagian; kosong bila bagian belum ada. */
    fun getBody(text: String, name: String): String {
        val lines = text.split("\n")
        val r = findSection(lines, name) ?: return ""
        return lines.subList(r.first + 1, r.last + 1).joinToString("\n").trim('\n', '\r').trimEnd()
    }

    /** Ganti isi satu bagian (atau tambahkan bagian baru di akhir file bila belum ada). */
    fun setBody(text: String, name: String, body: String): String {
        val cleanBody = body.trimEnd()
        val lines = text.split("\n")
        val r = findSection(lines, name)
        if (r == null) {
            if (cleanBody.isBlank()) return text
            val base = text.trimEnd()
            return (if (base.isEmpty()) "" else base + "\n\n") + "[" + name + "]\n" + cleanBody + "\n"
        }
        val before = lines.subList(0, r.first + 1)
        val after = lines.subList(r.last + 1, lines.size)
        val out = mutableListOf<String>()
        out.addAll(before)
        if (cleanBody.isNotBlank()) out.addAll(cleanBody.split("\n"))
        if (after.isNotEmpty()) { out.add(""); out.addAll(after.dropWhile { it.isBlank() }) }
        return out.joinToString("\n")
    }
}
