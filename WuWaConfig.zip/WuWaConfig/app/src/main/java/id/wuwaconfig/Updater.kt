package id.wuwaconfig

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cek pembaruan lewat GitHub Releases. Setiap build di GitHub Actions otomatis membuat release baru
 * (tag v<nomor build>) berisi APK. Aplikasi membandingkan nomor itu dengan versionCode yang terpasang.
 */
object Updater {
    const val REPO = "haimiyasenpai192-prog/WuWaConfig"

    class Info(val code: Int, val name: String, val url: String)
    class Result(val info: Info?, val failed: Boolean)

    /** Pembaruan yang menunggu ditampilkan (null = tidak ada). */
    val pending = mutableStateOf<Info?>(null)

    @Suppress("DEPRECATION")
    fun installedCode(ctx: Context): Int = try {
        val p = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else p.versionCode
    } catch (_: Throwable) { 0 }

    fun installedName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0"
    } catch (_: Throwable) { "1.0" }

    private fun fetch(): Result {
        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            if (c.responseCode == 404) return Result(null, false)
            if (c.responseCode != 200) return Result(null, true)
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val tag = j.optString("tag_name")
            val code = tag.filter { it.isDigit() }.toIntOrNull() ?: return Result(null, true)
            var url = j.optString("html_url")
            val assets = j.optJSONArray("assets")
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); break }
                }
            }
            val name = j.optString("name").ifBlank { tag }
            return Result(Info(code, name, url), false)
        } finally {
            c.disconnect()
        }
    }

    /** Cek di latar belakang, hasilnya dikirim ke thread utama. */
    fun check(onDone: (Result) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        Thread {
            val r = try { fetch() } catch (_: Throwable) { Result(null, true) }
            main.post { onDone(r) }
        }.start()
    }

    /** silent = true untuk cek otomatis saat aplikasi dibuka (tidak ada toast kalau tidak ada pembaruan). */
    fun checkAndNotify(ctx: Context, silent: Boolean) {
        check { r ->
            val i = r.info
            if (r.failed) {
                if (!silent) toast(ctx, "Gagal memeriksa pembaruan. Cek koneksi internet.")
            } else if (i != null && i.code > installedCode(ctx)) {
                pending.value = i
            } else {
                if (!silent) toast(ctx, "Aplikasi sudah versi terbaru.")
            }
        }
    }
}

/** Dipasang sekali di App(): cek otomatis saat dibuka dan tampilkan dialog kalau ada versi baru. */
@Composable
fun UpdateHost() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Updater.checkAndNotify(ctx, silent = true) }
    val info = Updater.pending.value ?: return
    AlertDialog(
        onDismissRequest = { Updater.pending.value = null },
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Pembaruan tersedia", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = { Text("${info.name} siap diunduh. Config terbaru sudah ikut di dalam APK-nya, tinggal install.", color = Color(0xFFC4CACE), fontSize = 15.sp) },
        confirmButton = {
            TextButton(onClick = {
                Updater.pending.value = null
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(info.url))) } catch (_: Throwable) {}
            }) { Text("Download", color = Color(0xFF8E86F0), fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
        },
        dismissButton = {
            TextButton(onClick = { Updater.pending.value = null }) {
                Text("Nanti", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp)
            }
        }
    )
}
