package id.wuwaconfig

import android.content.Context
import android.view.WindowManager
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * Downscale resolusi game: game dirender di resolusi lebih rendah (GPU lebih ringan, HP lebih dingin),
 * sementara layar HP dan aplikasi lain tidak berubah. Memakai Game Manager Android 13+ lewat Shizuku/root.
 */
object Downscale {
    const val OFF_INDEX = 13                       // 0..12 = 0.30x..0.90x, 13 = Off
    val STEPS: List<Float> = (0..12).map { 0.30f + 0.05f * it }
    val PRESETS = listOf(480, 500, 600, 720, 800, 900, 1080)
    val busy = mutableStateOf(false)
    val status = mutableStateOf<String?>(null)

    /** Sisi pendek layar fisik (mis. 1220 untuk layar 1220x2712): dasar hitungan resolusi game. */
    fun shortSide(ctx: Context): Int {
        val b = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
        return minOf(b.width(), b.height())
    }

    fun saved(ctx: Context): Float? =
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getFloat("downscale_ratio", -1f).takeIf { it > 0f }

    private fun save(ctx: Context, r: Float?) {
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putFloat("downscale_ratio", r ?: -1f).apply()
    }

    fun indexOf(r: Float?): Int = if (r == null) OFF_INDEX else STEPS.indices.minByOrNull { kotlin.math.abs(STEPS[it] - r) } ?: OFF_INDEX

    fun label(short: Int, r: Float?): String =
        if (r == null) "Normal (tanpa downscale)" else "${String.format(java.util.Locale.US, "%.2f", r)}x • ${(short * r).roundToInt()}p"

    /** Terapkan ke game. [r] null = reset. Hasilnya muncul di [status]. */
    fun apply(ctx: Context, scope: CoroutineScope, r: Float?) {
        if (busy.value) return
        ShizukuShell.refresh()
        when (ShizukuShell.status.value) {
            0 -> { status.value = when { ShizukuShell.isRoot() -> "Root tidak tersedia di perangkat ini."; ShizukuShell.isAdb() -> "Wireless ADB belum terhubung."; else -> "Shizuku belum berjalan. Nyalakan dulu Shizuku." }; return }
            1 -> { ShizukuShell.requestPermission(); status.value = "Izinkan akses dulu, lalu coba lagi."; return }
        }
        val pkg = ShizukuShell.installedPackage(ctx) ?: run { status.value = "Wuthering Waves tidak ditemukan."; return }
        busy.value = true; status.value = "Menerapkan…"
        scope.launch {
            val err = withContext(Dispatchers.IO) { ShizukuShell.downscale(pkg, r) }
            busy.value = false
            if (err == null) {
                save(ctx, r)
                status.value = if (r == null) "Dikembalikan ke normal. Tutup game sepenuhnya lalu buka lagi supaya perubahan terlihat."
                else "Diterapkan: ${label(shortSide(ctx), r)}. Tutup game sepenuhnya lalu buka lagi supaya perubahan terlihat."
            } else status.value = err
        }
    }
}

@Composable private fun ResOption(title: String, sub: String, sel: Boolean, ac: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(if (sel) ac else Color(0xFF1E1E26))
        .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), color = if (sel) Color.White else Color(0xFFC5CAF5), fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(sub, color = if (sel) Color.White.copy(0.85f) else Color(0xFF8A8FB5), fontSize = 12.sp)
    }
}

@Composable fun DownscaleCard(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val short = remember { Downscale.shortSide(ctx) }
    var ratio by remember { mutableStateOf(Downscale.saved(ctx)) }
    var showPicker by remember { mutableStateOf(false) }
    val busy = Downscale.busy.value
    val sdk = android.os.Build.VERSION.SDK_INT
    val st = Downscale.status.value
    val shape = RoundedCornerShape(18.dp)
    val on = ratio != null
    // Kartu cuma satu baris. Pilihan resolusi muncul sebagai popup daftar saat diketuk.
    Column(Modifier.fillMaxWidth().clip(shape).background(CARD).border(1.dp, Color.White.copy(0.08f), shape)) {
        Row(Modifier.fillMaxWidth().clickable(enabled = !busy) { showPicker = true }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.AspectRatio, null, tint = C_BLUE, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Resolusi game", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
            Spacer(Modifier.weight(1f))
            Text(if (on) "${(short * (ratio ?: 1f)).roundToInt()}p" else "Normal",
                Modifier.clip(RoundedCornerShape(12.dp)).background(if (on) ac.copy(alpha = 0.85f) else CHIP).padding(horizontal = 10.dp, vertical = 4.dp),
                color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1)
            if (on) {
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Outlined.RestartAlt, "Reset", tint = Color.White.copy(alpha = if (busy) 0.4f else 1f),
                    modifier = Modifier.size(28.dp).clip(CircleShape).background(CHIP)
                        .clickable(enabled = !busy) { ratio = null; Downscale.apply(ctx, scope, null) }.padding(5.dp))
            }
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Outlined.ChevronRight, null, tint = Color.White.copy(0.8f), modifier = Modifier.size(20.dp))
        }
        val note = st ?: if (sdk < 33) "HP ini butuh Android 13 atau lebih baru." else null
        if (note != null) Text(note, Modifier.padding(start = 14.dp, end = 14.dp, bottom = 8.dp),
            color = Color.White.copy(0.85f), fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2)
    }
    if (showPicker) Dialog(onDismissRequest = { showPicker = false }) {
        Column(Modifier.clip(RoundedCornerShape(28.dp)).background(Color(0xFF101015)).padding(16.dp)) {
            Text("Resolusi game", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("Hanya tampilan game yang berubah, layar HP tidak.", Modifier.padding(top = 2.dp, bottom = 12.dp),
                color = Color(0xFF8A8FB5), fontSize = 12.sp, lineHeight = 15.sp)
            LazyColumn(Modifier.heightIn(max = 460.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    ResOption("Normal", "tanpa downscale", ratio == null, ac) {
                        showPicker = false
                        if (ratio != null) { ratio = null; Downscale.apply(ctx, scope, null) }
                    }
                }
                items(Downscale.PRESETS.filter { it.toFloat() / short in 0.30f..0.90f }.reversed()) { h ->
                    val r = h.toFloat() / short
                    val sel = ratio != null && kotlin.math.abs((ratio ?: 0f) * short - h) < 1f
                    ResOption("${h}p", String.format(java.util.Locale.US, "%.2fx", r), sel, ac) {
                        showPicker = false
                        if (!sel) { ratio = r; Downscale.apply(ctx, scope, r) }
                    }
                }
            }
        }
    }
}
