package id.wuwaconfig

import android.content.Context
import android.view.WindowManager
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * Downscale resolusi game: game dirender di resolusi lebih rendah (GPU lebih ringan, HP lebih dingin),
 * sementara layar HP dan aplikasi lain tidak berubah. Memakai Game Manager Android 13+ lewat Shizuku/root.
 */
object Downscale {
    const val OFF_INDEX = 13                       // 0..12 = 0.30x..0.90x, 13 = Off
    val STEPS: List<Float> = (0..12).map { 0.30f + 0.05f * it }
    val PRESETS = listOf(360, 480, 540, 720, 900, 1080)
    val busy = mutableStateOf(false)
    val status = mutableStateOf<String?>(null)

    /** Sisi pendek layar fisik (mis. 1220 untuk layar 1220x2712): dasar hitungan resolusi game. */
    fun shortSide(ctx: Context): Int {
        val b = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
        return minOf(b.width(), b.height())
    }

    fun saved(ctx: Context): Float? =
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getFloat("downscale_ratio", -1f).takeIf { it > 0f }

    private fun save(ctx: Context, r: Float?) {
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putFloat("downscale_ratio", r ?: -1f).apply()
    }

    fun indexOf(r: Float?): Int = if (r == null) OFF_INDEX else STEPS.indices.minByOrNull { kotlin.math.abs(STEPS[it] - r) } ?: OFF_INDEX

    fun label(short: Int, r: Float?): String =
        if (r == null) "Normal (tanpa downscale)" else "${String.format(java.util.Locale.US, "%.2f", r)}x • ${(short * r).roundToInt()}p"

    /** Terapkan ke game. [r] null = reset. Hasilnya muncul di [status]. */
    fun apply(ctx: Context, scope: CoroutineScope, r: Float?) {
        if (busy.value) return
        ShizukuShell.refresh()
        when (ShizukuShell.status.value) {
            0 -> { status.value = when { ShizukuShell.isRoot() -> "Root tidak tersedia di perangkat ini."; ShizukuShell.isAdb() -> "Wireless ADB belum terhubung."; else -> "Shizuku belum berjalan. Nyalakan dulu Shizuku." }; return }
            1 -> { ShizukuShell.requestPermission(); status.value = "Izinkan akses dulu, lalu coba lagi."; return }
        }
        val pkg = ShizukuShell.installedPackage(ctx) ?: run { status.value = "Wuthering Waves tidak ditemukan."; return }
        busy.value = true; status.value = "Menerapkan…"
        scope.launch {
            val err = withContext(Dispatchers.IO) { ShizukuShell.downscale(pkg, r) }
            busy.value = false
            if (err == null) {
                save(ctx, r)
                status.value = if (r == null) "Dikembalikan ke resolusi normal. Restart game agar berlaku."
                else "Diterapkan: ${label(shortSide(ctx), r)}. Restart game agar berlaku."
            } else status.value = err
        }
    }
}

@Composable fun DownscaleCard(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val short = remember { Downscale.shortSide(ctx) }
    var ratio by remember { mutableStateOf(Downscale.saved(ctx)) }
    val busy = Downscale.busy.value
    val sdk = android.os.Build.VERSION.SDK_INT
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD).padding(horizontal = 14.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.AspectRatio, null, tint = C_BLUE, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Resolusi game", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(Downscale.label(short, ratio), color = Color.White, fontSize = 12.sp)
            }
            Btn("Reset", ac, Modifier, enabled = !busy && ratio != null) { ratio = null; Downscale.apply(ctx, scope, null) }
        }
        Slider(
            value = Downscale.indexOf(ratio).toFloat(),
            onValueChange = { v -> val i = v.roundToInt(); ratio = if (i >= Downscale.OFF_INDEX) null else Downscale.STEPS[i] },
            onValueChangeFinished = { Downscale.apply(ctx, scope, ratio) },
            valueRange = 0f..Downscale.OFF_INDEX.toFloat(), steps = Downscale.OFF_INDEX - 1,
            enabled = !busy,
            colors = SliderDefaults.colors(thumbColor = ac, activeTrackColor = ac, inactiveTrackColor = Color.White.copy(alpha = 0.25f))
        )
        val chips = Downscale.PRESETS.filter { it.toFloat() / short in 0.30f..0.90f }
        if (chips.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            chips.forEach { h ->
                val r = h.toFloat() / short
                val sel = ratio != null && kotlin.math.abs((ratio ?: 0f) * short - h) < 1f
                Text("${h}p", Modifier.clip(RoundedCornerShape(14.dp)).background(if (sel) ac else CHIP)
                    .clickable(enabled = !busy) { ratio = r; Downscale.apply(ctx, scope, r) }
                    .padding(horizontal = 14.dp, vertical = 8.dp), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
        val st = Downscale.status.value
        val note = st ?: if (sdk < 33) "HP ini butuh Android 13 atau lebih baru." else "Geser lalu lepas untuk menerapkan. Layar HP tidak berubah, hanya game."
        Text(note, Modifier.padding(top = 8.dp), color = Color.White, fontSize = 12.sp)
    }
}
