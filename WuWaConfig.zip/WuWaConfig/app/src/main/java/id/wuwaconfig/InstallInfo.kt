package id.wuwaconfig

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import java.util.Calendar
import java.util.Locale

/**
 * Catatan aksi terakhir (pasang / hapus config) supaya Beranda dan Edit bisa menampilkan
 * config apa yang sedang dipakai dan apakah pemasangannya berhasil. Disimpan di prefs, jadi tetap ada setelah aplikasi ditutup.
 */
object InstallInfo {
    /** kind = "install" atau "delete". [message] berisi pesan error kalau [ok] false. */
    class Rec(val kind: String, val label: String, val ok: Boolean, val message: String?, val time: Long)

    val rec = mutableStateOf<Rec?>(null)
    /** Daftar file config yang terakhir terlihat di folder game. null = belum pernah dicek. */
    val present = mutableStateOf<List<String>?>(null)

    private const val P = "install_info"

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        val kind = sp.getString("${P}_kind", null)
        if (kind != null) rec.value = Rec(kind, sp.getString("${P}_label", "") ?: "", sp.getBoolean("${P}_ok", false),
            sp.getString("${P}_msg", null), sp.getLong("${P}_time", 0L))
        present.value = sp.getString("${P}_present", null)?.let { s -> if (s.isEmpty()) emptyList() else s.split(",") }
    }

    fun save(ctx: Context, r: Rec) {
        rec.value = r
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit()
            .putString("${P}_kind", r.kind).putString("${P}_label", r.label).putBoolean("${P}_ok", r.ok)
            .putString("${P}_msg", r.message).putLong("${P}_time", r.time).apply()
    }

    fun setPresent(ctx: Context, list: List<String>?) {
        present.value = list
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().apply {
            if (list == null) remove("${P}_present") else putString("${P}_present", list.joinToString(","))
        }.apply()
    }

    /** "Hari ini 18:29" atau "28 Okt 18:29". */
    fun fmtTime(t: Long): String {
        val now = Calendar.getInstance(); val c = Calendar.getInstance().apply { timeInMillis = t }
        val hm = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        val same = now.get(Calendar.YEAR) == c.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
        if (same) return "Hari ini $hm"
        val bln = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
        return "${c.get(Calendar.DAY_OF_MONTH)} ${bln[c.get(Calendar.MONTH)]} $hm"
    }
}
