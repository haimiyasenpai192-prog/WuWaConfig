package id.wuwaconfig

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

val ACCENTS = listOf(0xFF6B5FDB, 0xFF4A8BDB, 0xFF4AA37A, 0xFFC95A82, 0xFFD0663C, 0xFFB8802F).map { Color(it) }
val LocalPanelAlpha = compositionLocalOf { 0.9f }
class WallInfo(val bitmap: ImageBitmap?, val solid: Color, val dim: Float, val blur: Boolean)
val LocalWall = compositionLocalOf { WallInfo(null, Color.Black, 0f, false) }
@Composable fun panelColor(): Color = Color(0xFF101015).copy(alpha = LocalPanelAlpha.current)
/** Kartu & tombol dibuat setengah transparan (gaya kaca) supaya wallpaper tetap terlihat di belakangnya. */
val CHIP = Color(0xFF1A1A22).copy(alpha = 0.5f)
val CARD = Color(0xFF101016).copy(alpha = 0.5f)
val C_BLUE = Color(0xFF5B9BE0)
val C_PURPLE = Color(0xFF8E86F0)
val C_PINK = Color(0xFFF08FB8)
val C_YELLOW = Color(0xFFE8B84A)
val C_GREEN = Color(0xFF5CC98A)
const val CREATOR_URL ="https://discord.com/users/1426827460187656223"
const val DISCORD_URL = "https://discord.gg/EFaCxujTcC"

class MainActivity : ComponentActivity() {
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r -> ShizukuShell.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val binderListener = Shizuku.OnBinderReceivedListener { ShizukuShell.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { ShizukuShell.refresh() }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Layar penuh: konten digambar sampai belakang status bar & navigation bar (transparan).
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        super.onCreate(savedInstanceState)
        window.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        AppLog.init(this)
        ShizukuShell.init(this)
        InstallInfo.load(this)
        ShizukuShell.refresh()
        setContent { App() }
    }

    override fun onResume() { super.onResume(); ShizukuShell.refresh() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

fun decodeSharp(open: () -> java.io.InputStream?): ImageBitmap? {
    val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open()?.use { BitmapFactory.decodeStream(it, null, b) }
    var sample = 1
    val big = maxOf(b.outWidth, b.outHeight)
    while (big / (sample * 2) >= 2600) sample *= 2
    return open()?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }?.asImageBitmap()
}

fun makeThumb(src: ImageBitmap): ImageBitmap {
    var b = src.asAndroidBitmap()
    while (b.width >= 1440) b = android.graphics.Bitmap.createScaledBitmap(b, b.width / 2, b.height / 2, true)
    if (b.width > 720) b = android.graphics.Bitmap.createScaledBitmap(b, 720, 720 * b.height / b.width, true)
    return b.asImageBitmap()
}

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

@Composable
fun App() {
    val ctx = LocalContext.current
    val dens = LocalDensity.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var accent by remember { mutableStateOf(prefs.getInt("accent", 0)) }
    // Wallpaper bawaan: taruh gambar di app/src/main/assets/wallpaper_default.jpg (opsional).
    val defaultWall = remember {
        try { decodeSharp { ctx.assets.open("wallpaper_default.jpg") } } catch (_: Exception) { null }
    }
    var wall by remember { mutableStateOf(prefs.getInt("wall", if (defaultWall != null) 1 else 0)) } // 0 tanpa,1 gambar,2 ungu,3 biru
    var dim by remember { mutableStateOf(prefs.getFloat("dim", 0f)) }
    var trans by remember { mutableStateOf(prefs.getFloat("trans", 0.1f)) }
    var blurOn by remember { mutableStateOf(prefs.getBoolean("blur", false)) }
    val wallFile = File(ctx.filesDir, "wallpaper.jpg")
    var wallVersion by remember { mutableStateOf(0) }
    val ac = ACCENTS[accent]

    val pickWall = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ctx.contentResolver.openInputStream(uri)?.use { i -> wallFile.outputStream().use { o -> i.copyTo(o) } }
            wall = 1; prefs.edit().putInt("wall", 1).apply(); wallVersion++
        }
    }
    val wallBitmap = remember(wallVersion, wall) {
        if (wall != 1) null
        else if (wallFile.exists()) decodeSharp { wallFile.inputStream() }
        else defaultWall
    }

    CompositionLocalProvider(LocalDensity provides Density(dens.density, minOf(dens.fontScale, 1f)), LocalPanelAlpha provides (1f - trans),
        LocalWall provides WallInfo(wallBitmap, when (wall) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); else -> Color.Black }, dim, blurOn)) {
    MaterialTheme(colorScheme = darkColorScheme(primary = ac)) {
        Box(Modifier.fillMaxSize().background(when (wall) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); else -> Color.Black })) {
            if (wallBitmap != null) {
                Image(wallBitmap, null, Modifier.fillMaxSize().then(if (blurOn) Modifier.blur(16.dp) else Modifier),
                    contentScale = ContentScale.Crop, filterQuality = FilterQuality.High)
            }
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            Column(Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -150f && tab < 3) tab++ else if (total > 150f && tab > 0) tab-- },
                        onHorizontalDrag = { _, d -> total += d })
                }
                .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
                val heads = listOf(
                    "Wave Config" to "Pilih, lalu install config", "Edit" to "Tulis atau tempel tweak config.",
                    "Tampilan" to "Atur warna dan wallpaper.", "Settings" to "Atur akses dan aplikasi.")
                val shadow = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(0.6f), Offset(0f, 3f), 10f))
                val headFade = fadeIn(tween(260)) togetherWith fadeOut(tween(140))
                Column(Modifier.padding(top = 12.dp).fillMaxWidth()) {
                    // Chip Shizuku sejajar dengan baris judul (tengah vertikalnya sama dengan teks judul).
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        AnimatedContent(targetState = tab, label = "judul", modifier = Modifier.weight(1f),
                            transitionSpec = { headFade }) { t ->
                            Text(heads[t].first, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White, style = shadow)
                        }
                        AnimatedVisibility(visible = tab == 0, enter = fadeIn(tween(250)), exit = fadeOut(tween(150))) { StatusChip() }
                    }
                    AnimatedContent(targetState = tab, label = "subjudul", transitionSpec = { headFade }) { t ->
                        Text(heads[t].second, fontSize = 13.sp, color = Color.White.copy(0.85f), style = shadow)
                    }
                }
                Spacer(Modifier.weight(1f))
                Panel {
                    AnimatedContent(targetState = tab, label = "tab",
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (slideInHorizontally(tween(340)) { it * dir / 3 } + fadeIn(tween(340))) togetherWith
                                (slideOutHorizontally(tween(340)) { -it * dir / 3 } + fadeOut(tween(160)))
                        }) { t ->
                    Column(Modifier.fillMaxWidth()) {
                    when (t) {
                        0 -> Home(ac)
                        1 -> Editor(ac)
                        2 -> Look(ac, accent, { accent = it; prefs.edit().putInt("accent", it).apply() },
                            wall, { w -> if (w == 1 && !wallFile.exists() && defaultWall == null) pickWall.launch("image/*") else if (w == 1) { wall = 1; prefs.edit().putInt("wall", 1).apply() } else { wall = w; prefs.edit().putInt("wall", w).apply() } },
                            { pickWall.launch("image/*") }, dim, { dim = it; prefs.edit().putFloat("dim", it).apply() },
                            blurOn, { blurOn = it; prefs.edit().putBoolean("blur", it).apply() }, wallBitmap,
                            trans, { trans = it; prefs.edit().putFloat("trans", it).apply() })
                        else -> SettingsTab(ac)
                    }
                    }
                    }
                }
                // Jarak panel ke navigasi dibuat kecil supaya kotak hitam menempel dekat navbar.
                Spacer(Modifier.height(4.dp))
                NavBar(tab, ac) { tab = it }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
    }
}

@Composable fun Panel(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(panelColor()).animateContentSize(tween(300)).padding(9.dp), content = content)

@Composable fun StatusChip() {
    val s = ShizukuShell.status.value
    val name = ShizukuShell.modeName()
    val (txt, col) = when (s) { 2 -> name to Color(0xFF5BD68E); 1 -> "Izinkan" to Color(0xFFE0B040); else -> "$name off" to Color(0xFFE06060) }
    Row(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(col)); Spacer(Modifier.width(6.dp))
        Text(txt, color = col, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable fun NavBar(sel: Int, ac: Color, onSel: (Int) -> Unit) {
    val items = listOf("Beranda" to Icons.Outlined.Home, "Edit" to Icons.Outlined.Edit, "Tampilan" to Icons.Outlined.Palette, "Settings" to Icons.Outlined.Settings)
    val navColors = listOf(Color(0xFF8AB4F8), Color(0xFF7CCFA4), Color(0xFFF08FB8), Color(0xFFE8B84A))
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(panelColor()).padding(5.dp)) {
        items.forEachIndexed { i, (n, ic) ->
            val on = i == sel
            val nc = navColors[i]
            val bgc by animateColorAsState(if (on) nc.copy(alpha = 0.16f) else Color.Transparent, tween(260), label = "navbg")
            val tint by animateColorAsState(if (on) nc else Color.Gray, tween(260), label = "navtint")
            val sc by animateFloatAsState(if (on) 1.18f else 1f, spring(dampingRatio = 0.45f, stiffness = 380f), label = "navscale")
            Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                .background(bgc)
                .clickable { onSel(i) }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(ic, n, tint = tint, modifier = Modifier.size(22.dp).graphicsLayer(scaleX = sc, scaleY = sc))
                Text(n, fontSize = 11.sp, color = tint)
            }
        }
    }
}

@Composable fun Btn(text: String, ac: Color, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true,
                    icon: ImageVector? = null, iconTint: Color = Color.White, brush: Brush? = null, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(20.dp)).then(if (filled && brush != null) Modifier.background(brush) else Modifier.background(if (filled) ac else CHIP)).alpha(if (enabled) 1f else 0.4f)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 8.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) { Icon(icon, null, tint = iconTint, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = if (filled) 17.sp else 13.sp,
                maxLines = 2, textAlign = TextAlign.Center, lineHeight = if (filled) 22.sp else 16.sp)
        }
    }
}

/**
 * Pastikan Shizuku siap & game terpasang; panggil aksi di thread IO.
 * [infoLabel] (kalau diisi) dicatat ke [InstallInfo] sebagai config yang dipakai beserta hasilnya (berhasil / gagal).
 */
fun runWithGame(ctx: Context, scope: kotlinx.coroutines.CoroutineScope, notifyLabel: String? = null,
                kind: String = "install", infoLabel: String? = null, detail: List<String>? = null, block: (String) -> String?) {
    fun fail(msg: String) {
        AppLog.e("Aksi", "${infoLabel ?: kind} gagal sebelum mulai: $msg")
        toast(ctx, msg)
        if (infoLabel != null) {
            InstallInfo.report.value = null; InstallInfo.dex.value = null; InstallInfo.recVisible.value = true
            InstallInfo.save(ctx, InstallInfo.Rec(kind, infoLabel, false, msg, System.currentTimeMillis()))
        }
    }
    AppLog.i("Aksi", "Mulai ${when (kind) { "delete" -> "hapus"; "dex2oat" -> "dex2oat"; "bersih" -> "bersih"; else -> "pasang" }}: ${infoLabel ?: "-"} | akses=${ShizukuShell.modeName()}")
    ShizukuShell.refresh()
    when (ShizukuShell.status.value) {
        0 -> { fail(when { ShizukuShell.isRoot() -> "Root tidak tersedia di perangkat ini."; ShizukuShell.isAdb() -> "Wireless ADB belum terhubung."; else -> "Shizuku belum berjalan. Nyalakan dulu Shizuku." }); return }
        1 -> { ShizukuShell.requestPermission(); fail(when { ShizukuShell.isRoot() -> "Izinkan akses root, lalu coba lagi."; ShizukuShell.isAdb() -> "Menyambung ke Wireless Debugging… coba lagi sebentar lagi. Kalau tetap gagal, pairing ulang."; else -> "Izinkan akses Shizuku, lalu coba lagi." }); return }
    }
    val pkg = ShizukuShell.installedPackage(ctx) ?: run { fail("Wuthering Waves tidak ditemukan."); return }
    scope.launch {
        if (infoLabel != null) { InstallInfo.detail.value = detail ?: emptyList(); InstallInfo.busy.value = true; InstallInfo.report.value = null; InstallInfo.dex.value = null; InstallInfo.recVisible.value = true }
        ShizukuShell.lastFailedFile = null
        val err = withContext(Dispatchers.IO) {
            val r = block(pkg)
            // Gagal: kumpulkan diagnosa otomatis ke log supaya penyebabnya bisa dilihat.
            if (r != null) ShizukuShell.diagnose(pkg, ShizukuShell.lastFailedFile)
            r
        }
        if (err == null) AppLog.i("Aksi", "Selesai: ${infoLabel ?: kind} BERHASIL ($pkg)")
        else AppLog.e("Aksi", "Selesai: ${infoLabel ?: kind} GAGAL ($pkg) -> $err")
        toast(ctx, err?.let { "Gagal: $it\nBuka Settings > Log untuk detail." } ?: when (kind) {
            "delete" -> "Berhasil menghapus config."
            "dex2oat" -> "DEX2OAT selesai."
            "bersih" -> "Selesai."
            else -> "Berhasil. Buka game untuk mencoba."
        })
        if (err == null && notifyLabel != null) Notifier.installed(ctx, notifyLabel)
        if (infoLabel != null) {
            InstallInfo.save(ctx, InstallInfo.Rec(kind, infoLabel, err == null, err, System.currentTimeMillis()))
            InstallInfo.setPresent(ctx, withContext(Dispatchers.IO) { ShizukuShell.existing(pkg) })
        }
        InstallInfo.busy.value = false
    }
}

private fun cfgValidity(t: String?): String = when {
    t == null -> "MISSING"
    t.isBlank() -> "EMPTY"
    Regex("(?m)^\\s*\\[[^\\]]+\\]").containsMatchIn(t) -> "VALID"
    else -> "INVALID"
}

/** Cari baris "Kunci: nilai" / "Kunci = nilai" (boleh di dalam komentar ; # //) di bagian atas file. */
private fun cfgHeader(texts: List<String?>, key: String): String? {
    val re = Regex("^[;#/\\s]*(?:Config\\s*)?$key\\s*[:=]\\s*(.+)$", RegexOption.IGNORE_CASE)
    for (t in texts) {
        if (t == null) continue
        t.lineSequence().take(80).forEach { l -> re.find(l.trim())?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }?.let { return it } }
    }
    return null
}


/** Cek file config di folder game, lalu susun laporan gaya terminal ke [InstallInfo.report]. */
fun runCheck(ctx: Context, scope: kotlinx.coroutines.CoroutineScope): Boolean {
    ShizukuShell.refresh()
    when (ShizukuShell.status.value) {
        0 -> { toast(ctx, when { ShizukuShell.isRoot() -> "Root tidak tersedia di perangkat ini."; ShizukuShell.isAdb() -> "Wireless ADB belum terhubung."; else -> "Shizuku belum berjalan. Nyalakan dulu Shizuku." }); return false }
        1 -> { ShizukuShell.requestPermission(); toast(ctx, "Izinkan akses dulu, lalu coba lagi."); return false }
    }
    val pkg = ShizukuShell.installedPackage(ctx) ?: run { toast(ctx, "Wuthering Waves tidak ditemukan."); return false }
    scope.launch {
        InstallInfo.recVisible.value = false; InstallInfo.dex.value = null
        InstallInfo.checking.value = true
        val f = withContext(Dispatchers.IO) { ShizukuShell.inspect(pkg) }
        InstallInfo.checking.value = false
        if (f == null) { InstallInfo.recVisible.value = true; toast(ctx, "Gagal membaca folder game. Buka Settings > Log."); return@launch }
        val files = listOf("DeviceProfiles.ini", "Engine.ini").map { it to cfgValidity(f[it]) }
        val src = listOf(f["Engine.ini"], f["DeviceProfiles.ini"], f["AndroidEngine.ini"])
        val r = InstallInfo.rec.value
        val applied = cfgHeader(src, "Applied") ?: r?.takeIf { it.kind == "install" && it.ok }?.label
        val gus = f["GameUserSettings.ini"]
        val rx = gus?.let { Regex("ResolutionSizeX\\s*=\\s*(\\d+)").find(it)?.groupValues?.get(1) }
        val ry = gus?.let { Regex("ResolutionSizeY\\s*=\\s*(\\d+)").find(it)?.groupValues?.get(1) }
        val bnd = (ctx.getSystemService(android.view.WindowManager::class.java)).maximumWindowMetrics.bounds
        val extra = mutableListOf<Pair<String, String>>()
        fun add(k: String, v: String?) { if (!v.isNullOrBlank()) extra += k to v }
        add("Config", applied)
        add("Layar", "${bnd.width()}x${bnd.height()} / ${ctx.resources.displayMetrics.densityDpi}")
        if (rx != null && ry != null) add("Resolusi game", "${rx}x${ry}")
        add("Tipe", cfgHeader(src, "Type"))
        add("Versi", cfgHeader(src, "Version"))
        add("Mode", cfgHeader(src, "Mode"))
        val out = InstallInfo.Report(files, extra)
        InstallInfo.report.value = out
        InstallInfo.checkTime.value = System.currentTimeMillis()
        InstallInfo.setPresent(ctx, Presets.ALL_FILES.filter { cfgValidity(f[it]) != "MISSING" })
    }
    return true
}

/** Kotak hasil Cek status (desain daftar rapi): ringkasan, daftar file dengan label, lalu info config dan layar. */
@Composable fun CheckCard(hideEmpty: Boolean = false) {
    val rep = InstallInfo.report.value
    val busy = InstallInfo.checking.value
    if (rep == null && !busy) {
        // Belum dicek: kotak kosong, tanpa teks apa pun (disembunyikan kalau kartu DEX2OAT sedang tampil).
        if (!hideEmpty) Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(18.dp)).background(CARD)
            .border(1.dp, Color.White.copy(0.08f), RoundedCornerShape(18.dp)))
        return
    }
    val green = Color(0xFF5BD68E); val red = Color(0xFFE06060); val yellow = Color(0xFFE8B84A)
    val valid = rep?.files?.count { it.second == "VALID" } ?: 0
    val total = rep?.files?.size ?: 0
    val (title, tint, icon) = when {
        busy -> Triple("Mengecek config\u2026", C_BLUE, Icons.Outlined.Sync)
        total > 0 && valid == total -> Triple("Config sudah terpasang", green, Icons.Outlined.CheckCircle)
        valid == 0 -> Triple("Config belum terpasang", red, Icons.Outlined.ErrorOutline)
        else -> Triple("Config terpasang sebagian", yellow, Icons.Outlined.Info)
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD)
        .border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (busy) CircularProgressIndicator(color = tint, strokeWidth = 2.5.dp, modifier = Modifier.size(24.dp))
            else Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                if (!busy) Text("Dicek " + InstallInfo.fmtTime(InstallInfo.checkTime.value), color = Color(0xFF9AA0A6), fontSize = 12.sp)
            }
        }
        if (!busy && rep != null) {
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.08f)))
            rep.files.forEach { (n, st) ->
                val c = when (st) { "VALID" -> green; "MISSING" -> red; else -> yellow }
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f), color = Color(0xFFC4CACE), fontSize = 13.sp)
                    Text(st, color = c, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(c.copy(alpha = 0.16f)).padding(horizontal = 9.dp, vertical = 3.dp))
                }
            }
            if (rep.extra.isNotEmpty()) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.08f)))
                Spacer(Modifier.height(8.dp))
                rep.extra.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        row.forEach { (k, v) ->
                            Column(Modifier.weight(1f)) {
                                Text(k, color = Color(0xFF888888), fontSize = 12.sp)
                                Text(v, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

/** Kotak hasil DEX2OAT: sedang mengompilasi / selesai / gagal, beserta mode dan status kompilasi game. */
@Composable fun DexCard() {
    val r = InstallInfo.dex.value
    val busy = InstallInfo.dexBusy.value
    if (r == null && !busy) return
    var logDlg by remember { mutableStateOf(false) }
    if (logDlg) LogDialog { logDlg = false }
    val green = Color(0xFF5BD68E); val red = Color(0xFFE06060)
    val tint = when { busy -> C_BLUE; r != null && r.ok -> green; else -> red }
    val task = r?.task ?: InstallInfo.dexTask.value
    val title = when { busy -> if (task == "DEX2OAT") "Mengompilasi DEX2OAT\u2026" else "$task\u2026"; r!!.ok -> "$task selesai"; else -> "$task gagal" }
    val sub = when { busy -> if (task == "DEX2OAT") "Jangan tutup aplikasi, bisa beberapa menit" else "Sebentar\u2026"; r!!.ok -> InstallInfo.fmtTime(r.time); else -> r.message ?: "" }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD)
        .border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (busy) CircularProgressIndicator(color = tint, strokeWidth = 2.5.dp, modifier = Modifier.size(24.dp))
            else Icon(if (r!!.ok) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline, null, tint = tint, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                if (sub.isNotEmpty()) Text(sub, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            if (!busy && r != null && !r.ok) {
                Icon(Icons.Outlined.Description, "Lihat log", tint = C_YELLOW,
                    modifier = Modifier.size(34.dp).clip(CircleShape).clickable { logDlg = true }.padding(6.dp))
            }
        }
        if (!busy && r != null && r.ok) {
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.08f)))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(r.modeLabel, color = Color(0xFF888888), fontSize = 12.sp)
                    Text(r.mode, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column(Modifier.weight(1f)) {
                    Text(r.statusLabel, color = Color(0xFF888888), fontSize = 12.sp)
                    Text(r.status ?: "tidak terbaca", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

/** Kotak hasil di bawah tombol Install: sedang memasang / berhasil / gagal / dihapus, lengkap dengan daftar file. */
@Composable fun ResultCard(bare: Boolean = false) {
    val r = InstallInfo.rec.value
    val busy = InstallInfo.busy.value
    if (r == null && !busy) return
    var logDlg by remember { mutableStateOf(false) }
    if (logDlg) LogDialog { logDlg = false }
    val green = Color(0xFF5BD68E); val red = Color(0xFFE06060)
    val deleted = r != null && r.kind == "delete"
    val tint = when { busy -> C_BLUE; r == null -> Color.Gray; deleted -> red; r.ok -> green; else -> red }
    val icon = when { busy -> Icons.Outlined.Sync; deleted && r!!.ok -> Icons.Outlined.Delete; r!!.ok -> Icons.Outlined.CheckCircle; else -> Icons.Outlined.ErrorOutline }
    val title = when {
        busy -> "Memasang config\u2026"
        deleted -> if (r!!.ok) "Config dihapus" else "Gagal menghapus config"
        r!!.ok -> "Config berhasil terpasang"
        else -> "Gagal memasang config"
    }
    val sub = when {
        busy -> "Jangan tutup aplikasi"
        r != null && !r.ok -> r.message
        r != null -> r.label + " \u00B7 " + InstallInfo.fmtTime(r.time)
        else -> null
    }
    val files = InstallInfo.detail.value
    // bare = true: dipakai di dalam kotak besar Beranda, jadi tanpa latar & garis tepi sendiri.
    val cardMod = if (bare) Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)
        else Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD)
            .border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
    Column(cardMod, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (busy) CircularProgressIndicator(color = tint, strokeWidth = 2.5.dp, modifier = Modifier.size(22.dp))
            else Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                if (!sub.isNullOrEmpty()) Text(sub, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            if (!busy && r != null && !r.ok) {
                Icon(Icons.Outlined.Description, "Lihat log", tint = C_YELLOW,
                    modifier = Modifier.size(34.dp).clip(CircleShape).clickable { logDlg = true }.padding(6.dp))
            }
        }
        if (files.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.08f)))
            files.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (busy) Icons.Outlined.Schedule else if (r != null && r.ok) Icons.Outlined.Check else Icons.Outlined.Close,
                        null, tint = tint, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(f, color = Color(0xFFC4CACE), fontSize = 13.sp)
                }
            }
        }
    }
}

/** Kartu status simpel: satu baris, config yang terakhir dipasang + waktu. Ketuk untuk cek ulang file di game. */
@Composable fun InfoCard(extra: String = "", trailing: @Composable RowScope.() -> Unit = {}) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val r = InstallInfo.rec.value
    var logDlg by remember { mutableStateOf(false) }
    if (logDlg) LogDialog { logDlg = false }
    val green = Color(0xFF5BD68E); val red = Color(0xFFE06060)
    // Hijau hanya untuk config berhasil dipasang. Config dihapus (berhasil maupun gagal) dan error lain = merah.
    val removed = r != null && r.kind == "delete" && r.ok
    val tint = when { r == null -> Color.Gray; removed -> red; r.ok -> green; else -> red }
    val icon = when { r == null -> Icons.Outlined.Info; removed -> Icons.Outlined.Delete; r.ok -> Icons.Outlined.CheckCircle; else -> Icons.Outlined.ErrorOutline }
    val title = when {
        r == null -> "Belum ada config terpasang"
        r.kind == "delete" -> if (r.ok) "Config dihapus" else "Gagal menghapus"
        r.ok -> "Config terpasang"
        else -> "Gagal memasang"
    }
    val sub = when {
        r == null -> null
        !r.ok -> r.message
        else -> InstallInfo.fmtTime(r.time) + if (extra.isNotEmpty()) " \u00B7 $extra" else ""
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
            .clickable {
                ShizukuShell.refresh()
                if (ShizukuShell.status.value != 2) { toast(ctx, "Hubungkan Shizuku atau Root dulu untuk mengecek."); return@clickable }
                val pkg = ShizukuShell.installedPackage(ctx) ?: run { toast(ctx, "Wuthering Waves tidak ditemukan."); return@clickable }
                scope.launch {
                    val list = withContext(Dispatchers.IO) { ShizukuShell.existing(pkg) }
                    InstallInfo.setPresent(ctx, list)
                    toast(ctx, if (list == null) "Gagal membaca folder game." else "Status diperbarui.")
                }
            }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                if (!sub.isNullOrEmpty()) Text(sub, color = Color(0xFF9AA0A6), fontSize = 11.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            // Pemasangan gagal: tombol pintas ke log supaya penyebabnya bisa dicek.
            if (r != null && !r.ok) {
                Icon(Icons.Outlined.Description, "Lihat log", tint = Color(0xFFE8B84A),
                    modifier = Modifier.padding(end = 4.dp).size(30.dp).clip(CircleShape).clickable { logDlg = true }.padding(6.dp))
            }
        }
        trailing()
    }
}

/** Layar log: lihat, salin, bagikan, atau hapus log aktivitas. Baris error merah, peringatan/diagnosa kuning. */
@Composable fun LogDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val ver = AppLog.version.value
    val raw = remember(ver) { AppLog.read() }
    val scroll = rememberScrollState()
    val red = Color(0xFFFF7B7B); val yellow = Color(0xFFE8B84A); val dim = Color(0xFF9AA0A6)
    val text = remember(raw) {
        buildAnnotatedString {
            if (raw.isBlank()) withStyle(SpanStyle(color = dim)) { append("Log masih kosong. Coba pasang config dulu, hasilnya akan tercatat di sini.") }
            else raw.lines().forEach { ln ->
                val col = when {
                    ln.contains(" E/") -> red
                    ln.contains(" W/") -> yellow
                    ln.startsWith("    ") -> yellow.copy(alpha = 0.85f)
                    else -> Color(0xFFC4CACE)
                }
                withStyle(SpanStyle(color = col)) { append(ln); append('\n') }
            }
        }
    }
    LaunchedEffect(raw) { scroll.scrollTo(scroll.maxValue) }
    fun full() = AppLog.header(ctx) + "\n" + raw.ifBlank { "(log kosong)" }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF08080C)).statusBarsPadding().navigationBarsPadding().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Description, null, tint = C_YELLOW, modifier = Modifier.size(26.dp)); Spacer(Modifier.width(10.dp))
                Text("Log", Modifier.weight(1f), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Icon(Icons.Outlined.Close, "Tutup", tint = Color.Gray, modifier = Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onDismiss).padding(8.dp))
            }
            Text("Kalau pasang config gagal, salin atau bagikan log ini ke pembuat / komunitas.", color = dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CHIP).padding(10.dp)) {
                SelectionContainer {
                    Text(text, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp,
                        modifier = Modifier.fillMaxSize().verticalScroll(scroll))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Salin", C_BLUE, Modifier.weight(1f), icon = Icons.Outlined.ContentCopy, iconTint = C_BLUE) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Wave Config log", full()))
                    toast(ctx, "Log disalin.")
                }
                Btn("Bagikan", C_PURPLE, Modifier.weight(1f), icon = Icons.Outlined.Share, iconTint = C_PURPLE) {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "Wave Config log"); putExtra(Intent.EXTRA_TEXT, full()) }
                    try { ctx.startActivity(Intent.createChooser(i, "Bagikan log").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { toast(ctx, "Tidak bisa membagikan log.") }
                }
                Btn("Hapus", C_PINK, Modifier.weight(1f), icon = Icons.Outlined.DeleteSweep, iconTint = Color(0xFFFF6B6B)) {
                    AppLog.clear(); toast(ctx, "Log dihapus.")
                }
            }
        }
    }
}

@Composable fun Home(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("Flagship") }
    var tier by remember { mutableStateOf(0) }
    var cfgDlg by remember { mutableStateOf(false) }
    var cfg by remember { mutableStateOf(Presets.current(ctx)) }
    var cfgVersions by remember { mutableStateOf(Presets.versions(ctx)) }
    val modeless = Presets.modeless(ctx, cfg)
    val effMode = if (modeless) "Flagship" else mode
    val tierColor = if (!modeless && effMode == "Balanced") C_GREEN else if (!modeless) C_PINK else C_PURPLE
    val tierList = Presets.tiers(ctx, cfg, effMode)
    val ti = tier.coerceIn(0, maxOf(0, tierList.size - 1))
    var importDlg by remember { mutableStateOf(false) }
    var dexDlg by remember { mutableStateOf(false) }
    var cleanDlg by remember { mutableStateOf(false) }
    var delDlg by remember { mutableStateOf(false) }
    var dexNow by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(dexDlg) {
        if (dexDlg && ShizukuShell.status.value == 2) {
            dexNow = withContext(Dispatchers.IO) { ShizukuShell.installedPackage(ctx)?.let { ShizukuShell.dexStatus(it) } }
        }
    }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    val doImport: (Uri) -> Unit = { u ->
        val name = try {
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                val col = c.getColumnIndex("_display_name")
                if (col >= 0 && c.moveToFirst()) c.getString(col) else null
            }
        } catch (_: Exception) { null } ?: u.lastPathSegment?.substringAfterLast('/') ?: "config.zip"
        val err = Presets.importZip(ctx, u, name)
        if (err == null) AppLog.i("Impor", "Zip $name berhasil diimpor") else AppLog.e("Impor", "Zip $name gagal: $err")
        cfgVersions = Presets.versions(ctx); cfg = Presets.current(ctx); tier = 0
        toast(ctx, err ?: "${Presets.title(cfg)} diimpor dan dipilih.")
    }
    val importSystem = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) doImport(u) }
    val importOther = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.data?.let { doImport(it) }
    }
    if (importDlg) FileManagerDialog(
        onDismiss = { importDlg = false },
        onSystem = { importDlg = false; importSystem.launch(arrayOf("*/*")) },
        onOther = {
            importDlg = false
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            try { importOther.launch(Intent.createChooser(i, "Pilih file manager")) }
            catch (_: Exception) { toast(ctx, "Tidak ada file manager lain yang tersedia.") }
        })
    deleteTarget?.let { v ->
        val hasBundled = Presets.isBundled(ctx, v)
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Hapus config?", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
            text = {
                Text(
                    if (hasBundled) "${Presets.title(v)} hasil impor akan dihapus dan kembali ke versi bawaan aplikasi."
                    else "${Presets.title(v)} akan dihapus dari aplikasi. File zip aslinya di HP tidak ikut terhapus.",
                    color = Color(0xFFC4CACE), fontSize = 15.sp)
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = Presets.deleteImported(ctx, v)
                    cfgVersions = Presets.versions(ctx); cfg = Presets.current(ctx); tier = 0
                    deleteTarget = null
                    toast(ctx, if (ok) "${Presets.title(v)} dihapus." else "Gagal menghapus ${Presets.title(v)}.")
                }) { Text("Hapus", color = Color(0xFFFF6B6B), fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
        )
    }
    if (cfgDlg) AlertDialog(
        onDismissRequest = { cfgDlg = false },
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Pilih config", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (cfgVersions.isEmpty()) Text("Belum ada config. Impor zip untuk mulai.", color = Color(0xFF8A9096), fontSize = 14.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
                cfgVersions.reversed().forEach { v ->
                    val imported = Presets.isImported(ctx, v)
                    AccessOption(Presets.title(v), Presets.summary(ctx, v),
                        Icons.Outlined.Layers, ac, Color(0xFF13111F), v == cfg,
                        end = if (imported) ({
                            Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0x22FF6B6B))
                                .clickable { cfgDlg = false; deleteTarget = v }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Outlined.Delete, "Hapus ${Presets.title(v)}", tint = Color(0xFFFF6B6B), modifier = Modifier.size(22.dp))
                            }
                        }) else null) {
                        cfg = v; tier = 0; Presets.setCurrent(ctx, v); cfgDlg = false
                    }
                }
                Spacer(Modifier.height(2.dp))
                ImportCard { cfgDlg = false; importDlg = true }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { cfgDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
    )
    if (dexDlg) {
        val runDex: (String?, String) -> Unit = { m, label ->
            dexDlg = false
            runWithGame(ctx, scope, kind = "dex2oat") { pkg ->
                InstallInfo.dexTask.value = "DEX2OAT"
                InstallInfo.recVisible.value = false; InstallInfo.report.value = null
                InstallInfo.dexBusy.value = true
                try {
                    val err = ShizukuShell.dexopt(pkg, m)
                    InstallInfo.dex.value = InstallInfo.DexRec("DEX2OAT", label, err == null, err, ShizukuShell.dexStatus(pkg), System.currentTimeMillis())
                    err
                } finally { InstallInfo.dexBusy.value = false }
            }
            AppLog.i("DEX2OAT", "Dipilih: $label")
        }
        AlertDialog(
            onDismissRequest = { dexDlg = false },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("DEX2OAT", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Kompilasi ulang game supaya loading dan performa lebih stabil. Prosesnya bisa beberapa menit, jangan tutup aplikasi.",
                        color = Color(0xFFC4CACE), fontSize = 14.sp)
                    Text("Status sekarang: ${dexNow ?: "tidak diketahui"}", color = C_BLUE, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    AccessOption("Speed-profile", "Seimbang, disarankan.", Icons.Outlined.Speed, C_GREEN, Color(0xFF0F1A14), false) { runDex("speed-profile", "speed-profile") }
                    AccessOption("Speed", "Kompilasi penuh, lebih lama dan memakai lebih banyak ruang.", Icons.Outlined.Bolt, C_YELLOW, Color(0xFF17140C), false) { runDex("speed", "speed") }
                    AccessOption("Reset", "Hapus hasil kompilasi, kembali ke bawaan sistem.", Icons.Outlined.RestartAlt, Color(0xFFFF6B6B), Color(0xFF1A1010), false) { runDex(null, "reset") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dexDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
        )
    }
    if (delDlg) AlertDialog(
        onDismissRequest = { delDlg = false },
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Hapus config dari game?", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = { Text("Engine.ini, DeviceProfiles.ini, dan Scalability.ini di folder game akan dihapus, jadi game kembali ke pengaturan bawaan. GameUserSettings.ini tidak ikut dihapus.", color = Color(0xFFC4CACE), fontSize = 15.sp) },
        confirmButton = {
            TextButton(onClick = {
                delDlg = false
                runWithGame(ctx, scope, kind = "delete", infoLabel = "Hapus config", detail = Presets.REMOVABLE) { ShizukuShell.delete(it, Presets.REMOVABLE) }
            }) { Text("Hapus", color = Color(0xFFFF6B6B), fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
        },
        dismissButton = { TextButton(onClick = { delDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
    )
    if (cleanDlg) {
        val runClean: (String, String) -> Unit = { what, title ->
            cleanDlg = false
            runWithGame(ctx, scope, kind = "bersih") { pkg ->
                InstallInfo.dexTask.value = title
                InstallInfo.recVisible.value = false; InstallInfo.report.value = null
                InstallInfo.dexBusy.value = true
                try {
                    val (err, sum) = ShizukuShell.sweep(pkg, what)
                    InstallInfo.dex.value = InstallInfo.DexRec(title, title, err == null, err, sum, System.currentTimeMillis(), "Hasil", "Aksi")
                    err
                } finally { InstallInfo.dexBusy.value = false }
            }
        }
        AlertDialog(
            onDismissRequest = { cleanDlg = false },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Bersihkan", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pembersih ini hanya menyentuh folder data game dan tidak menghapus config.", color = Color(0xFFC4CACE), fontSize = 14.sp)
                    AccessOption("Hapus shader", "Hapus cache shader. Dibuat ulang otomatis saat game dibuka.", Icons.Outlined.AutoDelete, C_BLUE, Color(0xFF0F1420), false) { runClean("shader", "Hapus shader") }
                    AccessOption("Hapus laporan crash", "Hapus file laporan crash game untuk melegakan ruang.", Icons.Outlined.DeleteSweep, C_YELLOW, Color(0xFF17140C), false) { runClean("junk", "Hapus laporan crash") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { cleanDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
        )
    }
    val gantiBtn: @Composable RowScope.() -> Unit = {
        Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { cfgDlg = true }.padding(start = 8.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(if (cfg.isEmpty()) "Impor" else "Ganti", color = C_BLUE, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Icon(Icons.Outlined.ChevronRight, null, tint = C_BLUE, modifier = Modifier.size(18.dp))
        }
    }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!modeless) Column(Modifier.fillMaxHeight().width(56.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            ModeRailItem(Icons.Outlined.AutoAwesome, C_PINK, mode == "Flagship", Modifier.weight(1f)) { mode = "Flagship"; tier = 0 }
            ModeRailItem(Icons.Outlined.Eco, C_GREEN, mode == "Balanced", Modifier.weight(1f)) { mode = "Balanced"; tier = 0 }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val box = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CARD)
            val noTrail: @Composable RowScope.() -> Unit = {}
            if (modeless) Row(box.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Layers, null, tint = C_BLUE, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Config", fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                    Text(if (cfg.isEmpty()) "Belum ada" else Presets.displayName(cfg), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        color = if (cfg.isEmpty()) Color.Gray else Color.White, maxLines = 1)
                }
                gantiBtn()
            }
            val tierChips: @Composable (Modifier) -> Unit = { mod ->
                Row(mod.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (tierList.isEmpty()) Text("Tidak tersedia", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
                    tierList.forEachIndexed { i, q ->
                        Text(q.label, color = if (ti == i) Color(0xFF2A1520) else Color.Gray, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, maxLines = 1,
                            modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(if (ti == i) tierColor else Color(0xFF26262F))
                                .clickable { tier = i }.padding(horizontal = 9.dp, vertical = 6.dp))
                    }
                }
            }
            if (!modeless) Row(box.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(effMode, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                    Text(if (effMode == "Balanced") "Balanced stabil" else "Visual stabil", color = Color.Gray, fontSize = 11.sp, maxLines = 1)
                }
                Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { cfgDlg = true }.padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Layers, null, tint = C_BLUE, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp))
                    Column {
                        Text("Config", fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                        Text(if (cfg.isEmpty()) "Belum ada" else Presets.displayName(cfg), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            color = if (cfg.isEmpty()) Color.Gray else Color.White, maxLines = 1)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(if (cfg.isEmpty()) "Impor" else "Ganti", color = C_BLUE, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                    Icon(Icons.Outlined.ChevronRight, null, tint = C_BLUE, modifier = Modifier.size(18.dp))
                }
            }
            Row(box.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Outlined.Tune, null, tint = C_YELLOW, modifier = Modifier.size(20.dp))
                Text("Kualitas", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1)
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) { tierChips(Modifier) }
            }
        }
    }
    Spacer(Modifier.height(4.dp))
    Btn("Install", ac, Modifier.fillMaxWidth().heightIn(min = 46.dp), filled = true, brush = Brush.horizontalGradient(listOf(C_BLUE, C_PURPLE, C_PINK))) {
        if (cfg.isEmpty()) { toast(ctx, "Belum ada config. Ketuk kartu Config lalu Impor zip."); return@Btn }
        val files = Presets.files(ctx, cfg, effMode, ti)
        if (files == null) { toast(ctx, if (modeless) "Preset $cfg belum tersedia." else "Preset $cfg $mode belum tersedia."); return@Btn }
        val tierLabel = tierList[ti].label
        val info = if (modeless) "${Presets.displayName(cfg)} • $tierLabel" else "${Presets.displayName(cfg)} • $mode • $tierLabel"
        val shown = files.keys.filter { !it.equals("AndroidEngine.ini", ignoreCase = true) }
        runWithGame(ctx, scope, if (modeless) "${Presets.displayName(cfg)} $tierLabel" else "${Presets.displayName(cfg)} $mode $tierLabel", infoLabel = info, detail = shown) { pkg ->
            var err: String? = null
            for ((name, text) in files) { err = ShizukuShell.writeVerified(pkg, name, text) ?: err }
            err
        }
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Btn("Cek status", ac, Modifier.weight(1f), icon = Icons.Outlined.FactCheck, iconTint = C_GREEN, enabled = !InstallInfo.checking.value) { runCheck(ctx, scope) }
        Btn(if (InstallInfo.dexBusy.value) "Mengompilasi…" else "DEX2OAT", ac, Modifier.weight(1f), icon = Icons.Outlined.Speed, iconTint = C_YELLOW,
            enabled = !InstallInfo.dexBusy.value) { dexDlg = true }
    }
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Btn("Bersihkan", ac, Modifier.weight(1f), icon = Icons.Outlined.CleaningServices, iconTint = C_BLUE, enabled = !InstallInfo.dexBusy.value) { cleanDlg = true }
        Btn("Hapus config", ac, Modifier.weight(1f), icon = Icons.Outlined.Delete, iconTint = Color(0xFFE06070), enabled = !InstallInfo.busy.value) { delDlg = true }
    }
    Spacer(Modifier.height(6.dp))
    Spacer(Modifier.height(6.dp))
    val showDex = InstallInfo.dex.value != null || InstallInfo.dexBusy.value
    val showCheck = InstallInfo.report.value != null || InstallInfo.checking.value
    // Satu kotak saja: hasil aksi terbaru (cek status, DEX2OAT/bersih, atau pasang/hapus config) tampil di sini.
    val staleFail = cfg.isEmpty() && !InstallInfo.busy.value && InstallInfo.rec.value?.ok == false
    val showRec = InstallInfo.recVisible.value && !staleFail && (InstallInfo.rec.value != null || InstallInfo.busy.value)
    if (showCheck) CheckCard(hideEmpty = true)
    else if (showDex) DexCard()
    else {
        val tint = InstallInfo.rec.value?.takeIf { showRec }?.let { if (it.ok && it.kind != "delete") Color(0xFF5BD68E) else Color(0xFFE06060) } ?: Color.White
        val borderC = if (showRec) tint.copy(alpha = 0.35f) else Color.White.copy(0.08f)
        Box(Modifier.fillMaxWidth().heightIn(min = 150.dp).clip(RoundedCornerShape(18.dp)).background(CARD)
            .border(1.dp, borderC, RoundedCornerShape(18.dp))) {
            if (showRec) ResultCard(bare = true)
        }
    }
}

@Composable fun ImportCard(onClick: () -> Unit) {
    val amber = Color(0xFFE0B040)
    Row(Modifier.fillMaxWidth().background(Color(0xFF17140C), RoundedCornerShape(20.dp))
        .drawBehind {
            val w = 1.5.dp.toPx()
            drawRoundRect(amber.copy(alpha = 0.6f), topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w),
                cornerRadius = CornerRadius(20.dp.toPx()), style = Stroke(width = w, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))))
        }
        .clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(amber.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.FileUpload, null, tint = amber, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Impor zip", color = amber, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text("Tambah config dari file .zip", color = Color(0xFFC4CACE), fontSize = 14.sp)
            Text("Engine, DeviceProfiles, Scalability, GameUserSettings", color = Color(0xFF8A9096), fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable fun FileManagerDialog(onDismiss: () -> Unit, onSystem: () -> Unit, onOther: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Pilih file manager", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AccessOption("Bawaan sistem", "Pemilih file bawaan Android.", Icons.Outlined.FolderOpen, Color(0xFF8E86F0), Color(0xFF13111F), false, onClick = onSystem)
                AccessOption("File manager lain", "Pilih dari aplikasi lain, misalnya MT Manager, Solid Explorer, atau ZArchiver.", Icons.Outlined.Apps, Color(0xFFE0B040), Color(0xFF17140C), false, onClick = onOther)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
    )
}

@Composable fun ModeRailItem(ic: androidx.compose.ui.graphics.vector.ImageVector, ac: Color, sel: Boolean, m: Modifier, onClick: () -> Unit) {
    Box(m.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(if (sel) Color.Black.copy(alpha = 0.55f) else Color(0xFF26262F).copy(alpha = 0.5f))
        .border(if (sel) 2.dp else 0.dp, if (sel) ac else Color.Transparent, RoundedCornerShape(18.dp))
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(ic, null, tint = ac, modifier = Modifier.size(26.dp))
    }
}

@Composable fun ModeCard(t: String, s: String, ic: androidx.compose.ui.graphics.vector.ImageVector, sel: Boolean, ac: Color, m: Modifier, onClick: () -> Unit) {
    Row(m.clip(RoundedCornerShape(24.dp)).background(if (sel) Color.Black.copy(alpha = 0.55f) else CHIP)
        .border(if (sel) 2.dp else 0.dp, if (sel) ac else Color.Transparent, RoundedCornerShape(24.dp))
        .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = ac); Spacer(Modifier.width(8.dp))
        Column { Text(t, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, maxLines = 1); Text(s, color = Color.Gray, fontSize = 11.sp, maxLines = 1) }
    }
}

@Composable fun CircleBtn(icon: ImageVector, desc: String, bg: Color = Color(0xFF26262F), enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.size(38.dp).clip(CircleShape).background(bg).alpha(if (enabled) 1f else 0.4f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center) { Icon(icon, desc, tint = Color.White, modifier = Modifier.size(20.dp)) }
}

@Composable fun Editor(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val names = listOf("Engine.ini", "DeviceProfiles.ini")
    val drafts = remember { mutableStateListOf(*names.map { n -> File(ctx.filesDir, n).takeIf { it.exists() }?.readText() ?: "" }.toTypedArray()) }
    var t by remember { mutableStateOf(0) }
    var presetMenu by remember { mutableStateOf(false) }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) drafts[t] = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() ?: drafts[t]
    }
    var folder by remember { mutableStateOf(ConfigFolder.name(ctx)) }
    var folderDlg by remember { mutableStateOf(false) }
    var folderInput by remember { mutableStateOf("") }
    fun save(i: Int): Boolean {
        File(ctx.filesDir, names[i]).writeText(drafts[i])
        val f = folder ?: return true
        return drafts[i].isBlank() || ConfigFolder.write(ctx, f, names[i], drafts[i])
    }
    fun saveMsg(ok: Boolean, all: Boolean): String {
        val base = if (all) "Semua tersimpan" else "Tersimpan"
        val f = folder ?: return base
        return if (ok) "$base di ${ConfigFolder.path(f)}" else "$base di aplikasi, tapi gagal ke ${ConfigFolder.path(f)}"
    }

    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CHIP).padding(4.dp)) {
        names.forEachIndexed { i, n ->
            Text(n, Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (t == i) ac else Color.Transparent)
                .clickable { t = i }.padding(vertical = 10.dp, horizontal = 4.dp), color = if (t == i) Color.White else Color.Gray,
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, softWrap = false, textAlign = TextAlign.Center)
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f).fillMaxHeight()) {
            Btn("Preset", ac, Modifier.fillMaxSize()) { presetMenu = true }
            DropdownMenu(presetMenu, { presetMenu = false }) {
                Presets.options(ctx).forEach { (title, m, i) -> DropdownMenuItem(text = { Text(title) }, onClick = {
                    drafts[t] = Presets.file(ctx, m, i, names[t]) ?: drafts[t]; presetMenu = false }) }
            }
        }
        Btn("Buka file", ac, Modifier.weight(1f).fillMaxHeight()) { open.launch("*/*") }
        Btn("Simpan", ac, Modifier.weight(1f).fillMaxHeight(), enabled = drafts[t].isNotBlank()) { toast(ctx, saveMsg(save(t), false)) }
        Btn("Simpan semua", ac, Modifier.weight(1f).fillMaxHeight()) { toast(ctx, saveMsg(names.indices.map(::save).all { it }, true)) }
    }
    Spacer(Modifier.height(8.dp))
    Btn(if (folder == null) "Buat folder di Download" else "Folder: ${ConfigFolder.path(folder!!)}", ac, Modifier.fillMaxWidth(), icon = Icons.Outlined.Folder) {
        folderInput = folder ?: ConfigFolder.DEFAULT; folderDlg = true
    }
    if (folderDlg) AlertDialog(
        onDismissRequest = { folderDlg = false },
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Folder config", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = {
            Column {
                Text("Folder dibuat di Download. Tiap tekan Simpan, file config juga masuk ke folder ini.", color = Color(0xFFC4CACE), fontSize = 15.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(folderInput, { folderInput = it }, singleLine = true, label = { Text("Nama folder") })
            }
        },
        confirmButton = {
            TextButton(enabled = ConfigFolder.clean(folderInput).isNotEmpty(), onClick = {
                val n = ConfigFolder.create(ctx, folderInput)
                folder = n; folderDlg = false
                toast(ctx, if (n != null) "Folder ${ConfigFolder.path(n)} siap. Tekan Simpan untuk mengisinya." else "Nama folder tidak valid.")
            }) { Text("Buat", color = Color(0xFF8E86F0), fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
        },
        dismissButton = {
            Row {
                if (folder != null) TextButton(onClick = {
                    ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().remove("config_folder").apply()
                    folder = null; folderDlg = false
                    toast(ctx, "Simpan ke folder dimatikan. Folder & isinya di Download tidak dihapus.")
                }) { Text("Matikan", color = Color(0xFFFF6B6B), fontSize = 16.sp) }
                TextButton(onClick = { folderDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontSize = 16.sp) }
            }
        }
    )
    Spacer(Modifier.height(10.dp))
    var full by remember { mutableStateOf(false) }
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var wallOn by remember { mutableStateOf(prefs.getBoolean("editor_wall", true)) }
    var dimLevel by remember { mutableStateOf(prefs.getInt("editor_dim", 1)) }
    val hint = if (t == 0) "[/Script/Engine.RendererSettings]\nr.ScreenPercentage=100" else "[Android_High DeviceProfile]\nBaseProfileName=Android_High"
    val codeStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFFBBBBCC), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 21.sp)
    // Kotak kecil: ketuk di mana saja untuk buka editor layar penuh
    Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0D0D12).copy(alpha = 0.6f)).clickable { full = true }.padding(12.dp)) {
        Text(drafts[t].ifEmpty { hint }, Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            style = codeStyle, color = if (drafts[t].isEmpty()) Color(0xFF8A8A98) else Color(0xFFBBBBCC))
        Icon(Icons.Outlined.Fullscreen, "Layar penuh", tint = Color(0xFF8A8A98), modifier = Modifier.align(Alignment.TopEnd).size(22.dp))
    }
    if (full) Dialog(onDismissRequest = { full = false },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        val wall = LocalWall.current
        val dimLevels = listOf(0.25f to "Terang", 0.5f to "Sedang", 0.72f to "Gelap")
        val showWall = wallOn
        val barBg = Color(0xFF1B1B22).copy(alpha = if (showWall) 0.88f else 1f)
        val panelBg = Color(0xFF101015).copy(alpha = if (showWall) 0.82f else 1f)
        var tfv by remember { mutableStateOf(TextFieldValue(drafts[t])) }
        LaunchedEffect(drafts[t]) { if (tfv.text != drafts[t]) tfv = TextFieldValue(drafts[t]) }
        var menu by remember { mutableStateOf(false) }
        var presetMode by remember { mutableStateOf(false) }
        var searching by remember { mutableStateOf(false) }
        var query by remember { mutableStateOf("") }
        var pos by remember { mutableStateOf(0) }
        var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
        val sc = rememberScrollState()
        val hsc = rememberScrollState()
        val focus = remember { FocusRequester() }
        val searchFocus = remember { FocusRequester() }
        LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
        LaunchedEffect(searching) { if (searching) runCatching { searchFocus.requestFocus() } }
        fun findNext() {
            if (query.isEmpty()) return
            val txt = tfv.text
            var i = txt.indexOf(query, pos, ignoreCase = true)
            if (i < 0) i = txt.indexOf(query, 0, ignoreCase = true)
            if (i < 0) { toast(ctx, "Tidak ditemukan"); return }
            pos = i + query.length
            layout?.let { l ->
                val y = l.getLineTop(l.getLineForOffset(i.coerceAtMost(tfv.text.length))).toInt()
                scope.launch { sc.animateScrollTo((y - 120).coerceAtLeast(0)) }
            }
        }
        val highlight = remember(query, searching, ac) {
            VisualTransformation { text ->
                val src = text.text
                val str = buildAnnotatedString {
                    append(src)
                    var off = 0
                    for (line in src.split("\n")) {
                        val end = off + line.length
                        val tl = line.trimStart()
                        when {
                            tl.startsWith("[") -> addStyle(SpanStyle(color = ac, fontWeight = FontWeight.Bold), off, end)
                            tl.startsWith(";") || tl.startsWith("#") -> addStyle(SpanStyle(color = Color(0xFF7D7D8C)), off, end)
                            else -> {
                                val eq = line.indexOf('=')
                                if (eq >= 0) {
                                    addStyle(SpanStyle(color = Color(0xFF6A6A78)), off + eq, off + eq + 1)
                                    addStyle(SpanStyle(color = Color(0xFFF2C46D)), off + eq + 1, end)
                                }
                            }
                        }
                        off = end + 1
                    }
                    if (searching && query.isNotEmpty()) {
                        var i = src.indexOf(query, 0, ignoreCase = true)
                        while (i >= 0) {
                            addStyle(SpanStyle(background = Color(0x88FFC857)), i, i + query.length)
                            i = src.indexOf(query, i + query.length, ignoreCase = true)
                        }
                    }
                }
                TransformedText(str, OffsetMapping.Identity)
            }
        }
        val lineCount = tfv.text.count { it == '\n' } + 1
        val codeStyle2 = androidx.compose.ui.text.TextStyle(color = Color(0xFFE6E6EE), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 22.sp)

        Box(Modifier.fillMaxSize().background(Color(0xFF0D0D12))) {
            if (showWall) {
                if (wall.bitmap != null) Image(wall.bitmap, null,
                    Modifier.fillMaxSize().then(if (wall.blur) Modifier.blur(16.dp) else Modifier),
                    contentScale = ContentScale.Crop, filterQuality = FilterQuality.High)
                else Box(Modifier.fillMaxSize().background(wall.solid))
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dimLevels[dimLevel].first)))
            }
            Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
                // Bar atas melayang berbentuk pil
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(barBg).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CircleBtn(Icons.Outlined.ArrowBack, "Kembali") { full = false }
                    if (searching) {
                        BasicTextField(query, { query = it; pos = 0 },
                            Modifier.weight(1f).padding(horizontal = 6.dp).focusRequester(searchFocus),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(ac),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { findNext() }),
                            decorationBox = { inner ->
                                Box { if (query.isEmpty()) Text("Cari di file…", color = Color(0xFF9A9AAA), fontSize = 16.sp); inner() }
                            })
                        CircleBtn(Icons.Outlined.KeyboardArrowDown, "Cari berikutnya") { findNext() }
                        CircleBtn(Icons.Outlined.Close, "Tutup pencarian") { searching = false; query = "" }
                    } else {
                        Column(Modifier.weight(1f).padding(start = 4.dp)) {
                            Text(names[t], color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                            Text("$lineCount baris", color = Color(0xFF8A8A98), fontSize = 11.sp)
                        }
                        CircleBtn(Icons.Outlined.Search, "Cari") { searching = true; pos = 0 }
                        CircleBtn(Icons.Outlined.Save, "Simpan", bg = ac, enabled = drafts[t].isNotBlank()) { toast(ctx, saveMsg(save(t), false)) }
                        Box {
                            CircleBtn(Icons.Outlined.MoreVert, "Menu") { presetMode = false; menu = true }
                            DropdownMenu(menu, { menu = false; presetMode = false }) {
                                if (!presetMode) {
                                    DropdownMenuItem(text = { Text("Preset") }, onClick = { presetMode = true })
                                    DropdownMenuItem(text = { Text("Simpan semua") }, onClick = {
                                        toast(ctx, saveMsg(names.indices.map(::save).all { it }, true)); menu = false })
                                    DropdownMenuItem(text = { Text(if (wallOn) "Wallpaper: hidup" else "Wallpaper: mati") }, onClick = {
                                        wallOn = !wallOn; prefs.edit().putBoolean("editor_wall", wallOn).apply(); menu = false })
                                    if (wallOn) DropdownMenuItem(text = { Text("Gelap wallpaper: ${dimLevels[dimLevel].second}") }, onClick = {
                                        dimLevel = (dimLevel + 1) % dimLevels.size; prefs.edit().putInt("editor_dim", dimLevel).apply() })
                                } else {
                                    Presets.options(ctx).forEach { (title, m, i) -> DropdownMenuItem(text = { Text(title) }, onClick = {
                                        drafts[t] = Presets.file(ctx, m, i, names[t]) ?: drafts[t]; menu = false; presetMode = false }) }
                                }
                            }
                        }
                    }
                }
                // Area teks: nomor baris + isi config berwarna
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(start = 10.dp, end = 10.dp, bottom = 10.dp)
                    .clip(RoundedCornerShape(18.dp)).background(panelBg)) {
                    val minH = maxHeight
                    Row(Modifier.fillMaxWidth().verticalScroll(sc).padding(vertical = 10.dp)) {
                        Text((1..lineCount).joinToString("\n"), Modifier.width(40.dp).padding(end = 8.dp), style = codeStyle2,
                            color = Color(0xFF4D4D5A), textAlign = TextAlign.End)
                        Box(Modifier.fillMaxWidth().horizontalScroll(hsc)) {
                            BasicTextField(tfv, { tfv = it; drafts[t] = it.text },
                                Modifier.defaultMinSize(minWidth = 300.dp, minHeight = minH).padding(start = 8.dp, end = 12.dp).focusRequester(focus),
                                textStyle = codeStyle2, cursorBrush = SolidColor(ac),
                                visualTransformation = highlight,
                                onTextLayout = { layout = it },
                                decorationBox = { inner ->
                                    Box {
                                        if (tfv.text.isEmpty()) Text(hint, color = Color(0xFF8A8A98), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 22.sp)
                                        inner()
                                    }
                                })
                        }
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.clip(CircleShape).background(CHIP).clickable { drafts[t] = "" }.padding(13.dp)) { Icon(Icons.Outlined.Delete, null, tint = Color(0xFFE06070)) }
        Btn("Pasang ${names[t]}", ac, Modifier.weight(1f), filled = true, enabled = drafts[t].isNotBlank()) {
            runWithGame(ctx, scope, names[t], infoLabel = "${names[t]} (edit manual)") { ShizukuShell.writeVerified(it, names[t], drafts[t]) }
        }
    }
}

@Composable fun Look(ac: Color, accent: Int, setAccent: (Int) -> Unit, wall: Int, setWall: (Int) -> Unit, change: () -> Unit,
                     dim: Float, setDim: (Float) -> Unit, blurOn: Boolean, setBlur: (Boolean) -> Unit, thumb: ImageBitmap? = null, trans: Float = 0.1f, setTrans: (Float) -> Unit = {}) {
    Text("Warna aksen", color = Color.LightGray, fontSize = 15.sp)
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        ACCENTS.forEachIndexed { i, c ->
            Box(Modifier.size(40.dp).clip(CircleShape).background(c).border(if (i == accent) 3.dp else 0.dp, Color.White, CircleShape)
                .clickable { setAccent(i) }, contentAlignment = Alignment.Center) { if (i == accent) Icon(Icons.Outlined.Check, null, tint = Color.White) }
        }
    }
    val thumbSharp = remember(thumb) { thumb?.let { makeThumb(it) } }
    Text("Wallpaper", color = Color.LightGray, fontSize = 15.sp)
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Ganti" to 1, "Tanpa" to 0, "Ungu" to 2, "Biru" to 3).forEach { (n, w) ->
            val shape = RoundedCornerShape(14.dp)
            val hasThumb = w == 1 && thumbSharp != null
            Box(Modifier.weight(1f).height(60.dp).clip(shape)
                .background(when (w) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); 1 -> CHIP; else -> Color.Black })
                .clickable { if (w == 1) change() else setWall(w) }) {
                if (hasThumb) {
                    Image(thumbSharp!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                        alignment = androidx.compose.ui.BiasAlignment(0f, -0.35f), filterQuality = FilterQuality.High)
                    Text(n, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(0.85f), Offset(0f, 2f), 6f)),
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
                } else {
                    Text(n, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
                }
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Redup", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Slider(dim, setDim, Modifier.weight(1f).padding(horizontal = 12.dp), valueRange = 0f..0.8f)
        Text("${(dim / 0.8f * 100).toInt()}%", color = Color.LightGray)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Transparan", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Slider(trans, setTrans, Modifier.weight(1f).padding(horizontal = 12.dp), valueRange = 0f..0.85f)
        Text("${(trans / 0.85f * 100).toInt()}%", color = Color.LightGray)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Blur wallpaper", Modifier.weight(1f), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Switch(blurOn, setBlur)
    }
}

@Composable fun SettingsTab(ac: Color) {
    val ctx = LocalContext.current
    val s = ShizukuShell.status.value
    val root = ShizukuShell.isRoot()
    val scope = rememberCoroutineScope()
    var dlg by remember { mutableStateOf(false) }
    var logDlg by remember { mutableStateOf(false) }
    if (logDlg) LogDialog { logDlg = false }
    if (dlg) AccessDialog { dlg = false }
    Column(Modifier.padding(horizontal = 12.dp)) {
    Row(Modifier.fillMaxWidth().clickable { ShizukuShell.refresh(); dlg = true }.padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(when { ShizukuShell.isAdb() -> Icons.Outlined.Wifi; root -> Icons.Outlined.Security; else -> Icons.Outlined.Power }, null, tint = ac, modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF0A0A1A)).padding(9.dp))
        Spacer(Modifier.width(16.dp))
        Column {
            Text(ShizukuShell.modeName(), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(when (s) { 2 -> "Terhubung"; 1 -> "Ketuk untuk beri izin"; else -> if (root) "Root tidak tersedia" else if (ShizukuShell.isAdb()) "Belum terhubung" else "Tidak berjalan" }, color = if (s == 2) Color(0xFF5BD68E) else Color(0xFFE0B040))
        }
    }
    Divider0()
    Row0("Log", "Cek penyebab gagal", Icons.Outlined.Description, tint = Color(0xFFE8B84A)) { logDlg = true }
    Divider0()
    Row0("Komunitas Discord", "", Icons.Outlined.SportsEsports, trailing = Icons.Outlined.OpenInNew) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL))) }
    Divider0()
    Row0("Pembuat aplikasi", "lismoyca", Icons.Outlined.Person, tint = Color(0xFFE49A72), trailing = Icons.Outlined.OpenInNew) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(CREATOR_URL)))
    }
    }
}

@Composable fun Divider0() { Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.10f))) }

@Composable fun Row0(t: String, v: String, ic: ImageVector, tint: Color = Color(0xFF8E86F0), trailing: ImageVector = Icons.Outlined.ChevronRight, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = tint); Spacer(Modifier.width(16.dp))
        Text(t, Modifier.weight(1f), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Text(v, color = Color.Gray, fontSize = 15.sp); Icon(trailing, null, tint = Color.Gray)
    }
}

@Composable fun AccessDialog(onDismiss: () -> Unit) {
    val cur = ShizukuShell.mode.value
    var pair by remember { mutableStateOf(false) }
    if (pair) { PairSheet(onDismiss = { pair = false; onDismiss() }); return }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                    Icons.Outlined.Smartphone, Color(0xFF8E86F0), Color(0xFF13111F), cur == ShizukuShell.MODE_SHIZUKU) {
                    ShizukuShell.select(ShizukuShell.MODE_SHIZUKU)
                    onDismiss()
                }
                AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                    Icons.Outlined.Security, Color(0xFFE49A72), Color(0xFF181412), cur == ShizukuShell.MODE_ROOT) {
                    ShizukuShell.select(ShizukuShell.MODE_ROOT)
                    onDismiss()
                }
                AccessOption("Wireless ADB", "Tanpa Shizuku & tanpa root. Pairing sekali dengan port + kode 6 digit.",
                    Icons.Outlined.Wifi, Color(0xFF5CC98A), Color(0xFF0F1713), cur == ShizukuShell.MODE_ADB) {
                    ShizukuShell.select(ShizukuShell.MODE_ADB)
                    pair = true
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
    )
}

@Composable fun AccessOption(title: String, desc: String, icon: ImageVector, accent: Color, bg: Color, selected: Boolean, end: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
        end?.invoke()
    }
}
