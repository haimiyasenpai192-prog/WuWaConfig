package id.wuwaconfig

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

val ACCENTS = listOf(0xFF6B5FDB, 0xFF4A8BDB, 0xFF4AA37A, 0xFFC95A82, 0xFFD0663C, 0xFFB8802F).map { Color(it) }
val LocalPanelAlpha = compositionLocalOf { 0.9f }
@Composable fun panelColor(): Color = Color(0xFF101015).copy(alpha = LocalPanelAlpha.current)
val CHIP = Color(0xFF1A1A22)
const val DISCORD_URL = "https://discord.gg/EFaCxujTcC"

class MainActivity : ComponentActivity() {
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> ShizukuShell.refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { ShizukuShell.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { ShizukuShell.refresh() }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        ShizukuShell.init(this)
        ShizukuShell.refresh()
        setContent { App() }
    }

    override fun onResume() { super.onResume(); ShizukuShell.refresh() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

fun decodeSharp(open: () -> java.io.InputStream?): ImageBitmap? {
    val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open()?.use { BitmapFactory.decodeStream(it, null, b) }
    var sample = 1
    val big = maxOf(b.outWidth, b.outHeight)
    while (big / (sample * 2) >= 2600) sample *= 2
    return open()?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }?.asImageBitmap()
}

fun makeThumb(src: ImageBitmap): ImageBitmap {
    var b = src.asAndroidBitmap()
    while (b.width >= 1440) b = android.graphics.Bitmap.createScaledBitmap(b, b.width / 2, b.height / 2, true)
    if (b.width > 720) b = android.graphics.Bitmap.createScaledBitmap(b, 720, 720 * b.height / b.width, true)
    return b.asImageBitmap()
}

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

@Composable
fun App() {
    val ctx = LocalContext.current
    val dens = LocalDensity.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var accent by remember { mutableStateOf(prefs.getInt("accent", 0)) }
    // Wallpaper bawaan: taruh gambar di app/src/main/assets/wallpaper_default.jpg (opsional).
    val defaultWall = remember {
        try { decodeSharp { ctx.assets.open("wallpaper_default.jpg") } } catch (_: Exception) { null }
    }
    var wall by remember { mutableStateOf(prefs.getInt("wall", if (defaultWall != null) 1 else 0)) } // 0 tanpa,1 gambar,2 ungu,3 biru
    var dim by remember { mutableStateOf(prefs.getFloat("dim", 0f)) }
    var trans by remember { mutableStateOf(prefs.getFloat("trans", 0.1f)) }
    var blurOn by remember { mutableStateOf(prefs.getBoolean("blur", false)) }
    val wallFile = File(ctx.filesDir, "wallpaper.jpg")
    var wallVersion by remember { mutableStateOf(0) }
    val ac = ACCENTS[accent]

    val pickWall = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ctx.contentResolver.openInputStream(uri)?.use { i -> wallFile.outputStream().use { o -> i.copyTo(o) } }
            wall = 1; prefs.edit().putInt("wall", 1).apply(); wallVersion++
        }
    }
    val wallBitmap = remember(wallVersion, wall) {
        if (wall != 1) null
        else if (wallFile.exists()) decodeSharp { wallFile.inputStream() }
        else defaultWall
    }

    CompositionLocalProvider(LocalDensity provides Density(dens.density, minOf(dens.fontScale, 1f)), LocalPanelAlpha provides (1f - trans)) {
    MaterialTheme(colorScheme = darkColorScheme(primary = ac)) {
        Box(Modifier.fillMaxSize().background(when (wall) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); else -> Color.Black })) {
            if (wallBitmap != null) {
                Image(wallBitmap, null, Modifier.fillMaxSize().then(if (blurOn) Modifier.blur(16.dp) else Modifier),
                    contentScale = ContentScale.Crop, filterQuality = FilterQuality.High)
            }
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            Column(Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -150f && tab < 3) tab++ else if (total > 150f && tab > 0) tab-- },
                        onHorizontalDrag = { _, d -> total += d })
                }
                .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
                val heads = listOf(
                    "WuWa Config" to "Pilih, lalu install config", "Edit" to "Tulis atau tempel tweak config.",
                    "Tampilan" to "Atur warna dan wallpaper.", "Settings" to "Atur akses dan aplikasi.")
                val shadow = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(0.6f), Offset(0f, 3f), 10f))
                Row(Modifier.padding(top = 16.dp).fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        AnimatedContent(targetState = tab, label = "judul",
                            transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(140)) }) { t ->
                            Column {
                                Text(heads[t].first, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White, style = shadow)
                                Text(heads[t].second, color = Color.White.copy(0.85f), style = shadow)
                            }
                        }
                    }
                    AnimatedVisibility(visible = tab == 0, enter = fadeIn(tween(250)), exit = fadeOut(tween(150))) { StatusChip() }
                }
                Spacer(Modifier.weight(1f))
                Panel {
                    AnimatedContent(targetState = tab, label = "tab",
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (slideInHorizontally(tween(340)) { it * dir / 3 } + fadeIn(tween(340))) togetherWith
                                (slideOutHorizontally(tween(340)) { -it * dir / 3 } + fadeOut(tween(160)))
                        }) { t ->
                    Column(Modifier.fillMaxWidth()) {
                    when (t) {
                        0 -> Home(ac)
                        1 -> Editor(ac)
                        2 -> Look(ac, accent, { accent = it; prefs.edit().putInt("accent", it).apply() },
                            wall, { w -> if (w == 1 && !wallFile.exists() && defaultWall == null) pickWall.launch("image/*") else if (w == 1) { wall = 1; prefs.edit().putInt("wall", 1).apply() } else { wall = w; prefs.edit().putInt("wall", w).apply() } },
                            { pickWall.launch("image/*") }, dim, { dim = it; prefs.edit().putFloat("dim", it).apply() },
                            blurOn, { blurOn = it; prefs.edit().putBoolean("blur", it).apply() }, wallBitmap,
                            trans, { trans = it; prefs.edit().putFloat("trans", it).apply() })
                        else -> SettingsTab(ac)
                    }
                    }
                    }
                }
                Spacer(Modifier.height(8.dp))
                NavBar(tab, ac) { tab = it }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
    }
}

@Composable fun Panel(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(panelColor()).animateContentSize(tween(300)).padding(12.dp), content = content)

@Composable fun StatusChip() {
    val s = ShizukuShell.status.value
    val name = if (ShizukuShell.isRoot()) "Root" else "Shizuku"
    val (txt, col) = when (s) { 2 -> name to Color(0xFF5BD68E); 1 -> "Izinkan" to Color(0xFFE0B040); else -> "$name off" to Color(0xFFE06060) }
    Row(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x99000000)).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(col)); Spacer(Modifier.width(8.dp))
        Text(txt, color = col, fontWeight = FontWeight.SemiBold)
    }
}

@Composable fun NavBar(sel: Int, ac: Color, onSel: (Int) -> Unit) {
    val items = listOf("Beranda" to Icons.Outlined.Home, "Edit" to Icons.Outlined.Edit, "Tampilan" to Icons.Outlined.Palette, "Settings" to Icons.Outlined.Settings)
    val navColors = listOf(Color(0xFF8AB4F8), Color(0xFF7CCFA4), Color(0xFFF08FB8), Color(0xFFE8B84A))
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(panelColor()).padding(5.dp)) {
        items.forEachIndexed { i, (n, ic) ->
            val on = i == sel
            val nc = navColors[i]
            val bgc by animateColorAsState(if (on) nc.copy(alpha = 0.16f) else Color.Transparent, tween(260), label = "navbg")
            val tint by animateColorAsState(if (on) nc else Color.Gray, tween(260), label = "navtint")
            val sc by animateFloatAsState(if (on) 1.18f else 1f, spring(dampingRatio = 0.45f, stiffness = 380f), label = "navscale")
            Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                .background(bgc)
                .clickable { onSel(i) }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(ic, n, tint = tint, modifier = Modifier.size(22.dp).graphicsLayer(scaleX = sc, scaleY = sc))
                Text(n, fontSize = 11.sp, color = tint)
            }
        }
    }
}

@Composable fun Btn(text: String, ac: Color, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true,
                    icon: ImageVector? = null, iconTint: Color = Color.White, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(20.dp)).background(if (filled) ac else CHIP).alpha(if (enabled) 1f else 0.4f)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 8.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) { Icon(icon, null, tint = iconTint, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = if (filled) 17.sp else 13.sp,
                maxLines = 2, textAlign = TextAlign.Center, lineHeight = if (filled) 22.sp else 16.sp)
        }
    }
}

/** Pastikan Shizuku siap & game terpasang; panggil aksi di thread IO. */
fun runWithGame(ctx: Context, scope: kotlinx.coroutines.CoroutineScope, notifyLabel: String? = null, block: (String) -> String?) {
    ShizukuShell.refresh()
    when (ShizukuShell.status.value) {
        0 -> { toast(ctx, if (ShizukuShell.isRoot()) "Root tidak tersedia di perangkat ini." else "Shizuku belum berjalan. Nyalakan dulu Shizuku."); return }
        1 -> { ShizukuShell.requestPermission(); toast(ctx, if (ShizukuShell.isRoot()) "Izinkan akses root, lalu coba lagi." else "Izinkan akses Shizuku, lalu coba lagi."); return }
    }
    val pkg = ShizukuShell.installedPackage(ctx) ?: run { toast(ctx, "Wuthering Waves tidak ditemukan."); return }
    scope.launch {
        val err = withContext(Dispatchers.IO) { block(pkg) }
        toast(ctx, err?.let { "Gagal: $it" } ?: "Berhasil. Buka game untuk mencoba.")
        if (err == null && notifyLabel != null) Notifier.installed(ctx, notifyLabel)
    }
}

@Composable fun Home(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("Flagship") }
    var tier by remember { mutableStateOf(0) }
    var pickDlg by remember { mutableStateOf(false) }
    var cfgDlg by remember { mutableStateOf(false) }
    var cfg by remember { mutableStateOf(Presets.current(ctx)) }
    var cfgVersions by remember { mutableStateOf(Presets.versions(ctx)) }
    val tierList = Presets.tiers(ctx, cfg, mode)
    val ti = tier.coerceIn(0, maxOf(0, tierList.size - 1))
    val importCfg = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow("_display_name")) else null
            } ?: u.lastPathSegment?.substringAfterLast('/') ?: "config.zip"
            val err = Presets.importZip(ctx, u, name)
            cfgVersions = Presets.versions(ctx); cfg = Presets.current(ctx); tier = 0
            toast(ctx, err ?: "Config ${cfg} diimpor dan dipilih.")
        }
    }
    val installUris: (List<Uri>) -> Unit = { uris ->
        if (uris.isNotEmpty()) runWithGame(ctx, scope, "Config manual") { pkg ->
            var err: String? = null
            for (u in uris) {
                val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow("_display_name")) else null }
                    ?: u.lastPathSegment?.substringAfterLast('/') ?: continue
                if (name !in INI_FILES) { err = "$name bukan file yang didukung"; continue }
                val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() ?: continue
                err = ShizukuShell.write(pkg, name, text) ?: err
            }
            err
        }
    }
    val manual = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { installUris(it) }
    val other = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data; val list = mutableListOf<Uri>()
        d?.clipData?.let { c -> for (i in 0 until c.itemCount) list += c.getItemAt(i).uri }
        if (list.isEmpty()) d?.data?.let { list += it }
        installUris(list)
    }
    if (pickDlg) AlertDialog(
        onDismissRequest = { pickDlg = false },
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Pilih file manager", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AccessOption("Bawaan sistem", "Pemilih file bawaan Android.", Icons.Outlined.FolderOpen, Color(0xFF8E86F0), Color(0xFF13111F), false) {
                    pickDlg = false; manual.launch(arrayOf("*/*"))
                }
                AccessOption("File manager lain", "Pilih dari aplikasi lain, misalnya MT Manager, Solid Explorer, atau ZArchiver.", Icons.Outlined.Apps, Color(0xFFE0B040), Color(0xFF17140C), false) {
                    pickDlg = false
                    val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                    try { other.launch(Intent.createChooser(i, "Pilih file manager")) }
                    catch (_: Exception) { toast(ctx, "Tidak ada file manager lain yang tersedia.") }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { pickDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
    )
    if (cfgDlg) AlertDialog(
        onDismissRequest = { cfgDlg = false },
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Pilih config", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                cfgVersions.reversed().forEach { v ->
                    AccessOption("Config $v", "Flagship dan Balanced, lengkap dengan tingkat kualitasnya.",
                        Icons.Outlined.Layers, ac, Color(0xFF13111F), v == cfg) {
                        cfg = v; tier = 0; Presets.setCurrent(ctx, v); cfgDlg = false
                    }
                }
                AccessOption("Impor zip", "Tambah config baru dari file .zip di HP kamu.",
                    Icons.Outlined.FileUpload, Color(0xFFE0B040), Color(0xFF17140C), false) {
                    cfgDlg = false; importCfg.launch(arrayOf("*/*"))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { cfgDlg = false }) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
    )
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(24.dp)).background(CHIP)
        .clickable { cfgDlg = true }.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Layers, null, tint = ac); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Config", fontSize = 12.sp, color = Color.Gray)
            Text(cfg, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Text("Ganti", color = ac, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Icon(Icons.Outlined.ChevronRight, null, tint = Color.Gray)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ModeCard("Flagship", "Visual stabil", Icons.Outlined.DesktopWindows, mode == "Flagship", ac, Modifier.weight(1f)) { mode = "Flagship"; tier = 0 }
        ModeCard("Balanced", "Balanced stabil", Icons.Outlined.Balance, mode == "Balanced", ac, Modifier.weight(1f)) { mode = "Balanced"; tier = 0 }
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Tune, null, tint = ac); Spacer(Modifier.width(12.dp))
        Text("Kualitas", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White, modifier = Modifier.weight(1f))
        Row(Modifier.clip(RoundedCornerShape(20.dp)).background(CHIP).padding(4.dp)) {
            if (tierList.isEmpty()) Text("Tidak tersedia", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp))
            tierList.forEachIndexed { i, q ->
                Text(q.label, color = if (ti == i) Color.White else Color.Gray, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1,
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (ti == i) ac else Color.Transparent)
                        .clickable { tier = i }.padding(horizontal = 14.dp, vertical = 7.dp))
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Btn("Install manual", ac, Modifier.weight(1f), icon = Icons.Outlined.FolderOpen, iconTint = Color(0xFFE0B040)) { pickDlg = true }
        Btn("Hapus config", ac, Modifier.weight(1f), icon = Icons.Outlined.Delete, iconTint = Color(0xFFE06070)) {
            runWithGame(ctx, scope) { ShizukuShell.delete(it, Presets.FILES) }
        }
    }
    Spacer(Modifier.height(8.dp))
    Btn("Install", ac, Modifier.fillMaxWidth(), filled = true) {
        val files = Presets.files(ctx, cfg, mode, ti)
        if (files == null) { toast(ctx, "Preset $cfg $mode belum tersedia."); return@Btn }
        runWithGame(ctx, scope, "$cfg $mode ${tierList[ti].label}") { pkg ->
            var err: String? = null
            for ((name, text) in files) { err = ShizukuShell.write(pkg, name, text) ?: err }
            err
        }
    }
}

val INI_FILES = setOf("Engine.ini", "DeviceProfiles.ini", "Scalability.ini", "GameUserSettings.ini")

@Composable fun ModeCard(t: String, s: String, ic: androidx.compose.ui.graphics.vector.ImageVector, sel: Boolean, ac: Color, m: Modifier, onClick: () -> Unit) {
    Row(m.clip(RoundedCornerShape(24.dp)).background(if (sel) Color.Black else CHIP)
        .border(if (sel) 2.dp else 0.dp, if (sel) ac else Color.Transparent, RoundedCornerShape(24.dp))
        .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = ac); Spacer(Modifier.width(8.dp))
        Column { Text(t, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, maxLines = 1); Text(s, color = Color.Gray, fontSize = 11.sp, maxLines = 1) }
    }
}

@Composable fun Editor(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val names = listOf("Engine.ini", "DeviceProfiles.ini")
    val drafts = remember { mutableStateListOf(*names.map { n -> File(ctx.filesDir, n).takeIf { it.exists() }?.readText() ?: "" }.toTypedArray()) }
    var t by remember { mutableStateOf(0) }
    var presetMenu by remember { mutableStateOf(false) }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) drafts[t] = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() ?: drafts[t]
    }
    fun save(i: Int) = File(ctx.filesDir, names[i]).writeText(drafts[i])

    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CHIP).padding(4.dp)) {
        names.forEachIndexed { i, n ->
            Text(n, Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (t == i) ac else Color.Transparent)
                .clickable { t = i }.padding(vertical = 10.dp, horizontal = 4.dp), color = if (t == i) Color.White else Color.Gray,
                fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, softWrap = false, textAlign = TextAlign.Center)
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f).fillMaxHeight()) {
            Btn("Preset", ac, Modifier.fillMaxSize()) { presetMenu = true }
            DropdownMenu(presetMenu, { presetMenu = false }) {
                Presets.options(ctx).forEach { (title, m, i) -> DropdownMenuItem(text = { Text(title) }, onClick = {
                    drafts[t] = Presets.file(ctx, m, i, names[t]) ?: drafts[t]; presetMenu = false }) }
            }
        }
        Btn("Buka file", ac, Modifier.weight(1f).fillMaxHeight()) { open.launch("*/*") }
        Btn("Simpan", ac, Modifier.weight(1f).fillMaxHeight(), enabled = drafts[t].isNotBlank()) { save(t); toast(ctx, "Tersimpan") }
        Btn("Simpan semua", ac, Modifier.weight(1f).fillMaxHeight()) { names.indices.forEach(::save); toast(ctx, "Semua tersimpan") }
    }
    Spacer(Modifier.height(10.dp))
    Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0D0D12)).padding(12.dp)) {
        val hint = if (t == 0) "[/Script/Engine.RendererSettings]\nr.ScreenPercentage=100" else "[Android_High DeviceProfile]\nBaseProfileName=Android_High"
        BasicTextField(drafts[t], { drafts[t] = it }, Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFFBBBBCC), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 21.sp),
            cursorBrush = SolidColor(ac),
            decorationBox = { inner ->
                Box {
                    if (drafts[t].isEmpty()) Text(hint, color = Color(0xFF8A8A98), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 21.sp)
                    inner()
                }
            })
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.clip(CircleShape).background(CHIP).clickable { drafts[t] = "" }.padding(13.dp)) { Icon(Icons.Outlined.Delete, null, tint = Color(0xFFE06070)) }
        Btn("Pasang ${names[t]}", ac, Modifier.weight(1f), filled = true, enabled = drafts[t].isNotBlank()) {
            runWithGame(ctx, scope, names[t]) { ShizukuShell.write(it, names[t], drafts[t]) }
        }
    }
}

@Composable fun Look(ac: Color, accent: Int, setAccent: (Int) -> Unit, wall: Int, setWall: (Int) -> Unit, change: () -> Unit,
                     dim: Float, setDim: (Float) -> Unit, blurOn: Boolean, setBlur: (Boolean) -> Unit, thumb: ImageBitmap? = null, trans: Float = 0.1f, setTrans: (Float) -> Unit = {}) {
    Text("Warna aksen", color = Color.LightGray, fontSize = 15.sp)
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        ACCENTS.forEachIndexed { i, c ->
            Box(Modifier.size(40.dp).clip(CircleShape).background(c).border(if (i == accent) 3.dp else 0.dp, Color.White, CircleShape)
                .clickable { setAccent(i) }, contentAlignment = Alignment.Center) { if (i == accent) Icon(Icons.Outlined.Check, null, tint = Color.White) }
        }
    }
    val thumbSharp = remember(thumb) { thumb?.let { makeThumb(it) } }
    Text("Wallpaper", color = Color.LightGray, fontSize = 15.sp)
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Ganti" to 1, "Tanpa" to 0, "Ungu" to 2, "Biru" to 3).forEach { (n, w) ->
            val shape = RoundedCornerShape(14.dp)
            val hasThumb = w == 1 && thumbSharp != null
            Box(Modifier.weight(1f).height(60.dp).clip(shape)
                .background(when (w) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); 1 -> CHIP; else -> Color.Black })
                .clickable { if (w == 1) change() else setWall(w) }) {
                if (hasThumb) {
                    Image(thumbSharp!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                        alignment = androidx.compose.ui.BiasAlignment(0f, -0.35f), filterQuality = FilterQuality.High)
                    Text(n, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        style = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(0.85f), Offset(0f, 2f), 6f)),
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp))
                } else {
                    Text(n, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
                }
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Redup", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Slider(dim, setDim, Modifier.weight(1f).padding(horizontal = 12.dp), valueRange = 0f..0.8f)
        Text("${(dim / 0.8f * 100).toInt()}%", color = Color.LightGray)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Transparan", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Slider(trans, setTrans, Modifier.weight(1f).padding(horizontal = 12.dp), valueRange = 0f..0.85f)
        Text("${(trans / 0.85f * 100).toInt()}%", color = Color.LightGray)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Blur wallpaper", Modifier.weight(1f), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Switch(blurOn, setBlur)
    }
}

@Composable fun SettingsTab(ac: Color) {
    val ctx = LocalContext.current
    val s = ShizukuShell.status.value
    val root = ShizukuShell.isRoot()
    var dlg by remember { mutableStateOf(false) }
    if (dlg) AccessDialog { dlg = false }
    Column(Modifier.padding(horizontal = 12.dp)) {
    Row(Modifier.fillMaxWidth().clickable { ShizukuShell.refresh(); dlg = true }.padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(if (root) Icons.Outlined.Security else Icons.Outlined.Power, null, tint = ac, modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF0A0A1A)).padding(9.dp))
        Spacer(Modifier.width(16.dp))
        Column {
            Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(when (s) { 2 -> "Terhubung"; 1 -> "Ketuk untuk beri izin"; else -> if (root) "Root tidak tersedia" else "Tidak berjalan" }, color = if (s == 2) Color(0xFF5BD68E) else Color(0xFFE0B040))
        }
    }
    Divider0()
    Row0("Gabung Discord", "", Icons.Outlined.SportsEsports, trailing = Icons.Outlined.OpenInNew) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL))) }
    Divider0()
    Row0("Bahasa", "Indonesia", Icons.Outlined.Language) {}
    Divider0()
    Row0("Cek pembaruan", "", Icons.Outlined.Refresh, tint = Color(0xFF5B9BE0)) { toast(ctx, "Belum ada server pembaruan (isi sendiri).") }
    Divider0()
    Row0("Tentang aplikasi", "v1.0", Icons.Outlined.Info, tint = Color(0xFF5BD68E)) { toast(ctx, "WuWa Config v1.0 — pemasang config via Shizuku") }
    }
}

@Composable fun Divider0() { Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.10f))) }

@Composable fun Row0(t: String, v: String, ic: ImageVector, tint: Color = Color(0xFF8E86F0), trailing: ImageVector = Icons.Outlined.ChevronRight, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = tint); Spacer(Modifier.width(16.dp))
        Text(t, Modifier.weight(1f), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Text(v, color = Color.Gray, fontSize = 15.sp); Icon(trailing, null, tint = Color.Gray)
    }
}

@Composable fun AccessDialog(onDismiss: () -> Unit) {
    val cur = ShizukuShell.mode.value
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                    Icons.Outlined.Smartphone, Color(0xFF8E86F0), Color(0xFF13111F), cur == ShizukuShell.MODE_SHIZUKU) {
                    ShizukuShell.setMode(ShizukuShell.MODE_SHIZUKU)
                    if (ShizukuShell.status.value == 1) ShizukuShell.requestPermission()
                    onDismiss()
                }
                AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                    Icons.Outlined.Security, Color(0xFFE49A72), Color(0xFF181412), cur == ShizukuShell.MODE_ROOT) {
                    ShizukuShell.setMode(ShizukuShell.MODE_ROOT)
                    onDismiss()
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
    )
}

@Composable fun AccessOption(title: String, desc: String, icon: ImageVector, accent: Color, bg: Color, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}
