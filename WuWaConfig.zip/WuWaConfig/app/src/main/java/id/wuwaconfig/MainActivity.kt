package id.wuwaconfig

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Delete as DeleteOutlined
import androidx.compose.material.icons.outlined.FolderOpen as FolderOpenOutlined
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

val ACCENTS = listOf(0xFF6B5FDB, 0xFF4A8BDB, 0xFF4AA37A, 0xFFC95A82, 0xFFD0663C, 0xFFB8802F).map { Color(it) }
val PANEL = Color(0xE6101015)
val CHIP = Color(0xFF1A1A22)
const val DISCORD_URL = "https://discord.gg/EFaCxujTcC"

class MainActivity : ComponentActivity() {
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> ShizukuShell.refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { ShizukuShell.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { ShizukuShell.refresh() }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        ShizukuShell.init(this)
        ShizukuShell.refresh()
        setContent { App() }
    }

    override fun onResume() { super.onResume(); ShizukuShell.refresh() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(0) }
    var accent by remember { mutableStateOf(prefs.getInt("accent", 0)) }
    // Wallpaper bawaan: taruh gambar di app/src/main/assets/wallpaper_default.jpg (opsional).
    val defaultWall = remember {
        try {
            ctx.assets.open("wallpaper_default.jpg").use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 })
            }?.asImageBitmap()
        } catch (_: Exception) { null }
    }
    var wall by remember { mutableStateOf(prefs.getInt("wall", if (defaultWall != null) 1 else 0)) } // 0 tanpa,1 gambar,2 ungu,3 biru
    var dim by remember { mutableStateOf(prefs.getFloat("dim", 0f)) }
    var blurOn by remember { mutableStateOf(prefs.getBoolean("blur", false)) }
    val wallFile = File(ctx.filesDir, "wallpaper.jpg")
    var wallVersion by remember { mutableStateOf(0) }
    val ac = ACCENTS[accent]

    val pickWall = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            ctx.contentResolver.openInputStream(uri)?.use { i -> wallFile.outputStream().use { o -> i.copyTo(o) } }
            wall = 1; prefs.edit().putInt("wall", 1).apply(); wallVersion++
        }
    }
    val wallBitmap = remember(wallVersion, wall) {
        if (wall != 1) null
        else if (wallFile.exists()) BitmapFactory.decodeFile(wallFile.path,
            BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
        else defaultWall
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = ac)) {
        Box(Modifier.fillMaxSize().background(when (wall) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); else -> Color.Black })) {
            if (wallBitmap != null) {
                Image(wallBitmap, null, Modifier.fillMaxSize().then(if (blurOn) Modifier.blur(16.dp) else Modifier),
                    contentScale = ContentScale.Crop)
            }
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            Column(Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -150f && tab < 3) tab++ else if (total > 150f && tab > 0) tab-- },
                        onHorizontalDrag = { _, d -> total += d })
                }
                .statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp)) {
                val heads = listOf(
                    "WuWa Config" to "Pilih, lalu install config", "Edit" to "Tulis atau tempel tweak config.",
                    "Tampilan" to "Atur warna dan wallpaper.", "Settings" to "Atur akses dan aplikasi.")
                val shadow = androidx.compose.ui.text.TextStyle(shadow = Shadow(Color.Black.copy(0.6f), Offset(0f, 3f), 10f))
                Row(Modifier.padding(top = 16.dp).fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        AnimatedContent(targetState = tab, label = "judul",
                            transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(140)) }) { t ->
                            Column {
                                Text(heads[t].first, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White, style = shadow)
                                Text(heads[t].second, color = Color.White.copy(0.85f), style = shadow)
                            }
                        }
                    }
                    AnimatedVisibility(visible = tab == 0, enter = fadeIn(tween(250)), exit = fadeOut(tween(150))) { StatusChip() }
                }
                Spacer(Modifier.weight(1f))
                Panel {
                    AnimatedContent(targetState = tab, label = "tab",
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (slideInHorizontally(tween(340)) { it * dir / 3 } + fadeIn(tween(340))) togetherWith
                                (slideOutHorizontally(tween(340)) { -it * dir / 3 } + fadeOut(tween(160)))
                        }) { t ->
                    when (t) {
                        0 -> Home(ac)
                        1 -> Editor(ac)
                        2 -> Look(ac, accent, { accent = it; prefs.edit().putInt("accent", it).apply() },
                            wall, { w -> if (w == 1 && !wallFile.exists() && defaultWall == null) pickWall.launch("image/*") else if (w == 1) { wall = 1; prefs.edit().putInt("wall", 1).apply() } else { wall = w; prefs.edit().putInt("wall", w).apply() } },
                            { pickWall.launch("image/*") }, dim, { dim = it; prefs.edit().putFloat("dim", it).apply() },
                            blurOn, { blurOn = it; prefs.edit().putBoolean("blur", it).apply() }, wallBitmap)
                        else -> SettingsTab(ac)
                    }
                    }
                }
                Spacer(Modifier.height(12.dp))
                NavBar(tab, ac) { tab = it }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable fun Panel(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(PANEL).animateContentSize(tween(300)).padding(16.dp), content = content)

@Composable fun StatusChip() {
    val s = ShizukuShell.status.value
    val name = if (ShizukuShell.isRoot()) "Root" else "Shizuku"
    val (txt, col) = when (s) { 2 -> name to Color(0xFF5BD68E); 1 -> "Izinkan" to Color(0xFFE0B040); else -> "$name off" to Color(0xFFE06060) }
    Row(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x99000000)).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(col)); Spacer(Modifier.width(8.dp))
        Text(txt, color = col, fontWeight = FontWeight.SemiBold)
    }
}

@Composable fun NavBar(sel: Int, ac: Color, onSel: (Int) -> Unit) {
    val items = listOf("Beranda" to Icons.Default.Home, "Edit" to Icons.Default.Edit, "Tampilan" to Icons.Default.Palette, "Settings" to Icons.Default.Settings)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(PANEL).padding(8.dp)) {
        items.forEachIndexed { i, (n, ic) ->
            val on = i == sel
            val bgc by animateColorAsState(if (on) Color.Black.copy(0.6f) else Color.Transparent, tween(260), label = "navbg")
            val tint by animateColorAsState(if (on) ac else Color.Gray, tween(260), label = "navtint")
            val sc by animateFloatAsState(if (on) 1.18f else 1f, spring(dampingRatio = 0.45f, stiffness = 380f), label = "navscale")
            Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                .background(bgc)
                .clickable { onSel(i) }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(ic, n, tint = tint, modifier = Modifier.graphicsLayer(scaleX = sc, scaleY = sc))
                Text(n, fontSize = 13.sp, color = tint)
            }
        }
    }
}

@Composable fun Btn(text: String, ac: Color, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true,
                    icon: ImageVector? = null, iconTint: Color = Color.White, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(20.dp)).background(if (filled) ac else CHIP).alpha(if (enabled) 1f else 0.4f)
        .clickable(enabled = enabled, onClick = onClick).padding(16.dp), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) { Icon(icon, null, tint = iconTint); Spacer(Modifier.width(10.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = if (filled) 20.sp else 16.sp)
        }
    }
}

/** Pastikan Shizuku siap & game terpasang; panggil aksi di thread IO. */
fun runWithGame(ctx: Context, scope: kotlinx.coroutines.CoroutineScope, notifyLabel: String? = null, block: (String) -> String?) {
    ShizukuShell.refresh()
    when (ShizukuShell.status.value) {
        0 -> { toast(ctx, if (ShizukuShell.isRoot()) "Root tidak tersedia di perangkat ini." else "Shizuku belum berjalan. Nyalakan dulu Shizuku."); return }
        1 -> { ShizukuShell.requestPermission(); toast(ctx, if (ShizukuShell.isRoot()) "Izinkan akses root, lalu coba lagi." else "Izinkan akses Shizuku, lalu coba lagi."); return }
    }
    val pkg = ShizukuShell.installedPackage(ctx) ?: run { toast(ctx, "Wuthering Waves tidak ditemukan."); return }
    scope.launch {
        val err = withContext(Dispatchers.IO) { block(pkg) }
        toast(ctx, err?.let { "Gagal: $it" } ?: "Berhasil. Buka game untuk mencoba.")
        if (err == null && notifyLabel != null) Notifier.installed(ctx, notifyLabel)
    }
}

@Composable fun Home(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("Flagship") }
    var quality by remember { mutableStateOf("High") }
    val manual = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        runWithGame(ctx, scope, "Config manual") { pkg ->
            var err: String? = null
            for (u in uris) {
                val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow("_display_name")) else null } ?: continue
                if (name !in INI_FILES) { err = "$name bukan file yang didukung"; continue }
                val text = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() ?: continue
                err = ShizukuShell.write(pkg, name, text) ?: err
            }
            err
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ModeCard("Flagship", "Visual stabil", Icons.Default.DesktopWindows, mode == "Flagship", ac, Modifier.weight(1f)) { mode = "Flagship" }
        ModeCard("Balanced", "Balanced stabil", Icons.Default.Balance, mode == "Balanced", ac, Modifier.weight(1f)) { mode = "Balanced" }
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Tune, null, tint = ac); Spacer(Modifier.width(12.dp))
        Text("Kualitas", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White, modifier = Modifier.weight(1f))
        Row(Modifier.clip(RoundedCornerShape(20.dp)).background(CHIP).padding(4.dp)) {
            listOf("High", "Medium").forEach { q ->
                Text(q, color = if (quality == q) Color.White else Color.Gray, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(if (quality == q) ac else Color.Transparent)
                        .clickable { quality = q }.padding(horizontal = 20.dp, vertical = 12.dp))
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Btn("Install manual", ac, Modifier.weight(1f), icon = Icons.Outlined.FolderOpenOutlined, iconTint = Color(0xFFE0B040)) { manual.launch(arrayOf("*/*")) }
        Btn("Hapus config", ac, Modifier.weight(1f), icon = Icons.Outlined.DeleteOutlined, iconTint = Color(0xFFE06070)) {
            runWithGame(ctx, scope) { ShizukuShell.delete(it, Presets.FILES) }
        }
    }
    Spacer(Modifier.height(12.dp))
    Btn("Install", ac, Modifier.fillMaxWidth(), filled = true) {
        val files = Presets.all(ctx, mode, quality)
        if (files == null) { toast(ctx, "Preset $mode $quality belum tersedia."); return@Btn }
        runWithGame(ctx, scope, "$mode $quality") { pkg ->
            var err: String? = null
            for ((name, text) in files) { err = ShizukuShell.write(pkg, name, text) ?: err }
            err
        }
    }
}

val INI_FILES = setOf("Engine.ini", "DeviceProfiles.ini", "Scalability.ini", "GameUserSettings.ini")

@Composable fun ModeCard(t: String, s: String, ic: androidx.compose.ui.graphics.vector.ImageVector, sel: Boolean, ac: Color, m: Modifier, onClick: () -> Unit) {
    Row(m.clip(RoundedCornerShape(24.dp)).background(if (sel) Color.Black else CHIP)
        .border(if (sel) 2.dp else 0.dp, if (sel) ac else Color.Transparent, RoundedCornerShape(24.dp))
        .clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = ac); Spacer(Modifier.width(10.dp))
        Column { Text(t, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White); Text(s, color = Color.Gray, fontSize = 13.sp) }
    }
}

@Composable fun Editor(ac: Color) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val names = listOf("Engine.ini", "DeviceProfiles.ini")
    val drafts = remember { mutableStateListOf(*names.map { n -> File(ctx.filesDir, n).takeIf { it.exists() }?.readText() ?: "" }.toTypedArray()) }
    var t by remember { mutableStateOf(0) }
    var presetMenu by remember { mutableStateOf(false) }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) drafts[t] = ctx.contentResolver.openInputStream(u)?.bufferedReader()?.readText() ?: drafts[t]
    }
    fun save(i: Int) = File(ctx.filesDir, names[i]).writeText(drafts[i])

    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CHIP).padding(6.dp)) {
        names.forEachIndexed { i, n ->
            Text(n, Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (t == i) ac else Color.Transparent)
                .clickable { t = i }.padding(14.dp), color = if (t == i) Color.White else Color.Gray,
                fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f)) {
            Btn("Preset", ac, Modifier.fillMaxWidth()) { presetMenu = true }
            DropdownMenu(presetMenu, { presetMenu = false }) {
                Presets.names.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = {
                    drafts[t] = Presets.file(ctx, n, names[t]) ?: drafts[t]; presetMenu = false }) }
            }
        }
        Btn("Buka file", ac, Modifier.weight(1f)) { open.launch("*/*") }
        Btn("Simpan", ac, Modifier.weight(1f), enabled = drafts[t].isNotBlank()) { save(t); toast(ctx, "Tersimpan") }
        Btn("Simpan semua", ac, Modifier.weight(1f)) { names.indices.forEach(::save); toast(ctx, "Semua tersimpan") }
    }
    Spacer(Modifier.height(10.dp))
    Box(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF0D0D12)).padding(16.dp)) {
        val hint = if (t == 0) "[/Script/Engine.RendererSettings]\nr.ScreenPercentage=100" else "[Android_High DeviceProfile]\nBaseProfileName=Android_High"
        BasicTextField(drafts[t], { drafts[t] = it }, Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFFBBBBCC), fontFamily = FontFamily.Monospace, fontSize = 15.sp, lineHeight = 26.sp),
            cursorBrush = SolidColor(ac),
            decorationBox = { inner ->
                Box {
                    if (drafts[t].isEmpty()) Text(hint, color = Color(0xFF8A8A98), fontFamily = FontFamily.Monospace, fontSize = 15.sp, lineHeight = 26.sp)
                    inner()
                }
            })
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.clip(CircleShape).background(CHIP).clickable { drafts[t] = "" }.padding(18.dp)) { Icon(Icons.Outlined.DeleteOutlined, null, tint = Color(0xFFE06070)) }
        Btn("Pasang ${names[t]}", ac, Modifier.weight(1f), filled = true, enabled = drafts[t].isNotBlank()) {
            runWithGame(ctx, scope, names[t]) { ShizukuShell.write(it, names[t], drafts[t]) }
        }
    }
}

@Composable fun Look(ac: Color, accent: Int, setAccent: (Int) -> Unit, wall: Int, setWall: (Int) -> Unit, change: () -> Unit,
                     dim: Float, setDim: (Float) -> Unit, blurOn: Boolean, setBlur: (Boolean) -> Unit, thumb: ImageBitmap? = null) {
    Text("Warna aksen", color = Color.LightGray, fontSize = 20.sp)
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        ACCENTS.forEachIndexed { i, c ->
            Box(Modifier.size(54.dp).clip(CircleShape).background(c).border(if (i == accent) 3.dp else 0.dp, Color.White, CircleShape)
                .clickable { setAccent(i) }, contentAlignment = Alignment.Center) { if (i == accent) Icon(Icons.Default.Check, null, tint = Color.White) }
        }
    }
    Text("Wallpaper", color = Color.LightGray, fontSize = 20.sp)
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf("Tanpa" to 0, "Ganti" to 1, "Ungu" to 2, "Biru" to 3).forEach { (n, w) ->
            Box(Modifier.weight(1f).height(80.dp).clip(RoundedCornerShape(16.dp))
                .background(when (w) { 2 -> Color(0xFF1B1550); 3 -> Color(0xFF14283C); 1 -> CHIP; else -> Color.Black })
                .border(if (wall == w) 2.dp else 0.dp, ac, RoundedCornerShape(16.dp))
                .clickable { if (w == 1) change() else setWall(w) }.padding(12.dp), contentAlignment = Alignment.BottomStart) {
                if (w == 1 && thumb != null) Image(thumb, null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
                Text(n, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Redup", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Slider(dim, setDim, Modifier.weight(1f).padding(horizontal = 12.dp), valueRange = 0f..0.8f)
        Text("${(dim / 0.8f * 100).toInt()}%", color = Color.LightGray)
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Blur wallpaper", Modifier.weight(1f), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Switch(blurOn, setBlur)
    }
}

@Composable fun SettingsTab(ac: Color) {
    val ctx = LocalContext.current
    val s = ShizukuShell.status.value
    val root = ShizukuShell.isRoot()
    var dlg by remember { mutableStateOf(false) }
    if (dlg) AccessDialog { dlg = false }
    Column(Modifier.padding(horizontal = 12.dp)) {
    Row(Modifier.fillMaxWidth().clickable { ShizukuShell.refresh(); dlg = true }.padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(if (root) Icons.Default.Security else Icons.Default.Power, null, tint = ac, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0A0A1A)).padding(10.dp))
        Spacer(Modifier.width(16.dp))
        Column {
            Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(when (s) { 2 -> "Terhubung"; 1 -> "Ketuk untuk beri izin"; else -> if (root) "Root tidak tersedia" else "Tidak berjalan" }, color = if (s == 2) Color(0xFF5BD68E) else Color(0xFFE0B040))
        }
    }
    Divider0()
    Row0("Gabung Discord", "", Icons.Default.SportsEsports, trailing = Icons.Default.OpenInNew) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_URL))) }
    Divider0()
    Row0("Bahasa", "Indonesia", Icons.Default.Language) {}
    Divider0()
    Row0("Cek pembaruan", "", Icons.Default.Refresh, tint = Color(0xFF5B9BE0)) { toast(ctx, "Belum ada server pembaruan (isi sendiri).") }
    Divider0()
    Row0("Tentang aplikasi", "v1.0", Icons.Default.Info, tint = Color(0xFF5BD68E)) { toast(ctx, "WuWa Config v1.0 — pemasang config via Shizuku") }
    }
}

@Composable fun Divider0() { Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.10f))) }

@Composable fun Row0(t: String, v: String, ic: ImageVector, tint: Color = Color(0xFF8E86F0), trailing: ImageVector = Icons.Default.ChevronRight, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(ic, null, tint = tint); Spacer(Modifier.width(16.dp))
        Text(t, Modifier.weight(1f), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text(v, color = Color.Gray, fontSize = 20.sp); Icon(trailing, null, tint = Color.Gray)
    }
}

@Composable fun AccessDialog(onDismiss: () -> Unit) {
    val cur = ShizukuShell.mode.value
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                    Icons.Default.Smartphone, Color(0xFF7CCFA4), Color(0xFF111916), cur == ShizukuShell.MODE_SHIZUKU) {
                    ShizukuShell.setMode(ShizukuShell.MODE_SHIZUKU)
                    if (ShizukuShell.status.value == 1) ShizukuShell.requestPermission()
                    onDismiss()
                }
                AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                    Icons.Default.Security, Color(0xFFE49A72), Color(0xFF181412), cur == ShizukuShell.MODE_ROOT) {
                    ShizukuShell.setMode(ShizukuShell.MODE_ROOT)
                    onDismiss()
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF7CCFA4), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
    )
}

@Composable fun AccessOption(title: String, desc: String, icon: ImageVector, accent: Color, bg: Color, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}
