package id.wuwaconfig

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/**
 * Folder config di dalam Download (Download/<nama folder>/).
 * Pakai MediaStore, jadi tidak butuh izin storage di Android 11+.
 */
object ConfigFolder {
    private const val KEY = "config_folder"
    const val DEFAULT = "File Config"

    /** Nama folder yang dipilih, atau null kalau belum pernah dibuat. */
    fun name(ctx: Context): String? =
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString(KEY, null)?.takeIf { it.isNotBlank() }

    fun clean(raw: String): String = raw.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trim('.')

    /** Simpan nama folder & coba buat foldernya di Download. Return nama bersih, atau null kalau tidak valid. */
    fun create(ctx: Context, raw: String): String? {
        val n = clean(raw).ifEmpty { return null }
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString(KEY, n).apply()
        runCatching { File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), n).mkdirs() }
        return n
    }

    fun path(n: String) = "Download/$n"

    /** Tulis [text] ke Download/<folder>/<fileName>. Menimpa file lama kalau ada. */
    fun write(ctx: Context, folder: String, fileName: String, text: String): Boolean = runCatching {
        val rel = Environment.DIRECTORY_DOWNLOADS + "/" + folder + "/"
        val col = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val res = ctx.contentResolver
        var uri: Uri? = res.query(col, arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(fileName, rel), null)?.use { c ->
            if (c.moveToFirst()) Uri.withAppendedPath(col, c.getLong(0).toString()) else null
        }
        if (uri == null) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream") // supaya tidak jadi .ini.txt
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            }
            uri = res.insert(col, cv)
        }
        val u = uri ?: return@runCatching false
        res.openOutputStream(u, "wt")?.use { it.write(text.toByteArray()) } != null
    }.getOrDefault(false)
}
