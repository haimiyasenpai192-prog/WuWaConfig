package id.wuwaconfig

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val GREEN = Color(0xFF5CC98A)

/** Pairing nirkabel: kartu bertahap (3 langkah), port di satu kolom, kode 6 digit di kotak-kotak terpisah. */
@Composable fun PairSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var port by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val step = AdbPair.step.value
    val busy = step == AdbPair.Step.PAIRING || step == AdbPair.Step.CONNECTING
    val ready = port.length in 4..5 && code.length == 6 && !busy
    val focus = remember { FocusRequester() }

    fun go() {
        val p = port.toIntOrNull() ?: return
        scope.launch {
            val err = withContext(Dispatchers.IO) { ShizukuShell.pairAdb(ctx, p, code) }
            if (err == null) { PairNotif.cancel(ctx); Notifier.accessSelected(ctx, "Wireless ADB"); onDismiss() }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(32.dp)).background(Color(0xFF0C0F0D))
            .border(1.dp, GREEN.copy(0.25f), RoundedCornerShape(32.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Wifi, null, tint = GREEN, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(GREEN.copy(0.12f)).padding(10.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Pairing Wireless ADB", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Cukup sekali. Setelah itu tersambung otomatis.", color = Color(0xFFA9B0B5), fontSize = 13.sp)
                }
            }

            StepRow(1, "Buka Developer options → Wireless debugging → Pair device with pairing code.", done = port.isNotEmpty()) {
                TextButton(onClick = {
                    try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
                }) { Icon(Icons.Outlined.OpenInNew, null, tint = GREEN, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Buka Developer options", color = GREEN, fontSize = 13.sp) }
            }

            StepRow(2, "Masukkan port yang tampil di dialog pairing.", done = port.length >= 4) {
                BasicTextField(port, { v -> port = v.filter { it.isDigit() }.take(5) }, singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 22.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(GREEN),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF151A17)).padding(horizontal = 16.dp, vertical = 14.dp),
                    decorationBox = { inner -> Box { if (port.isEmpty()) Text("Port, mis. 37215", color = Color.Gray, fontSize = 18.sp); inner() } })
            }

            StepRow(3, "Masukkan kode 6 digit.", done = code.length == 6) {
                Box {
                    // Kolom input asli disembunyikan; 6 kotak di atasnya hanya menampilkan isinya.
                    BasicTextField(code, { v -> code = v.filter { it.isDigit() }.take(6) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.matchParentSize().focusRequester(focus),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.Transparent), cursorBrush = SolidColor(Color.Transparent))
                    Row(Modifier.fillMaxWidth().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { focus.requestFocus() },
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        repeat(6) { i ->
                            val on = i == code.length
                            val bc by animateColorAsState(if (on) GREEN else Color.White.copy(0.12f), label = "box")
                            Box(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF151A17))
                                .border(if (on) 2.dp else 1.dp, bc, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Text(code.getOrNull(i)?.toString() ?: "", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            if (AdbPair.message.value.isNotBlank() && step != AdbPair.Step.IDLE) {
                val bad = step == AdbPair.Step.FAILED
                Text(AdbPair.message.value, color = if (bad) Color(0xFFFF8A8A) else GREEN, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Via notifikasi", GREEN, Modifier.weight(1f), icon = Icons.Outlined.NotificationsActive, enabled = port.length in 4..5 && !busy) {
                    PairNotif.show(ctx, port.toInt()); toast(ctx, "Tarik bayangan notifikasi, lalu balas dengan kode.")
                }
                Btn(if (busy) "Memproses…" else "Pair", GREEN, Modifier.weight(1f), filled = true, enabled = ready) { go() }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Tutup", color = Color(0xFF8E86F0)) }
        }
    }
}

@Composable private fun StepRow(n: Int, text: String, done: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(if (done) GREEN else Color(0xFF1E2421)), contentAlignment = Alignment.Center) {
            if (done) Icon(Icons.Outlined.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
            else Text("$n", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, color = Color(0xFFC4CACE), fontSize = 14.sp, lineHeight = 19.sp)
            content()
        }
    }
}
