package id.wuwaconfig

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Preset config disimpan sebagai file ZIP, satu zip = satu versi config (contoh: v1.0.zip).
 *
 * Susunan folder di dalam zip (folder pembungkus di luar boleh ada, huruf besar/kecil bebas).
 * Dua gaya yang didukung:
 *
 * 1) Folder bernomor "[ N ] Nama": nomor = urutan tombol, "Nama" = label tombol.
 *      [ 1 ] Flagship/   [ 2 ] Mid~range/   Balancand/[ 1 ] Ultra/   Balancand/[ 2 ] High/
 * 2) Folder biasa tanpa nomor, urutan otomatis (ultra, flagship, high, mid/medium, low):
 *      flagship/   mid-range/   balanced/high/   balanced/medium/
 *    Format lama flagship_high, balanced_medium, dst. juga terbaca (label: High, Medium).
 *
 * 3) Folder tingkat berdiri sendiri: ultra/  high/  medium/ (tanpa folder flagship atau balanced). Tiap folder jadi
 *    satu pilihan, dan pilihan Flagship/Balanced di Beranda disembunyikan untuk versi ini. File .ini di root zip juga
 *    diterima (label "Custom"). Kalau zip punya folder flagship/balanced, pilihan mode tampil seperti biasa.
 *    Mau isi berbeda per mode? Taruh di flagship/ultra, flagship/high, balanced/high, balanced/medium, dst.
 *
 * File yang dikenali: Engine.ini, DeviceProfiles.ini, Scalability.ini, GameUserSettings.ini, AndroidEngine.ini (dipasang ke folder Engine game, ditulis terakhir supaya menimpa salinan dari Engine.ini). Semua yang ada di folder
 * tingkat itu ikut terpasang saat Install.
 *
 * Aturan umum:
 * - Mode Balanced = ada folder di jalurnya yang namanya mengandung "balanc" (Balanced/Balancand).
 *   Mode Flagship = ada folder "flagship" atau yang berawalan "mid" (mid-range).
 * - Tiap folder tingkat berisi satu atau lebih file config di atas (biasanya Engine.ini dan DeviceProfiles.ini).
 * - "~" di nama folder ditampilkan sebagai "-".
 *
 * Lokasi zip:
 *   1. Bawaan aplikasi: app/src/main/assets/presets/c1.bin (zip config terenkripsi, lihat Vault.kt; daftar di ENCRYPTED), atau <versi>.zip biasa (tidak terenkripsi)
 *   2. Diimpor dari HP lewat dialog "Pilih config" -> "Impor zip" (disimpan di filesDir/presets/).
 *      Zip hasil impor menimpa zip bawaan yang namanya sama.
 *   3. Zip hasil impor bisa dihapus lewat ikon sampah di dialog "Pilih config". Zip bawaan tidak bisa dihapus.
 */
object Presets {
    /** File config yang dikenali di dalam zip (urutan = urutan pemasangan). */
    val ALL_FILES = listOf("Engine.ini", "DeviceProfiles.ini", "Scalability.ini", "GameUserSettings.ini", "AndroidEngine.ini")
    /** File yang dihapus oleh tombol "Hapus config". GameUserSettings.ini sengaja tidak ikut karena itu pengaturan milik game. */
    val REMOVABLE = listOf("Engine.ini", "DeviceProfiles.ini", "Scalability.ini")
    private val ALL_LC = ALL_FILES.map { it.lowercase() }.toSet()
    private const val KEY = "config_version"
    private const val ASSET_DIR = "presets"

    /** Satu tingkat kualitas: label tombol + isi file (nama file asli -> teks). */
    class Tier(val label: String, val files: Map<String, String>, val order: Int = 0)

    /** Hasil baca zip. [modeless] = zip tanpa folder flagship/balanced (hanya folder tingkat seperti ultra/high), jadi pilihan mode disembunyikan. */
    class Parsed(val byMode: Map<String, List<Tier>>, val modeless: Boolean)

    private val cache = mutableMapOf<String, Parsed>()

    private fun importedDir(ctx: Context) = File(ctx.filesDir, ASSET_DIR)

    /** Config bawaan terenkripsi: nama versi -> nama file di assets/presets (lihat Vault.kt). */
    private val ENCRYPTED = mapOf("config_v1.2_release" to "c1.bin")

    private fun openZip(ctx: Context, version: String): InputStream? {
        val f = File(importedDir(ctx), "$version.zip")
        if (f.exists()) return f.inputStream()
        ENCRYPTED[version]?.let { n -> Vault.open(ctx, "$ASSET_DIR/$n")?.let { return java.io.ByteArrayInputStream(it) } }
        return try { ctx.assets.open("$ASSET_DIR/$version.zip") } catch (_: Exception) { null }
    }

    private fun clean(s: String) = s.replace('~', '-').replace('_', ' ').trim()

    private val NUMBERED = Regex("^\\[\\s*(\\d+)\\s*]\\s*(.*)$")
    private val MODE_PREFIX = Regex("^(?:flagship|balanc\\w*)[_ -]+(.+)$", RegexOption.IGNORE_CASE)

    private class Raw(val mode: String, val order: Int, val label: String, val file: String, val text: String)
    private class Flat(val order: Int?, val label: String, val file: String, val text: String)

    /** Urutan bawaan untuk folder tanpa nomor: makin kecil makin tinggi kualitasnya. */
    private fun rank(label: String): Int {
        val l = label.lowercase()
        return when {
            "ultra" in l -> 0
            "flagship" in l -> 1
            "high" in l -> 2
            "mid" in l || "medium" in l -> 3
            "low" in l -> 4
            else -> 5
        }
    }

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    /** Baca zip jadi peta mode ("Flagship"/"Balanced") -> daftar tingkat, terurut. Zip tanpa susunan dikenali jatuh ke mode bebas (lihat bawah). */
    private fun parse(stream: InputStream): Parsed {
        val raws = mutableListOf<Raw>()
        val flats = mutableListOf<Flat>()
        val numbered = mutableListOf<Raw>()
        ZipInputStream(stream).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val segs = e.name.replace('\\', '/').split('/').filter { it.isNotEmpty() }
                if (segs.isEmpty() || segs[0] == "__MACOSX") continue
                val file = segs.last()
                if (file.startsWith("._") || file.lowercase() !in ALL_LC) continue
                val folder = if (segs.size >= 2) segs[segs.size - 2].trim() else ""
                val folders = segs.dropLast(1).map { it.lowercase() }
                val mode = when {
                    folders.any { "balanc" in it } -> "Balanced"
                    folders.any { "flagship" in it || it.startsWith("mid") } -> "Flagship"
                    else -> null
                }
                val num = NUMBERED.find(folder)
                val text = String(z.readBytes(), Charsets.UTF_8)
                if (mode == null) {
                    // Tanpa folder flagship/balanced. Bernomor: sementara dianggap Flagship (mis. "[ 2 ] Mid~range"),
                    // kecuali seluruh zip tidak punya folder mode sama sekali (lihat bawah).
                    if (num != null) numbered += Raw("Flagship", num.groupValues[1].toInt(), cap(clean(num.groupValues[2])), file, text)
                    else flats += Flat(null, cap(clean(folder)).ifBlank { "Custom" }, file, text)
                    continue
                }
                if (num != null) {
                    raws += Raw(mode, num.groupValues[1].toInt(), cap(clean(num.groupValues[2])), file, text)
                } else {
                    val label = cap(clean(MODE_PREFIX.find(folder)?.groupValues?.get(1) ?: folder))
                    raws += Raw(mode, rank(label), label, file, text)
                }
            }
        }
        if (raws.isEmpty()) numbered.forEach { flats += Flat(it.order, it.label, it.file, it.text) } else raws += numbered
        fun build(groups: Map<Pair<Int, String>, List<Pair<String, String>>>): List<Tier> =
            groups.entries.sortedWith(compareBy({ it.key.first }, { it.key.second })).map { (k, fs) -> Tier(k.second, fs.toMap(), k.first) }

        val byMode = raws.groupBy { it.mode }.mapValues { (_, list) ->
            build(list.groupBy({ it.order to it.label }, { it.file to it.text }))
        }.filterValues { it.isNotEmpty() }

        // Folder tingkat yang berdiri sendiri (mis. ultra/, high/, medium/ tanpa folder flagship atau balanced):
        // tiap folder jadi satu pilihan dan muncul di mode Flagship maupun Balanced. Jika zip juga punya folder
        // per mode, pilihan bersama ini ditambahkan ke kedua mode (kecuali namanya sudah ada di mode itu).
        val shared = build(flats.groupBy({ (it.order ?: rank(it.label)) to it.label }, { it.file to it.text }))
        if (shared.isEmpty()) return Parsed(byMode, false)
        val merged = listOf("Flagship", "Balanced").associateWith { m ->
            val own = byMode[m] ?: emptyList()
            val extra = shared.filter { t -> own.none { it.label.equals(t.label, ignoreCase = true) } }
            (own + extra).sortedWith(compareBy({ it.order }, { it.label }))
        }
        // Zip hanya berisi folder tingkat (tanpa folder flagship/balanced): pilihan mode disembunyikan di Beranda.
        return Parsed(merged, modeless = byMode.isEmpty())
    }

    private fun load(ctx: Context, version: String): Parsed =
        cache.getOrPut(version) { try { openZip(ctx, version)?.let { parse(it) } ?: Parsed(emptyMap(), false) } catch (_: Exception) { Parsed(emptyMap(), false) } }

    /** True jika versi ini tidak punya folder flagship/balanced, jadi tombol mode tidak ditampilkan. */
    fun modeless(ctx: Context, version: String): Boolean = load(ctx, version).modeless

    private fun versionOrder(): Comparator<String> = Comparator { a, b ->
        val x = Regex("\\d+").findAll(a).map { it.value.toLong() }.toList()
        val y = Regex("\\d+").findAll(b).map { it.value.toLong() }.toList()
        var r = 0
        for (i in 0 until maxOf(x.size, y.size)) {
            r = (x.getOrElse(i) { -1L }).compareTo(y.getOrElse(i) { -1L })
            if (r != 0) break
        }
        if (r != 0) r else a.compareTo(b, ignoreCase = true)
    }

    /** Daftar versi config (nama zip tanpa .zip), dari assets dan hasil impor. */
    fun versions(ctx: Context): List<String> {
        val bundled = try { ctx.assets.list(ASSET_DIR)?.toList() } catch (_: Exception) { null } ?: emptyList()
        val imported = importedDir(ctx).list()?.toList() ?: emptyList()
        val enc = ENCRYPTED.filterValues { n -> bundled.any { it.equals(n, ignoreCase = true) } }.keys
        return ((bundled + imported).filter { it.endsWith(".zip", ignoreCase = true) }
            .map { it.dropLast(4) } + enc).distinct().sortedWith(versionOrder())
    }

    /** Versi yang sedang dipilih (disimpan di prefs); default versi terbaru. Kosong ("") kalau belum ada config sama sekali. */
    fun current(ctx: Context): String {
        val saved = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString(KEY, null)
        val all = versions(ctx)
        return if (saved != null && saved in all) saved else all.lastOrNull() ?: ""
    }

    fun setCurrent(ctx: Context, version: String) {
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString(KEY, version).apply()
    }

    /** Impor zip dari HP. Mengembalikan pesan error, atau null kalau berhasil. */
    fun importZip(ctx: Context, uri: Uri, displayName: String): String? {
        if (!displayName.endsWith(".zip", ignoreCase = true)) return "$displayName bukan file zip"
        val version = displayName.dropLast(4).replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
        if (version.isEmpty()) return "Nama zip tidak valid"
        val dir = importedDir(ctx).also { it.mkdirs() }
        val tmp = File(dir, "$version.zip.tmp")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                ?: return "Tidak bisa membuka file"
            val parsed = tmp.inputStream().use { parse(it) }
            if (parsed.byMode.isEmpty()) { tmp.delete(); return "Zip tidak berisi file config (Engine.ini, DeviceProfiles.ini, Scalability.ini, atau GameUserSettings.ini)" }
            val dest = File(dir, "$version.zip")
            dest.delete()
            if (!tmp.renameTo(dest)) { tmp.delete(); return "Gagal menyimpan zip" }
            cache.remove(version)
            setCurrent(ctx, version)
            null
        } catch (e: Exception) { tmp.delete(); AppLog.e("Impor", "Zip $displayName error: ${e.javaClass.simpleName}: ${e.message}"); "Zip rusak atau tidak bisa dibaca" }
    }

    private val LEAD_CONFIG = Regex("^config\\b[\\s:.-]*", RegexOption.IGNORE_CASE)
    private val V_SPACE = Regex("\\bv\\s+(?=\\d)", RegexOption.IGNORE_CASE)

    /** Nama rapi dari nama zip: "_" jadi spasi, kata "Config" di depan dibuang, "v 1.1" jadi "v1.1". */
    fun displayName(version: String): String {
        var s = version.replace('_', ' ').replace(Regex("\\s+"), " ").trim()
        while (true) {
            val m = LEAD_CONFIG.find(s) ?: break
            if (m.value.isEmpty()) break
            s = s.substring(m.range.last + 1).trim()
        }
        s = V_SPACE.replace(s, "v").trim(' ', '-', '.')
        return s.ifBlank { version }
    }

    /** Judul untuk daftar: nama rapi; kalau hanya nomor versi (mis. "v1.1") diberi awalan "Config". */
    fun title(version: String): String {
        val n = displayName(version)
        return if (Regex("^v?\\d", RegexOption.IGNORE_CASE).containsMatchIn(n)) "Config $n" else n
    }

    /** Ringkasan isi satu versi untuk daftar config, mis. "Flagship 2 • Balanced 2" atau "3 tingkat kualitas". */
    fun summary(ctx: Context, version: String): String {
        val f = tiers(ctx, version, "Flagship"); val b = tiers(ctx, version, "Balanced")
        return when {
            f.isEmpty() && b.isEmpty() -> "Config kosong"
            modeless(ctx, version) -> "${f.size} tingkat kualitas"
            else -> listOfNotNull(f.takeIf { it.isNotEmpty() }?.let { "Flagship ${it.size}" }, b.takeIf { it.isNotEmpty() }?.let { "Balanced ${it.size}" }).joinToString(" • ")
        }
    }

    /** True jika versi ini ada di bawaan aplikasi (assets). */
    fun isBundled(ctx: Context, version: String): Boolean =
        try {
            val l = ctx.assets.list(ASSET_DIR)
            l?.any { it.equals("$version.zip", ignoreCase = true) } == true ||
                (ENCRYPTED[version]?.let { n -> l?.any { it.equals(n, ignoreCase = true) } } == true)
        } catch (_: Exception) { false }

    /** True jika versi ini punya zip hasil impor (bisa dihapus). Config bawaan aplikasi tidak bisa dihapus. */
    fun isImported(ctx: Context, version: String): Boolean = File(importedDir(ctx), "$version.zip").exists()

    /**
     * Hapus zip hasil impor. Kalau ada config bawaan dengan nama sama, config bawaan itu yang dipakai lagi.
     * Mengembalikan true kalau berhasil.
     */
    fun deleteImported(ctx: Context, version: String): Boolean {
        val f = File(importedDir(ctx), "$version.zip")
        val ok = !f.exists() || f.delete()
        cache.remove(version)
        return ok
    }

    /** Tingkat kualitas yang tersedia untuk satu mode di versi tertentu (kosong jika tidak ada). */
    fun tiers(ctx: Context, version: String, mode: String): List<Tier> = load(ctx, version).byMode[mode] ?: emptyList()

    /** File satu preset (Engine.ini dan, kalau ada, DeviceProfiles.ini), atau null jika tidak tersedia. */
    fun files(ctx: Context, version: String, mode: String, tier: Int): Map<String, String>? {
        val t = tiers(ctx, version, mode).getOrNull(tier) ?: return null
        val out = linkedMapOf<String, String>()
        for (n in ALL_FILES) { t.files.entries.firstOrNull { it.key.equals(n, ignoreCase = true) }?.let { out[n] = it.value } }
        return out.takeIf { it.isNotEmpty() }
    }

    /** Semua preset di versi terpilih untuk tab Edit: (judul, mode, indeks tingkat). */
    fun options(ctx: Context): List<Triple<String, String, Int>> {
        val v = current(ctx)
        if (modeless(ctx, v)) return tiers(ctx, v, "Flagship").mapIndexed { i, t -> Triple(t.label, "Flagship", i) }
        return listOf("Flagship", "Balanced").flatMap { m ->
            tiers(ctx, v, m).mapIndexed { i, t -> Triple("$m ${t.label}", m, i) }
        }
    }

    fun file(ctx: Context, mode: String, tier: Int, name: String): String? = files(ctx, current(ctx), mode, tier)?.get(name)
}
