package id.wuwaconfig

import android.content.Context

/**
 * Preset config Flagship (Engine.ini + DeviceProfiles.ini) disimpan di assets:
 * assets/flagship_high/ dan assets/flagship_medium/.
 * Balanced belum punya file config, jadi belum tersedia.
 */
object Presets {
    val FILES = listOf("Engine.ini", "DeviceProfiles.ini")
    val names = listOf("Flagship High", "Flagship Medium")

    private fun folder(mode: String, quality: String): String? =
        if (mode == "Flagship") "flagship_${quality.lowercase()}" else null

    /** Baca satu file preset; null jika preset tidak tersedia. Isi dibaca apa adanya (CRLF dipertahankan). */
    fun file(ctx: Context, mode: String, quality: String, name: String): String? {
        val f = folder(mode, quality) ?: return null
        return try { ctx.assets.open("$f/$name").bufferedReader().use { it.readText() } } catch (e: Exception) { null }
    }

    /** Semua file untuk satu preset (Engine.ini + DeviceProfiles.ini), atau null jika belum tersedia. */
    fun all(ctx: Context, mode: String, quality: String): Map<String, String>? {
        val m = FILES.associateWith { file(ctx, mode, quality, it) ?: return null }
        return m
    }

    fun file(ctx: Context, presetName: String, name: String): String? {
        val (m, q) = presetName.split(" ")
        return file(ctx, m, q, name)
    }
}
