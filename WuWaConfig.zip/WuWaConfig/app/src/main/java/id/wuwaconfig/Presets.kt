package id.wuwaconfig

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Preset config disimpan sebagai file ZIP, satu zip = satu versi config (contoh: v1.0.zip).
 *
 * Susunan folder di dalam zip (folder pembungkus di luar boleh ada, huruf besar/kecil bebas).
 * Dua gaya yang didukung:
 *
 * 1) Folder bernomor "[ N ] Nama": nomor = urutan tombol, "Nama" = label tombol.
 *      [ 1 ] Flagship/   [ 2 ] Mid~range/   Balancand/[ 1 ] Ultra/   Balancand/[ 2 ] High/
 * 2) Folder biasa tanpa nomor, urutan otomatis (ultra, flagship, high, mid/medium, low):
 *      flagship/   mid-range/   balanced/high/   balanced/medium/
 *    Format lama flagship_high, balanced_medium, dst. juga terbaca (label: High, Medium).
 *
 * Aturan umum:
 * - Mode Balanced = ada folder di jalurnya yang namanya mengandung "balanc" (Balanced/Balancand).
 *   Mode Flagship = ada folder "flagship" atau yang berawalan "mid" (mid-range).
 * - Tiap folder tingkat berisi Engine.ini dan DeviceProfiles.ini.
 * - "~" di nama folder ditampilkan sebagai "-".
 *
 * Lokasi zip:
 *   1. Bawaan aplikasi: app/src/main/assets/presets/<versi>.zip
 *   2. Diimpor dari HP lewat dialog "Pilih config" -> "Impor zip" (disimpan di filesDir/presets/).
 *      Zip hasil impor menimpa zip bawaan yang namanya sama.
 */
object Presets {
    val FILES = listOf("Engine.ini", "DeviceProfiles.ini")
    private const val KEY = "config_version"
    private const val ASSET_DIR = "presets"

    /** Satu tingkat kualitas: label tombol + isi file (nama file asli -> teks). */
    class Tier(val label: String, val files: Map<String, String>)

    private val cache = mutableMapOf<String, Map<String, List<Tier>>>()

    private fun importedDir(ctx: Context) = File(ctx.filesDir, ASSET_DIR)

    private fun openZip(ctx: Context, version: String): InputStream? {
        val f = File(importedDir(ctx), "$version.zip")
        if (f.exists()) return f.inputStream()
        return try { ctx.assets.open("$ASSET_DIR/$version.zip") } catch (_: Exception) { null }
    }

    private fun clean(s: String) = s.replace('~', '-').replace('_', ' ').trim()

    private val NUMBERED = Regex("^\\[\\s*(\\d+)\\s*]\\s*(.*)$")
    private val MODE_PREFIX = Regex("^(?:flagship|balanc\\w*)[_ -]+(.+)$", RegexOption.IGNORE_CASE)

    private class Raw(val mode: String, val order: Int, val label: String, val file: String, val text: String)

    /** Urutan bawaan untuk folder tanpa nomor: makin kecil makin tinggi kualitasnya. */
    private fun rank(label: String): Int {
        val l = label.lowercase()
        return when {
            "ultra" in l -> 0
            "flagship" in l -> 1
            "high" in l -> 2
            "mid" in l || "medium" in l -> 3
            "low" in l -> 4
            else -> 5
        }
    }

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    /** Baca zip jadi peta mode ("Flagship"/"Balanced") -> daftar tingkat, terurut. Hanya tingkat yang punya Engine.ini. */
    private fun parse(stream: InputStream): Map<String, List<Tier>> {
        val raws = mutableListOf<Raw>()
        ZipInputStream(stream).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val segs = e.name.replace('\\', '/').split('/').filter { it.isNotEmpty() }
                if (segs.size < 2 || segs[0] == "__MACOSX") continue
                val file = segs.last()
                if (file.startsWith("._") || !file.endsWith(".ini", ignoreCase = true)) continue
                val folder = segs[segs.size - 2].trim()
                val folders = segs.dropLast(1).map { it.lowercase() }
                val mode = when {
                    folders.any { "balanc" in it } -> "Balanced"
                    folders.any { "flagship" in it || it.startsWith("mid") } -> "Flagship"
                    else -> null
                }
                val num = NUMBERED.find(folder)
                if (num == null && mode == null) continue
                val text = String(z.readBytes(), Charsets.UTF_8)
                if (num != null) {
                    raws += Raw(mode ?: "Flagship", num.groupValues[1].toInt(), cap(clean(num.groupValues[2])), file, text)
                } else {
                    val label = cap(clean(MODE_PREFIX.find(folder)?.groupValues?.get(1) ?: folder))
                    raws += Raw(mode!!, rank(label), label, file, text)
                }
            }
        }
        return raws.groupBy { it.mode }.mapValues { (_, list) ->
            list.groupBy { it.order to it.label }.entries.sortedWith(compareBy({ it.key.first }, { it.key.second })).mapNotNull { (k, rs) ->
                val files = rs.associate { it.file to it.text }
                if (files.keys.none { it.equals("Engine.ini", ignoreCase = true) }) null else Tier(k.second, files)
            }
        }.filterValues { it.isNotEmpty() }
    }

    private fun load(ctx: Context, version: String): Map<String, List<Tier>> =
        cache.getOrPut(version) { try { openZip(ctx, version)?.let { parse(it) } ?: emptyMap() } catch (_: Exception) { emptyMap() } }

    private fun versionOrder(): Comparator<String> = Comparator { a, b ->
        val x = Regex("\\d+").findAll(a).map { it.value.toLong() }.toList()
        val y = Regex("\\d+").findAll(b).map { it.value.toLong() }.toList()
        var r = 0
        for (i in 0 until maxOf(x.size, y.size)) {
            r = (x.getOrElse(i) { -1L }).compareTo(y.getOrElse(i) { -1L })
            if (r != 0) break
        }
        if (r != 0) r else a.compareTo(b, ignoreCase = true)
    }

    /** Daftar versi config (nama zip tanpa .zip), dari assets dan hasil impor. */
    fun versions(ctx: Context): List<String> {
        val bundled = try { ctx.assets.list(ASSET_DIR)?.toList() } catch (_: Exception) { null } ?: emptyList()
        val imported = importedDir(ctx).list()?.toList() ?: emptyList()
        return (bundled + imported).filter { it.endsWith(".zip", ignoreCase = true) }
            .map { it.dropLast(4) }.distinct().sortedWith(versionOrder())
    }

    /** Versi yang sedang dipilih (disimpan di prefs); default versi terbaru. */
    fun current(ctx: Context): String {
        val saved = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getString(KEY, null)
        val all = versions(ctx)
        return if (saved != null && saved in all) saved else all.lastOrNull() ?: "v1.0"
    }

    fun setCurrent(ctx: Context, version: String) {
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putString(KEY, version).apply()
    }

    /** Impor zip dari HP. Mengembalikan pesan error, atau null kalau berhasil. */
    fun importZip(ctx: Context, uri: Uri, displayName: String): String? {
        if (!displayName.endsWith(".zip", ignoreCase = true)) return "$displayName bukan file zip"
        val version = displayName.dropLast(4).replace(Regex("[^A-Za-z0-9._ -]"), "_").trim()
        if (version.isEmpty()) return "Nama zip tidak valid"
        val dir = importedDir(ctx).also { it.mkdirs() }
        val tmp = File(dir, "$version.zip.tmp")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                ?: return "Tidak bisa membuka file"
            val parsed = tmp.inputStream().use { parse(it) }
            if (parsed.isEmpty()) { tmp.delete(); return "Zip tidak berisi preset yang dikenali (butuh Engine.ini di folder bernomor)" }
            val dest = File(dir, "$version.zip")
            dest.delete()
            if (!tmp.renameTo(dest)) { tmp.delete(); return "Gagal menyimpan zip" }
            cache.remove(version)
            setCurrent(ctx, version)
            null
        } catch (e: Exception) { tmp.delete(); "Zip rusak atau tidak bisa dibaca" }
    }

    /** Tingkat kualitas yang tersedia untuk satu mode di versi tertentu (kosong jika tidak ada). */
    fun tiers(ctx: Context, version: String, mode: String): List<Tier> = load(ctx, version)[mode] ?: emptyList()

    /** File satu preset (Engine.ini dan, kalau ada, DeviceProfiles.ini), atau null jika tidak tersedia. */
    fun files(ctx: Context, version: String, mode: String, tier: Int): Map<String, String>? {
        val t = tiers(ctx, version, mode).getOrNull(tier) ?: return null
        val out = linkedMapOf<String, String>()
        for (n in FILES) { t.files.entries.firstOrNull { it.key.equals(n, ignoreCase = true) }?.let { out[n] = it.value } }
        return out.takeIf { it.containsKey("Engine.ini") }
    }

    /** Semua preset di versi terpilih untuk tab Edit: (judul, mode, indeks tingkat). */
    fun options(ctx: Context): List<Triple<String, String, Int>> {
        val v = current(ctx)
        return listOf("Flagship", "Balanced").flatMap { m ->
            tiers(ctx, v, m).mapIndexed { i, t -> Triple("$m ${t.label}", m, i) }
        }
    }

    fun file(ctx: Context, mode: String, tier: Int, name: String): String? = files(ctx, current(ctx), mode, tier)?.get(name)
}
