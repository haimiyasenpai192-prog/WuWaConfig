package id.wuwaconfig

/**
 * Preset contoh (tulisan sendiri, konservatif). Ubah sesuka hati lewat tab Edit.
 * Preset hanya mengisi Engine.ini; DeviceProfiles.ini sengaja tidak disentuh.
 */
object Presets {
    val names = listOf("Flagship High", "Flagship Medium", "Balanced High", "Balanced Medium")

    fun engine(mode: String, quality: String): String {
        val high = quality == "High"
        val flagship = mode == "Flagship"
        val sp = if (flagship) 100 else if (high) 90 else 80
        val shadow = if (flagship && high) 2048 else if (high) 1024 else 512
        val aniso = if (flagship) 8 else 4
        return """
[SystemSettings]
r.ScreenPercentage=$sp
r.Shadow.MaxCSMResolution=$shadow
r.MaxAnisotropy=$aniso
r.ViewDistanceScale=${if (flagship) "1.0" else "0.8"}
""".trimStart()
    }

    fun byName(n: String): String {
        val (m, q) = n.split(" ")
        return engine(m, q)
    }
}
