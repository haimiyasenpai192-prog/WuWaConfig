package id.wuwaconfig

import android.content.Context

/**
 * Preset config (Engine.ini + DeviceProfiles.ini) disimpan di assets:
 * flagship_high/, flagship_medium/, balanced_high/, balanced_medium/.
 */
object Presets {
    val FILES = listOf("Engine.ini", "DeviceProfiles.ini")
    val names = listOf("Flagship High", "Flagship Medium", "Balanced High", "Balanced Medium")

    private fun folder(mode: String, quality: String): String? =
        if (mode == "Flagship" || mode == "Balanced") "${mode.lowercase()}_${quality.lowercase()}" else null

    /** Baca satu file preset; null jika preset tidak tersedia. Isi dibaca apa adanya (CRLF dipertahankan). */
    fun file(ctx: Context, mode: String, quality: String, name: String): String? {
        val f = folder(mode, quality) ?: return null
        return try { ctx.assets.open("$f/$name").bufferedReader().use { it.readText() } } catch (e: Exception) { null }
    }

    /** Semua file untuk satu preset (Engine.ini + DeviceProfiles.ini), atau null jika belum tersedia. */
    fun all(ctx: Context, mode: String, quality: String): Map<String, String>? {
        val m = FILES.associateWith { file(ctx, mode, quality, it) ?: return null }
        return m
    }

    fun file(ctx: Context, presetName: String, name: String): String? {
        val (m, q) = presetName.split(" ")
        return file(ctx, m, q, name)
    }
}
