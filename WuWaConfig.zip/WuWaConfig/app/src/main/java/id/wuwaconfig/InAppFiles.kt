package id.wuwaconfig

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

/** Operasi file untuk file manager di dalam aplikasi. */
object FileOps {
    class Entry(val file: File, val isDir: Boolean, val sub: String, val modified: Long)

    fun root(): File = Environment.getExternalStorageDirectory()

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            .all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun size(b: Long): String = when {
        b < 1024L -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1024.0 / 1024.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1024.0 / 1024.0 / 1024.0)
    }

    /** Isi folder: folder dulu, lalu file, urut abjad. Null kalau folder tidak bisa dibuka. */
    fun list(dir: File): List<Entry>? {
        val kids = dir.listFiles() ?: return null
        return kids.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })).map { f ->
            if (f.isDirectory) {
                val n = f.list()?.size
                Entry(f, true, when { n == null -> "Terkunci"; n == 0 -> "Kosong"; else -> "$n item" }, f.lastModified())
            } else Entry(f, false, size(f.length()), f.lastModified())
        }
    }

    /** Ekstrak [zip] ke folder baru (nama zip) di dalam [parent]. Mengembalikan (folder hasil, pesan error). */
    fun extractZip(zip: File, parent: File): Pair<File?, String?> {
        val base0 = zip.nameWithoutExtension.ifBlank { "zip" }
        var dest = File(parent, base0)
        var n = 2
        while (dest.exists()) { dest = File(parent, "$base0 ($n)"); n++ }
        return try {
            if (!dest.mkdirs()) return Pair(null, "Tidak bisa membuat folder ${dest.name}")
            val base = dest.canonicalPath + File.separator
            ZipFile(zip).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val out = File(dest, e.name)
                    if (!out.canonicalPath.startsWith(base)) throw SecurityException("path tidak aman")
                    if (e.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        z.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    }
                }
            }
            Pair(dest, null)
        } catch (e: SecurityException) {
            dest.deleteRecursively(); Pair(null, "Zip berisi path yang tidak aman, dibatalkan.")
        } catch (e: Exception) {
            dest.deleteRecursively(); Pair(null, "Gagal mengekstrak: ${e.message ?: "zip rusak"}")
        }
    }
}

private val FM_BG = Color(0xFF0B0B10)
private val FM_PURPLE = Color(0xFF8E86F0)
private val FM_FOLDER = Color(0xFFF0A63C)
private val FM_TEXT = Color(0xFFEDEFF1)
private val FM_DIM = Color(0xFF8A9096)

/**
 * File manager di dalam aplikasi: jelajah folder HP, ketuk .zip untuk diimpor sebagai config atau diekstrak.
 * [onPickZip] dipanggil dengan file zip yang dipilih untuk diimpor; manager ditutup sesudahnya.
 */
@Composable fun InAppFileManager(onDismiss: () -> Unit, onPickZip: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(FileOps.hasAccess(ctx)) }
    val askAll = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { granted = FileOps.hasAccess(ctx) }
    val askLegacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = FileOps.hasAccess(ctx) }

    val root = remember { FileOps.root() }
    var dir by remember { mutableStateOf(File(root, "Download").takeIf { it.isDirectory } ?: root) }
    var entries by remember { mutableStateOf<List<FileOps.Entry>?>(emptyList()) }   // null = folder terkunci
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var action by remember { mutableStateOf<File?>(null) }
    val atRoot = dir.absolutePath == root.absolutePath

    LaunchedEffect(dir, reload, granted) {
        if (!granted) return@LaunchedEffect
        loading = true
        entries = withContext(Dispatchers.IO) { FileOps.list(dir) }
        loading = false
    }

    fun up(): Boolean {
        val p = dir.parentFile
        if (atRoot || p == null) return false
        dir = p
        return true
    }

    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            val uri = Uri.parse("package:${ctx.packageName}")
            try { askAll.launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)) }
            catch (_: Exception) {
                try { askAll.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                catch (_: Exception) { toast(ctx, "Tidak bisa membuka pengaturan izin.") }
            }
        } else askLegacy.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    Dialog(
        onDismissRequest = { if (!up()) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = FM_BG) {
            Column(Modifier.fillMaxSize()) {
                // Bar atas
                Row(Modifier.fillMaxWidth().background(Color(0xFF1C2030)).padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!up()) onDismiss() }) {
                        Icon(Icons.Outlined.ArrowBack, null, tint = FM_TEXT)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(if (atRoot) "Penyimpanan internal" else dir.name, color = FM_TEXT, fontWeight = FontWeight.SemiBold,
                            fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(dir.absolutePath, color = FM_DIM, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { reload++ }) { Icon(Icons.Outlined.Refresh, null, tint = FM_TEXT) }
                    IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, null, tint = FM_TEXT) }
                }

                when {
                    !granted -> Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Outlined.FolderOpen, null, tint = FM_PURPLE, modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(16.dp))
                        Text("Butuh izin akses semua file", color = FM_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(8.dp))
                        Text("Supaya aplikasi bisa menjelajah folder HP, mengambil zip config, dan mengekstraknya.",
                            color = FM_DIM, fontSize = 14.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(20.dp))
                        Button(onClick = { requestAccess() }, colors = ButtonDefaults.buttonColors(containerColor = FM_PURPLE, contentColor = Color.White)) {
                            Text("Beri izin", fontWeight = FontWeight.SemiBold)
                        }
                    }
                    else -> LazyColumn(Modifier.fillMaxSize().navigationBarsPadding()) {
                        if (!atRoot) item {
                            FmRow(Icons.Outlined.ArrowUpward, FM_FOLDER, "..", "Naik satu folder", "") { up() }
                        }
                        val list = entries
                        if (loading) item {
                            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = FM_PURPLE)
                            }
                        } else if (list == null) item {
                            Text("Folder ini tidak bisa dibuka (dikunci oleh sistem).", color = FM_DIM, fontSize = 14.sp,
                                modifier = Modifier.padding(24.dp))
                        } else if (list.isEmpty()) item {
                            Text("Folder kosong.", color = FM_DIM, fontSize = 14.sp, modifier = Modifier.padding(24.dp))
                        } else items(list, key = { it.file.absolutePath }) { e ->
                            val isZip = !e.isDir && e.file.name.endsWith(".zip", ignoreCase = true)
                            val date = remember(e.modified) { SimpleDateFormat("dd/MM/yy", Locale.US).format(Date(e.modified)) }
                            FmRow(
                                icon = if (e.isDir) Icons.Outlined.Folder else if (isZip) Icons.Outlined.FolderZip else Icons.Outlined.InsertDriveFile,
                                tint = if (e.isDir) FM_FOLDER else if (isZip) Color(0xFFE0B040) else FM_DIM,
                                name = e.file.name, sub = e.sub, date = date, dim = !e.isDir && !isZip
                            ) {
                                when {
                                    e.isDir -> dir = e.file
                                    isZip -> action = e.file
                                    else -> toast(ctx, "Hanya file .zip yang bisa diimpor atau diekstrak.")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    action?.let { f ->
        AlertDialog(
            onDismissRequest = { action = null },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text(f.name, color = FM_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AccessOption("Impor sebagai config", "Pakai zip ini sebagai config WuWa.", Icons.Outlined.FileDownload,
                        FM_PURPLE, Color(0xFF13111F), false, onClick = { action = null; onPickZip(f); onDismiss() })
                    AccessOption("Ekstrak di sini", "Keluarkan isi zip ke folder baru di ${f.parentFile?.name ?: "sini"}.", Icons.Outlined.Unarchive,
                        Color(0xFFE0B040), Color(0xFF17140C), false, onClick = {
                            action = null; busy = true
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { FileOps.extractZip(f, f.parentFile ?: dir) }
                                busy = false
                                toast(ctx, r.second ?: "Diekstrak ke folder ${r.first?.name}")
                                reload++
                            }
                        })
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { action = null }) { Text("Batal", color = FM_PURPLE, fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
        )
    }

    if (busy) AlertDialog(
        onDismissRequest = {},
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Mengekstrak…", color = FM_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 20.sp) },
        text = { LinearProgressIndicator(color = FM_PURPLE, modifier = Modifier.fillMaxWidth()) },
        confirmButton = {}
    )
}

@Composable private fun FmRow(icon: ImageVector, tint: Color, name: String, sub: String, date: String, dim: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = if (dim) FM_DIM else FM_TEXT, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = FM_DIM, fontSize = 13.sp, maxLines = 1)
        }
        if (date.isNotEmpty()) Text(date, color = FM_DIM, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
    }
}
