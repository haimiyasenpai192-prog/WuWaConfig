package id.wuwaconfig

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

/** Operasi file untuk file manager di dalam aplikasi. */
object FileOps {
    class Entry(val file: File, val isDir: Boolean, val sub: String, val modified: Long)

    fun root(): File = Environment.getExternalStorageDirectory()

    /** Android/data dan Android/obb tidak bisa dibuka aplikasi biasa (Android 11+), harus lewat Shizuku/Root. */
    fun isRestricted(dir: File): Boolean {
        val a = root().absolutePath + "/Android"
        val p = dir.absolutePath
        return p == "$a/data" || p.startsWith("$a/data/") || p == "$a/obb" || p.startsWith("$a/obb/")
    }

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            .all { ctx.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    fun size(b: Long): String = when {
        b < 1024L -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1024.0 / 1024.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1024.0 / 1024.0 / 1024.0)
    }

    /** Isi folder: folder dulu, lalu file, urut abjad. Null kalau folder tidak bisa dibuka. */
    fun list(dir: File): List<Entry>? {
        val kids = dir.listFiles() ?: return null
        return kids.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })).map { f ->
            if (f.isDirectory) {
                val n = f.list()?.size
                Entry(f, true, when { n == null -> "Terkunci"; n == 0 -> "Kosong"; else -> "$n item" }, f.lastModified())
            } else Entry(f, false, size(f.length()), f.lastModified())
        }
    }

    /** Ekstrak [zip] ke folder baru (nama zip) di dalam [parent]. Mengembalikan (folder hasil, pesan error). */
    fun extractZip(zip: File, parent: File): Pair<File?, String?> {
        val base0 = zip.nameWithoutExtension.ifBlank { "zip" }
        var dest = File(parent, base0)
        var n = 2
        while (dest.exists()) { dest = File(parent, "$base0 ($n)"); n++ }
        return try {
            if (!dest.mkdirs()) return Pair(null, "Tidak bisa membuat folder ${dest.name}")
            val base = dest.canonicalPath + File.separator
            ZipFile(zip).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val out = File(dest, e.name)
                    if (!out.canonicalPath.startsWith(base)) throw SecurityException("path tidak aman")
                    if (e.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        z.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    }
                }
            }
            Pair(dest, null)
        } catch (e: SecurityException) {
            dest.deleteRecursively(); Pair(null, "Zip berisi path yang tidak aman, dibatalkan.")
        } catch (e: Exception) {
            dest.deleteRecursively(); Pair(null, "Gagal mengekstrak: ${e.message ?: "zip rusak"}")
        }
    }
}

private val FM_BG = Color(0xFF0B0B10)
private val FM_CARD = Color(0xFF14151C)
private val FM_PURPLE = Color(0xFF8E86F0)
private val FM_FOLDER = Color(0xFFF0A63C)
private val FM_ZIP = Color(0xFF4AA37A)
private val FM_TEXT = Color(0xFFEDEFF1)
private val FM_DIM = Color(0xFF8A9096)

/**
 * File manager di dalam aplikasi: jelajah folder HP, ketuk .zip untuk diimpor sebagai config atau diekstrak.
 * Tampilan dibuat simpel: hanya folder dan zip, file tersembunyi disembunyikan (bisa diubah lewat menu ⋮).
 * [onPickZip] dipanggil dengan file zip yang dipilih untuk diimpor; manager ditutup sesudahnya.
 */
@Composable fun InAppFileManager(onDismiss: () -> Unit, onPickZip: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(FileOps.hasAccess(ctx)) }
    val askAll = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { granted = FileOps.hasAccess(ctx) }
    val askLegacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = FileOps.hasAccess(ctx) }

    val root = remember { FileOps.root() }
    var dir by remember { mutableStateOf(File(root, "Download").takeIf { it.isDirectory } ?: root) }
    var entries by remember { mutableStateOf<List<FileOps.Entry>?>(emptyList()) }   // null = folder terkunci
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var action by remember { mutableStateOf<File?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var showHidden by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    val atRoot = dir.absolutePath == root.absolutePath
    val dateFmt = remember { SimpleDateFormat("d MMM yyyy", Locale("id", "ID")) }

    val shStatus = ShizukuShell.status.value   // 2 = Shizuku/Root siap
    val needShizuku = FileOps.isRestricted(dir) && shStatus != 2
    LaunchedEffect(dir) { ShizukuShell.refresh() }

    LaunchedEffect(dir, reload, granted, shStatus) {
        if (!granted) return@LaunchedEffect
        loading = true
        val restricted = FileOps.isRestricted(dir)
        entries = withContext(Dispatchers.IO) {
            val ready = ShizukuShell.status.value == 2
            when {
                restricted -> if (ready) ShizukuShell.listDir(dir.absolutePath) else null
                else -> FileOps.list(dir) ?: if (ready) ShizukuShell.listDir(dir.absolutePath) else null
            }
        }
        loading = false
    }

    fun up(): Boolean {
        val p = dir.parentFile
        if (atRoot || p == null) return false
        dir = p
        return true
    }

    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            val uri = Uri.parse("package:${ctx.packageName}")
            try { askAll.launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)) }
            catch (_: Exception) {
                try { askAll.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                catch (_: Exception) { toast(ctx, "Tidak bisa membuka pengaturan izin.") }
            }
        } else askLegacy.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    // Jalur folder dari penyimpanan internal sampai folder sekarang, untuk breadcrumb.
    val crumbs = remember(dir) {
        val out = ArrayList<File>()
        var f: File? = dir
        while (f != null) {
            out.add(f)
            if (f.absolutePath == root.absolutePath) break
            f = f.parentFile
        }
        out.reversed()
    }
    val crumbScroll = rememberScrollState()
    LaunchedEffect(dir) { delay(60); crumbScroll.animateScrollTo(crumbScroll.maxValue) }

    val raw = entries
    val visible = remember(raw, showHidden, showAll) {
        raw?.filter { e ->
            (showHidden || !e.file.name.startsWith(".")) &&
                (showAll || e.isDir || e.file.name.endsWith(".zip", ignoreCase = true))
        }
    }

    Dialog(
        onDismissRequest = { if (!up()) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(Modifier.fillMaxSize(), color = FM_BG) {
            Column(Modifier.fillMaxSize()) {
                // Bar atas: kembali, judul, menu, tutup
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!up()) onDismiss() }) {
                        Icon(Icons.Outlined.ArrowBack, null, tint = FM_TEXT)
                    }
                    Text(if (atRoot) "Penyimpanan internal" else dir.name, color = FM_TEXT, fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Outlined.MoreVert, null, tint = FM_TEXT) }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Buka Android/data") },
                                leadingIcon = { Icon(Icons.Outlined.Folder, null) },
                                onClick = { dir = File(root, "Android/data"); menuOpen = false })
                            DropdownMenuItem(
                                text = { Text("Tampilkan semua file") },
                                leadingIcon = { if (showAll) Icon(Icons.Outlined.Check, null) else Spacer(Modifier.size(24.dp)) },
                                onClick = { showAll = !showAll; menuOpen = false })
                            DropdownMenuItem(
                                text = { Text("Tampilkan file tersembunyi") },
                                leadingIcon = { if (showHidden) Icon(Icons.Outlined.Check, null) else Spacer(Modifier.size(24.dp)) },
                                onClick = { showHidden = !showHidden; menuOpen = false })
                            DropdownMenuItem(
                                text = { Text("Segarkan") },
                                leadingIcon = { Icon(Icons.Outlined.Refresh, null) },
                                onClick = { reload++; menuOpen = false })
                        }
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, null, tint = FM_TEXT) }
                }

                // Breadcrumb: ketuk bagian mana saja untuk lompat ke folder itu
                Row(Modifier.fillMaxWidth().horizontalScroll(crumbScroll).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    crumbs.forEachIndexed { i, f ->
                        val last = i == crumbs.lastIndex
                        if (i > 0) Icon(Icons.Outlined.ChevronRight, null, tint = FM_DIM, modifier = Modifier.size(18.dp))
                        Text(
                            if (i == 0) "Internal" else f.name,
                            color = if (last) FM_PURPLE else FM_DIM,
                            fontSize = 13.sp,
                            fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp))
                                .background(if (last) FM_PURPLE.copy(alpha = 0.14f) else FM_CARD)
                                .clickable(enabled = !last) { dir = f }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                when {
                    !granted -> FmMessage(Icons.Outlined.FolderOpen, "Butuh izin akses semua file",
                        "Supaya aplikasi bisa menjelajah folder HP, mengambil zip config, dan mengekstraknya.") {
                        Spacer(Modifier.height(20.dp))
                        Button(onClick = { requestAccess() }, colors = ButtonDefaults.buttonColors(containerColor = FM_PURPLE, contentColor = Color.White)) {
                            Text("Beri izin", fontWeight = FontWeight.SemiBold)
                        }
                    }
                    needShizuku -> FmMessage(Icons.Outlined.Lock, "Butuh Shizuku atau Root",
                        "Folder Android/data hanya bisa dibuka lewat Shizuku atau Root. Pastikan Shizuku aktif lalu beri izin.") {
                        if (shStatus == 1) {
                            Spacer(Modifier.height(20.dp))
                            Button(onClick = { ShizukuShell.requestPermission() }, colors = ButtonDefaults.buttonColors(containerColor = FM_PURPLE, contentColor = Color.White)) {
                                Text("Beri izin Shizuku", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    loading -> Box(Modifier.fillMaxSize().padding(40.dp), contentAlignment = Alignment.TopCenter) {
                        CircularProgressIndicator(color = FM_PURPLE)
                    }
                    visible == null -> FmMessage(Icons.Outlined.Lock, "Folder terkunci", "Folder ini tidak bisa dibuka (dikunci oleh sistem).") {}
                    visible.isEmpty() -> FmMessage(Icons.Outlined.FolderOpen,
                        if (raw.isNullOrEmpty()) "Folder kosong" else "Tidak ada folder atau zip",
                        if (raw.isNullOrEmpty()) "Belum ada isi di folder ini." else "Buka menu ⋮ untuk menampilkan semua file.") {}
                    else -> LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)) {
                        items(visible, key = { it.file.absolutePath }) { e ->
                            val isZip = !e.isDir && e.file.name.endsWith(".zip", ignoreCase = true)
                            val date = dateFmt.format(Date(e.modified))
                            FmRow(
                                icon = if (e.isDir) Icons.Outlined.Folder else if (isZip) Icons.Outlined.FolderZip else Icons.Outlined.InsertDriveFile,
                                tint = if (e.isDir) FM_FOLDER else if (isZip) FM_ZIP else FM_DIM,
                                name = e.file.name,
                                sub = "${e.sub} · $date",
                                highlight = isZip,
                                dim = !e.isDir && !isZip,
                                chevron = e.isDir
                            ) {
                                when {
                                    e.isDir -> dir = e.file
                                    isZip && FileOps.isRestricted(e.file) ->
                                        toast(ctx, "Impor dan ekstrak zip dari folder ini belum didukung. Salin dulu ke Download.")
                                    isZip -> action = e.file
                                    else -> toast(ctx, "Hanya file .zip yang bisa diimpor atau diekstrak.")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    action?.let { f ->
        AlertDialog(
            onDismissRequest = { action = null },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text(f.name, color = FM_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AccessOption("Impor sebagai config", "Pakai zip ini sebagai config WuWa.", Icons.Outlined.FileDownload,
                        FM_PURPLE, Color(0xFF13111F), false, onClick = { action = null; onPickZip(f); onDismiss() })
                    AccessOption("Ekstrak di sini", "Keluarkan isi zip ke folder baru di ${f.parentFile?.name ?: "sini"}.", Icons.Outlined.Unarchive,
                        Color(0xFFE0B040), Color(0xFF17140C), false, onClick = {
                            action = null; busy = true
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { FileOps.extractZip(f, f.parentFile ?: dir) }
                                busy = false
                                toast(ctx, r.second ?: "Diekstrak ke folder ${r.first?.name}")
                                reload++
                            }
                        })
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { action = null }) { Text("Batal", color = FM_PURPLE, fontWeight = FontWeight.Medium, fontSize = 16.sp) } }
        )
    }

    if (busy) AlertDialog(
        onDismissRequest = {},
        containerColor = Color.Black,
        shape = RoundedCornerShape(28.dp),
        title = { Text("Mengekstrak…", color = FM_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 20.sp) },
        text = { LinearProgressIndicator(color = FM_PURPLE, modifier = Modifier.fillMaxWidth()) },
        confirmButton = {}
    )
}

/** Satu baris file/folder: kartu bulat dengan ikon berwarna di kotak kecil. */
@Composable private fun FmRow(
    icon: ImageVector, tint: Color, name: String, sub: String,
    highlight: Boolean = false, dim: Boolean = false, chevron: Boolean = false, onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (highlight) tint.copy(alpha = 0.10f) else FM_CARD)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = if (dim) FM_DIM else FM_TEXT, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = FM_DIM, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (chevron) Icon(Icons.Outlined.ChevronRight, null, tint = FM_DIM, modifier = Modifier.size(22.dp))
    }
}

/** Pesan di tengah layar (izin, kosong, terkunci). */
@Composable private fun FmMessage(icon: ImageVector, title: String, text: String, extra: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = FM_PURPLE, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, color = FM_TEXT, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(text, color = FM_DIM, fontSize = 14.sp, textAlign = TextAlign.Center)
        extra()
    }
}
