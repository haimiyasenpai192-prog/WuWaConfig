package id.wuwaconfig

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer

/**
 * Notifikasi + suara saat config berhasil dipasang.
 * Suara diputar lewat MediaPlayer yang dipegang di sini (bukan di Composable), dan baru dilepas
 * setelah selesai diputar, jadi tidak terpotong saat layar berubah atau aplikasi pindah ke latar.
 * Kalau suara sebelumnya masih jalan, suara baru tidak dimulai agar yang sedang jalan tidak dipotong.
 */
object Notifier {
    private const val CHANNEL = "install_done"
    private const val NOTIF_ID = 1
    private var player: MediaPlayer? = null

    fun installed(ctx: Context, label: String) {
        val app = ctx.applicationContext
        playSound(app)
        showNotification(app, label)
    }

    @Synchronized
    private fun playSound(app: Context) {
        try {
            if (player?.isPlaying == true) return
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val mp = MediaPlayer.create(app, R.raw.notif_install, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE) ?: return
            mp.setOnCompletionListener { m -> release(m) }
            mp.setOnErrorListener { m, _, _ -> release(m); true }
            player = mp
            mp.start()
        } catch (_: Throwable) {
            player = null
        }
    }

    @Synchronized
    private fun release(m: MediaPlayer) {
        try { m.release() } catch (_: Throwable) {}
        if (player === m) player = null
    }

    private fun showNotification(app: Context, label: String) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            // Suara sudah diputar sendiri di atas, jadi channel dibuat tanpa suara agar tidak dobel.
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Config terpasang", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    setSound(null, null); enableVibration(false)
                })
            val open = PendingIntent.getActivity(
                app, 0,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Config terpasang")
                .setContentText("$label berhasil dipasang. Buka game untuk mencoba.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (_: Throwable) {}
    }
}
