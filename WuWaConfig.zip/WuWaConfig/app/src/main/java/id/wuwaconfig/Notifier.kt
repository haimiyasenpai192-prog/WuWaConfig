package id.wuwaconfig

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer

/**
 * Notifikasi + suara saat config berhasil dipasang.
 * Suara diputar lewat MediaPlayer yang dipegang di sini (bukan di Composable), dan baru dilepas
 * setelah selesai diputar, jadi tidak terpotong saat layar berubah atau aplikasi pindah ke latar.
 * Kalau suara sebelumnya masih jalan, suara baru tidak dimulai agar yang sedang jalan tidak dipotong.
 */
object Notifier {
    private const val CHANNEL = "install_done"
    private const val CHANNEL_ACCESS = "access_selected"
    private const val NOTIF_ID = 1
    private const val CHANNEL_FAILED = "access_failed"
    private const val NOTIF_ID_ACCESS = 2
    private var player: MediaPlayer? = null

    fun installed(ctx: Context, label: String) {
        val app = ctx.applicationContext
        playSound(app, R.raw.notif_install)
        showNotification(app, label)
    }

    /** Dipanggil saat pengguna memilih Shizuku / Root di dialog "Izinkan Akses". Suara diputar penuh, tidak dipotong. */
    fun accessSelected(ctx: Context, method: String) {
        val app = ctx.applicationContext
        playSound(app, R.raw.notif_access)
        showAccessNotification(app, method)
    }

    /** Gagal / ditolak: notif memakai suara notifikasi bawaan HP (lewat channel, bukan suara custom). */
    fun accessFailed(ctx: Context, method: String, reason: String) {
        val app = ctx.applicationContext
        AppLog.w("Akses", "$method gagal: $reason")
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_FAILED, "Akses gagal", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(
                app, 2,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(app, CHANNEL_FAILED)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Akses $method gagal")
                .setContentText(reason)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_ID_ACCESS, n)
        } catch (_: Throwable) {}
    }

    @Synchronized
    private fun playSound(app: Context, res: Int) {
        try {
            if (player?.isPlaying == true) return
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val mp = MediaPlayer.create(app, res, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE) ?: return
            mp.setOnCompletionListener { m -> release(m) }
            mp.setOnErrorListener { m, _, _ -> release(m); true }
            player = mp
            mp.start()
        } catch (_: Throwable) {
            player = null
        }
    }

    @Synchronized
    private fun release(m: MediaPlayer) {
        try { m.release() } catch (_: Throwable) {}
        if (player === m) player = null
    }

    private fun showNotification(app: Context, label: String) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            // Suara sudah diputar sendiri di atas, jadi channel dibuat tanpa suara agar tidak dobel.
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Config terpasang", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    setSound(null, null); enableVibration(false)
                })
            val open = PendingIntent.getActivity(
                app, 0,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(app, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Config terpasang")
                .setContentText("$label berhasil dipasang. Buka game untuk mencoba.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_ID, n)
        } catch (_: Throwable) {}
    }

    private fun showAccessNotification(app: Context, method: String) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ACCESS, "Metode akses dipilih", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    setSound(null, null); enableVibration(false)
                })
            val open = PendingIntent.getActivity(
                app, 1,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(app, CHANNEL_ACCESS)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Akses $method dipilih")
                .setContentText("Metode akses diganti ke $method.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(NOTIF_ID_ACCESS, n)
        } catch (_: Throwable) {}
    }
}
