package id.wuwaconfig

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Daftar bagian (section). Ketuk salah satu -> [onPick] dipanggil dan editor teks langsung terbuka
 * dengan kursor di akhir bagian itu, jadi tinggal menambahkan cvar.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable fun SectionPicker(fileIdx: Int, text: String, ac: Color, onPick: (String) -> Unit) {
    val found = remember(text) { IniSmart.parse(text).map { it.name }.filter { it != "(tanpa section)" } }
    val base = if (fileIdx == 0) IniSmart.ENGINE_SECTIONS else emptyList()
    val names = (base + found.filter { n -> base.none { it.equals(n, ignoreCase = true) } }).distinct()
    val card = Color(0xFF0D0D12).copy(alpha = 0.6f)
    val ctx = LocalContext.current
    var menuFor by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxWidth()) {
        Text("Pilih bagian, lalu tambahkan cvar di teks", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
        if (names.isEmpty()) {
            Text("Belum ada bagian. Pakai Preset atau Buka file dulu.", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
        }
        names.forEach { n ->
            val count = IniSmart.getBody(text, n).split("\n").count { it.isNotBlank() }
            Box(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp)).background(card)
                    .combinedClickable(onClick = { onPick(n) }, onLongClick = { menuFor = n })
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("[$n]", color = Color.White, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        if (count > 0) Text("$count baris", color = Color.White, fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Outlined.ChevronRight, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                DropdownMenu(menuFor == n, { menuFor = null }) {
                    DropdownMenuItem(text = { Text("Salin") }, onClick = {
                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("bagian", "[$n]"))
                        toast(ctx, "Disalin: [$n]")
                        menuFor = null
                    })
                }
            }
        }
    }
}
