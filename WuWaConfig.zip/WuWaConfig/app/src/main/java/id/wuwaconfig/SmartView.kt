package id.wuwaconfig

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Pilih bagian (section) dari daftar. Ketuk salah satu -> langsung masuk ke editor bagian itu,
 * lalu tinggal menambahkan beberapa cvar (satu baris satu cvar).
 */
@Composable fun SectionPicker(fileIdx: Int, text: String, onChange: (String) -> Unit, ac: Color) {
    val ctx = LocalContext.current
    var sel by remember(fileIdx) { mutableStateOf<String?>(null) }
    var tfv by remember(fileIdx) { mutableStateOf(TextFieldValue("")) }
    val found = remember(text) { IniSmart.parse(text).map { it.name }.filter { it != "(tanpa section)" } }
    val base = if (fileIdx == 0) IniSmart.ENGINE_SECTIONS else emptyList()
    val names = (base + found.filter { n -> base.none { it.equals(n, ignoreCase = true) } }).distinct()
    val current = sel
    val card = Color(0xFF0D0D12).copy(alpha = 0.6f)

    if (current == null) {
        Column(Modifier.fillMaxWidth()) {
            Text("Pilih bagian yang mau diedit", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
            if (names.isEmpty()) {
                Text("Belum ada bagian. Pakai Preset atau Buka file dulu.", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
            }
            names.forEach { n ->
                val count = IniSmart.getBody(text, n).split("\n").count { it.isNotBlank() }
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp)).background(card)
                    .clickable {
                        val b = IniSmart.getBody(text, n)
                        val full = "[$n]\n" + b + (if (b.isNotEmpty()) "\n" else "")
                        tfv = TextFieldValue(full, TextRange(full.length)); sel = n }.padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("[$n]", Modifier.weight(1f), color = Color.White, fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    if (count > 0) Text("$count baris", color = Color.White, fontSize = 12.sp)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Outlined.ChevronRight, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    } else {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { sel = null }.padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.ChevronLeft, null, tint = Color.White, modifier = Modifier.size(22.dp))
                Text("Kembali", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            Text("Tambahkan cvar di bawah header, satu baris satu cvar.", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.padding(start = 4.dp, top = 2.dp, bottom = 8.dp))
            Box(Modifier.fillMaxWidth().heightIn(min = 240.dp).clip(RoundedCornerShape(16.dp)).background(card).padding(12.dp)) {
                BasicTextField(tfv, { tfv = it }, Modifier.fillMaxWidth(),
                    textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 21.sp),
                    cursorBrush = SolidColor(Color.White))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Batal", ac, Modifier.weight(1f).fillMaxHeight()) { sel = null }
                Btn("Simpan bagian", ac, Modifier.weight(2f).fillMaxHeight(), filled = true) {
                    val lines = tfv.text.split("\n").dropWhile { it.isBlank() }
                    val rest = if (lines.isNotEmpty() && lines[0].trim().equals("[$current]", ignoreCase = true)) lines.drop(1) else lines
                    onChange(IniSmart.setBody(text, current, rest.joinToString("\n")))
                    toast(ctx, "Bagian [$current] tersimpan")
                    sel = null
                }
            }
        }
    }
}
