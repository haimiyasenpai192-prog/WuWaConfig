package id.wuwaconfig

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import rikka.shizuku.Shizuku

/**
 * Akses file game lewat Shizuku (shell uid) atau Root (su). Keduanya bisa menulis ke Android/data.
 * Metode yang dipilih disimpan di prefs ("access_mode").
 */
object ShizukuShell {
    const val REQ = 4711
    const val MODE_SHIZUKU = 0
    const val MODE_ROOT = 1
    const val MODE_SAF = 2

    /** 0 = tidak berjalan / tidak tersedia, 1 = belum diizinkan, 2 = terhubung (untuk metode yang aktif) */
    val status = mutableStateOf(0)
    val mode = mutableStateOf(MODE_SHIZUKU)

    private var rootState = 1
    private var prefs: SharedPreferences? = null
    private var appCtx: Context? = null
    private var pendingRoot = false
    private var awaitingShizuku = false
    private val main = Handler(Looper.getMainLooper())

    /** Nama file terakhir yang gagal ditulis (dipakai untuk diagnosa). */
    @Volatile var lastFailedFile: String? = null

    private val PACKAGES = listOf(
        "com.kurogame.wutheringwaves.global", "com.kurogame.wutheringwaves.bilibili",
        "com.kurogame.wutheringwaves.kuro", "com.kurogame.wutheringwaves.tw",
        "com.kurogame.wutheringwaves.jp", "com.kurogame.wutheringwaves.kr",
        "com.kurogame.wutheringwaves"
    )

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        mode.value = prefs?.getInt("access_mode", MODE_SHIZUKU) ?: MODE_SHIZUKU
        if (mode.value == MODE_ROOT) checkRootAsync()
    }

    fun isRoot() = mode.value == MODE_ROOT
    fun isSaf() = mode.value == MODE_SAF
    fun modeName() = when (mode.value) { MODE_ROOT -> "Root"; MODE_SAF -> "Folder (SAF)"; else -> "Shizuku" }

    fun setMode(m: Int) {
        mode.value = m
        prefs?.edit()?.putInt("access_mode", m)?.apply()
        if (m == MODE_ROOT) { rootState = 1; checkRootAsync() }
        refresh()
    }

    /** Minta su; Magisk/KernelSU/APatch akan menampilkan dialog izin kalau belum pernah diizinkan. */
    fun checkRootAsync() {
        Thread {
            val s = probeRoot()
            main.post {
                rootState = s; refresh()
                if (pendingRoot) {
                    pendingRoot = false
                    val c = appCtx
                    if (c != null) when (s) {
                        2 -> Notifier.accessSelected(c, "Root")
                        0 -> Notifier.accessFailed(c, "Root", "Root tidak tersedia di perangkat ini.")
                        else -> Notifier.accessFailed(c, "Root", "Izin root ditolak.")
                    }
                }
            }
        }.start()
    }

    /**
     * Dipanggil saat pengguna memilih metode di dialog "Izinkan Akses".
     * Berhasil -> suara + notif khusus. Gagal / ditolak -> notif dengan suara bawaan HP.
     */
    fun select(m: Int) {
        val c = appCtx ?: return
        awaitingShizuku = false
        if (m == MODE_ROOT) {
            pendingRoot = true
            setMode(MODE_ROOT)   // memicu pengecekan su; hasilnya dikabarkan di checkRootAsync
            return
        }
        if (m == MODE_SAF) {
            pendingRoot = false
            setMode(MODE_SAF)
            if (status.value == 2) Notifier.accessSelected(c, "Folder (SAF)")
            else Notifier.accessFailed(c, "Folder (SAF)", "Folder Android/data belum diizinkan.")
            return
        }
        pendingRoot = false
        setMode(MODE_SHIZUKU)
        when (status.value) {
            2 -> Notifier.accessSelected(c, "Shizuku")
            1 -> {
                val blocked = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }
                if (blocked) Notifier.accessFailed(c, "Shizuku", "Izin Shizuku ditolak. Aktifkan lewat aplikasi Shizuku.")
                else { awaitingShizuku = true; requestPermission() }
            }
            else -> Notifier.accessFailed(c, "Shizuku", "Shizuku belum berjalan. Nyalakan dulu Shizuku.")
        }
    }

    /** Hasil dialog izin Shizuku. */
    fun onPermissionResult(granted: Boolean) {
        refresh()
        if (!awaitingShizuku) return
        awaitingShizuku = false
        val c = appCtx ?: return
        if (granted) Notifier.accessSelected(c, "Shizuku")
        else Notifier.accessFailed(c, "Shizuku", "Izin Shizuku ditolak.")
    }

    private fun probeRoot(): Int = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() == 0 && out.contains("uid=0")) { AppLog.i("Akses", "Root OK: ${out.trim()}"); 2 }
        else { AppLog.w("Akses", "Root ditolak / bukan uid 0: ${out.trim()}"); 1 }
    } catch (e: java.io.IOException) { AppLog.w("Akses", "Root tidak tersedia: ${e.message}"); 0 } catch (e: Throwable) { AppLog.e("Akses", "Cek root error: ${e.message}"); 1 }

    fun refresh() {
        status.value = if (isSaf()) (appCtx?.let { if (SafAccess.granted(it)) 2 else 1 } ?: 0) else if (isRoot()) rootState else try {
            when {
                !Shizuku.pingBinder() -> 0
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
                else -> 1
            }
        } catch (e: Throwable) { 0 }
    }

    fun requestPermission() {
        if (isSaf()) return
        if (isRoot()) { checkRootAsync(); return }
        try { if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun installedPackage(ctx: Context): String? = PACKAGES.firstOrNull {
        try { ctx.packageManager.getPackageInfo(it, 0); true } catch (_: Exception) { false }
    }

    private const val SUB = "files/UE4Game/Client/Client/Saved/Config/Android"

    /**
     * Beberapa ROM (HyperOS / Android 16) menolak akses shell ke Android/data lewat /storage/emulated/0,
     * tapi masih mengizinkannya lewat mount lain. Root yang terakhir berhasil diingat di [root].
     */
    private val ROOTS = listOf(
        "/storage/emulated/0",
        "/sdcard",
        "/mnt/androidwritable/0/emulated/0",
        "/mnt/pass_through/0/emulated/0",
        "/mnt/user/0/emulated/0",
        "/mnt/user/0/primary",
        "/data/media/0"
    )
    @Volatile private var root = ROOTS[0]

    private fun dir(pkg: String, r: String = root) = "$r/Android/data/$pkg/$SUB"

    // Shizuku 13 menyembunyikan newProcess(); dipanggil lewat reflection (cara umum dipakai).
    private fun shizukuProc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    /** Paksa pakai su (forceSu) untuk percobaan cadangan saat Shizuku ditolak ROM. */
    @Volatile private var forceSu = false

    private fun sh(cmd: String): Process =
        if (isRoot() || forceSu) Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)) else shizukuProc(cmd)

    private fun usingSu() = isRoot() || forceSu

    private fun denied(err: String) =
        err.contains("Permission denied", true) || err.contains("Operation not permitted", true)

    /** Satu percobaan tulis ke root tertentu. Return Pair(exit code, pesan error). */
    private fun tryWrite(r: String, pkg: String, name: String, text: String): Pair<Int, String> {
        val d = dir(pkg, r)
        // Mode root: samakan pemilik/izin file dengan folder induknya agar game tetap bisa membacanya (best effort).
        val fix = if (usingSu())
            " && { chown \$(stat -c %u:%g '$d') '$d/$name' 2>/dev/null; chmod 660 '$d/$name' 2>/dev/null; restorecon '$d/$name' 2>/dev/null; true; }"
        else ""
        // Root alternatif hanya dipakai kalau memang ada di namespace proses ini (jangan mkdir di /mnt/...).
        val guard = if (r != ROOTS[0]) "[ -d '$r/Android/data' ] || { echo 'Permission denied: $r tidak ada' >&2; exit 1; }; " else ""
        val p = sh("${guard}mkdir -p '$d' && cat > '$d/$name'$fix")
        p.outputStream.use { it.write(text.toByteArray()) }
        val code = p.waitFor()
        val err = if (code == 0) "" else p.errorStream.bufferedReader().readText().trim()
        return code to err
    }

    /** @return null jika sukses, atau pesan error */
    fun write(pkg: String, name: String, text: String): String? {
        val c = appCtx
        if (isSaf() && c != null) return SafAccess.write(c, pkg, name, text)
        val r = writeShell(pkg, name, text)
        if (r != null && c != null && denied(r) && SafAccess.granted(c)) {
            AppLog.w("Tulis", "Shell ditolak, mencoba lewat SAF")
            return SafAccess.write(c, pkg, name, text)
        }
        return r
    }

    private fun writeShell(pkg: String, name: String, text: String): String? = try {
        var (code, err) = tryWrite(root, pkg, name, text)
        if (code != 0 && denied(err)) {
            // Ditolak di path utama -> coba mount alternatif, ingat yang berhasil.
            for (alt in ROOTS) {
                if (alt == root) continue
                val (c, e) = tryWrite(alt, pkg, name, text)
                if (c == 0) {
                    AppLog.i("Tulis", "Path utama ditolak, berhasil lewat $alt")
                    root = alt; code = 0; err = ""; break
                } else AppLog.w("Tulis", "Fallback $alt gagal: ${e.lineSequence().firstOrNull() ?: "exit=$c"}")
            }
        }
        if (code != 0 && denied(err) && !isRoot()) {
            // Android 16 / HyperOS: shell (Shizuku) diblokir dari Android/data. Kalau HP di-root, coba su.
            forceSu = true
            try {
                val (c, e) = tryWrite(ROOTS[0], pkg, name, text)
                if (c == 0) { AppLog.i("Tulis", "Shizuku ditolak, berhasil lewat su"); code = 0; err = "" }
                else { AppLog.w("Tulis", "Fallback su gagal: ${e.lineSequence().firstOrNull() ?: "exit=$c"}"); forceSu = false }
            } catch (t: Throwable) { forceSu = false; AppLog.w("Tulis", "su tidak tersedia: ${t.message}") }
        }
        if (code == 0) {
            AppLog.i("Tulis", "OK $name (${text.length} karakter) via $root")
            null
        } else {
            lastFailedFile = name
            AppLog.e("Tulis", "GAGAL $name | exit=$code | $err")
            err.ifBlank { "Gagal menulis $name (exit $code)" }
        }
    } catch (e: Throwable) {
        lastFailedFile = name
        AppLog.e("Tulis", "EXCEPTION $name | ${e.javaClass.simpleName}: ${e.message}")
        e.message ?: "Error"
    }

    /** Isi file di folder config game, atau null kalau tidak ada / tidak bisa dibaca. */
    fun read(pkg: String, name: String): String? {
        val c = appCtx
        if (isSaf() && c != null) return SafAccess.read(c, pkg, name)
        return readShell(pkg, name) ?: if (c != null && SafAccess.granted(c)) SafAccess.read(c, pkg, name) else null
    }

    private fun readShell(pkg: String, name: String): String? = try {
        var res: String? = null
        for (r in listOf(root) + ROOTS.filter { it != root }) {
            val p = sh("cat '${dir(pkg, r)}/$name'")
            val out = p.inputStream.bufferedReader().readText()
            if (p.waitFor() == 0) { res = out; root = r; break }
            if (r == root && !denied(p.errorStream.bufferedReader().readText())) break // bukan masalah izin (mis. file belum ada)
        }
        res
    } catch (e: Throwable) { null }

    /** Tulis lalu baca ulang untuk memastikan isinya benar-benar sama. null = sukses. */
    fun writeVerified(pkg: String, name: String, text: String): String? {
        write(pkg, name, text)?.let { return it }
        val back = read(pkg, name) ?: run {
            AppLog.e("Verifikasi", "$name tidak terbaca setelah ditulis")
            return "$name tidak terbaca setelah ditulis"
        }
        fun norm(s: String) = s.replace("\r\n", "\n").trim()
        return if (norm(back) == norm(text)) null else {
            AppLog.e("Verifikasi", "$name isinya beda setelah ditulis (asli ${text.length} krk, terbaca ${back.length} krk)")
            "$name tidak sesuai setelah ditulis"
        }
    }

    /** Nama file config yang sekarang ada di folder game (urutan ALL_FILES). */
    fun existing(pkg: String): List<String>? {
        val c = appCtx
        fun saf() = c?.let { x -> SafAccess.names(x, pkg)?.let { n -> Presets.ALL_FILES.filter { f -> n.any { it.equals(f, true) } } } }
        if (isSaf()) return saf()
        val r = existingShell(pkg)
        return if (r.isNullOrEmpty() && c != null && SafAccess.granted(c)) saf() ?: r else r
    }

    private fun existingShell(pkg: String): List<String>? = try {
        var out = emptySet<String>()
        for (r in listOf(root) + ROOTS.filter { it != root }) {
            val p = sh("ls '${dir(pkg, r)}' 2>/dev/null")
            out = p.inputStream.bufferedReader().readText().lines().map { it.trim() }.filter { it.isNotEmpty() }.toSet()
            if (p.waitFor() == 0 && out.isNotEmpty()) { root = r; break }
        }
        Presets.ALL_FILES.filter { f -> out.any { it.equals(f, ignoreCase = true) } }
    } catch (e: Throwable) { null }

    fun delete(pkg: String, names: List<String>): String? {
        val c = appCtx
        if (isSaf() && c != null) return SafAccess.delete(c, pkg, names)
        val r = deleteShell(pkg, names)
        return if (r != null && c != null && denied(r) && SafAccess.granted(c)) SafAccess.delete(c, pkg, names) else r
    }

    private fun deleteShell(pkg: String, names: List<String>): String? = try {
        val d = dir(pkg)
        val p = sh(names.joinToString(" ; ") { "rm -f '$d/$it'" })  // [d] memakai root yang terakhir berhasil
        val code = p.waitFor()
        if (code == 0) {
            AppLog.i("Hapus", "OK ${names.joinToString()}")
            null
        } else {
            val err = p.errorStream.bufferedReader().readText().trim()
            AppLog.e("Hapus", "GAGAL | exit=$code | $err")
            err.ifBlank { "Gagal menghapus (exit $code)" }
        }
    } catch (e: Throwable) {
        AppLog.e("Hapus", "EXCEPTION ${e.javaClass.simpleName}: ${e.message}")
        e.message ?: "Error"
    }

    /** Jalankan satu perintah diagnosa, kembalikan keluaran (stdout+stderr) yang sudah dirapikan. */
    private fun probe(cmd: String): String = try {
        val p = sh("$cmd 2>&1")
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        out.ifBlank { "(kosong)" }
    } catch (e: Throwable) { "(error: ${e.javaClass.simpleName}: ${e.message})" }

    /**
     * Dipanggil saat pemasangan gagal: kumpulkan fakta yang biasanya jadi penyebab dan tulis ke log.
     * Cek: identitas proses, folder Android/data game, folder Config, izin file yang gagal, SELinux, sisa ruang.
     */
    fun diagnose(pkg: String, failedFile: String? = null) {
        try {
            val d = dir(pkg)
            val base = "/storage/emulated/0/Android/data/$pkg"
            val sb = StringBuilder("Diagnosa otomatis (akses: ${modeName()})\n")
            sb.append("id            : ").append(probe("id")).append('\n')
            sb.append("SELinux       : ").append(probe("getenforce")).append('\n')
            sb.append("Android/data  : ").append(probe("ls -ldn '/storage/emulated/0/Android/data'")).append('\n')
            sb.append("folder game   : ").append(probe("ls -ld '$base'")).append('\n')
            sb.append("folder config : ").append(probe("ls -ld '$d'")).append('\n')
            if (failedFile != null)
                sb.append("file gagal    : ").append(probe("ls -l '$d/$failedFile'")).append('\n')
            sb.append("isi config    : ").append(probe("ls -l '$d'").lines().take(12).joinToString(" | ")).append('\n')
            sb.append("coba mount    : ").append(ROOTS.joinToString(" | ") { r ->
                r.substringAfterLast('/') + "=" + probe("ls '${dir(pkg, r)}' >/dev/null && echo OK").lines().last().take(40)
            }).append('\n')
            sb.append("ruang kosong  : ").append(probe("df /storage/emulated/0 | tail -1")).append('\n')
            sb.append("Petunjuk      : ").append(hint(pkg, failedFile))
            AppLog.w("Diagnosa", sb.toString())
        } catch (e: Throwable) {
            AppLog.e("Diagnosa", "Diagnosa gagal dijalankan: ${e.message}")
        }
    }

    /** True kalau folder game dimiliki grup yang tidak dimiliki shell dan other tidak punya akses (drwxrws---). */
    private fun groupBlocked(lsLine: String): Boolean {
        val parts = lsLine.trim().split(Regex("\\s+"))
        if (parts.size < 4 || !parts[0].startsWith("d") || parts[0].length < 10) return false
        val otherNoAccess = parts[0].substring(7, 10) == "---"
        val grp = parts[3]
        val ids = probe("id")
        return otherNoAccess && !ids.contains("($grp)")
    }

    /** Tebakan penyebab paling umum berdasarkan hasil cek folder. */
    private fun hint(pkg: String, failedFile: String?): String {
        val d = dir(pkg)
        val base = "/storage/emulated/0/Android/data/$pkg"
        val gameDir = probe("ls -ld '$base'")
        val cfgDir = probe("ls -ld '$d'")
        val file = if (failedFile != null) probe("ls -l '$d/$failedFile'") else ""
        return when {
            gameDir.contains("No such file") ->
                "Folder data game belum ada. Buka game sampai masuk menu utama sekali, tutup, lalu coba pasang lagi."
            cfgDir.contains("No such file") ->
                "Folder Config belum dibuat game. Buka game sampai selesai download resource, lalu coba lagi."
            groupBlocked(gameDir) ->
                "ROM memblokir akses shell (Shizuku) ke folder data game: folder dimiliki game dengan grup yang bukan milik shell, " +
                "jadi bukan salah aplikasi atau Shizuku mati. Solusi: (0) pilih metode 'Folder (SAF)' di Izinkan Akses lalu izinkan folder Android/data/game, (1) HP root + pilih metode Root di aplikasi, " +
                "(2) coba Shizuku v13.5.4, (3) hapus data game lewat Info Aplikasi agar folder dibuat ulang dengan izin normal " +
                "(resource game akan diunduh ulang)."
            gameDir.contains("Permission denied") || cfgDir.contains("Permission denied") ->
                "Akses ditolak. Pastikan Shizuku masih berjalan & aplikasi sudah diizinkan (restart Shizuku lewat Wireless Debugging), atau pakai Root."
            file.contains("Permission denied") || file.contains("Operation not permitted") ->
                "File sudah ada tapi dikunci/dimiliki game. Coba 'Hapus config' di Settings, lalu pasang ulang."
            probe("df /storage/emulated/0 | tail -1").let { it.contains(" 100%") } ->
                "Penyimpanan penuh. Kosongkan ruang lalu coba lagi."
            else ->
                "Tidak ada penyebab pasti dari cek otomatis. Kemungkinan: Shizuku tidak aktif (mati setelah HP restart / Wi-Fi putus), atau ROM membatasi akses Android/data. Nyalakan ulang Shizuku lalu coba lagi."
        }
    }
}
