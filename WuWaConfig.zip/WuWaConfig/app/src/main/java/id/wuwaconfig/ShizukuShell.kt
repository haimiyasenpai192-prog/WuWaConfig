package id.wuwaconfig

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import rikka.shizuku.Shizuku

/**
 * Akses file game lewat Shizuku (shell uid) atau Root (su). Keduanya bisa menulis ke Android/data.
 * Metode yang dipilih disimpan di prefs ("access_mode").
 */
object ShizukuShell {
    const val REQ = 4711
    const val MODE_SHIZUKU = 0
    const val MODE_ROOT = 1

    /** 0 = tidak berjalan / tidak tersedia, 1 = belum diizinkan, 2 = terhubung (untuk metode yang aktif) */
    val status = mutableStateOf(0)
    val mode = mutableStateOf(MODE_SHIZUKU)

    private var rootState = 1
    private var prefs: SharedPreferences? = null
    private val main = Handler(Looper.getMainLooper())

    private val PACKAGES = listOf(
        "com.kurogame.wutheringwaves.global", "com.kurogame.wutheringwaves.bilibili",
        "com.kurogame.wutheringwaves.kuro", "com.kurogame.wutheringwaves.tw",
        "com.kurogame.wutheringwaves.jp", "com.kurogame.wutheringwaves.kr",
        "com.kurogame.wutheringwaves"
    )

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        mode.value = prefs?.getInt("access_mode", MODE_SHIZUKU) ?: MODE_SHIZUKU
        if (mode.value == MODE_ROOT) checkRootAsync()
    }

    fun isRoot() = mode.value == MODE_ROOT

    fun setMode(m: Int) {
        mode.value = m
        prefs?.edit()?.putInt("access_mode", m)?.apply()
        if (m == MODE_ROOT) { rootState = 1; checkRootAsync() }
        refresh()
    }

    /** Minta su; Magisk/KernelSU/APatch akan menampilkan dialog izin kalau belum pernah diizinkan. */
    fun checkRootAsync() {
        Thread {
            val s = probeRoot()
            main.post { rootState = s; refresh() }
        }.start()
    }

    private fun probeRoot(): Int = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() == 0 && out.contains("uid=0")) 2 else 1
    } catch (e: java.io.IOException) { 0 } catch (e: Throwable) { 1 }

    fun refresh() {
        status.value = if (isRoot()) rootState else try {
            when {
                !Shizuku.pingBinder() -> 0
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
                else -> 1
            }
        } catch (e: Throwable) { 0 }
    }

    fun requestPermission() {
        if (isRoot()) { checkRootAsync(); return }
        try { if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun installedPackage(ctx: Context): String? = PACKAGES.firstOrNull {
        try { ctx.packageManager.getPackageInfo(it, 0); true } catch (_: Exception) { false }
    }

    private fun dir(pkg: String) =
        "/storage/emulated/0/Android/data/$pkg/files/UE4Game/Client/Client/Saved/Config/Android"

    // Shizuku 13 menyembunyikan newProcess(); dipanggil lewat reflection (cara umum dipakai).
    private fun shizukuProc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    private fun sh(cmd: String): Process =
        if (isRoot()) Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)) else shizukuProc(cmd)

    /** @return null jika sukses, atau pesan error */
    fun write(pkg: String, name: String, text: String): String? = try {
        val d = dir(pkg)
        // Mode root: samakan pemilik/izin file dengan folder induknya agar game tetap bisa membacanya (best effort).
        val fix = if (isRoot())
            " && { chown \$(stat -c %u:%g '$d') '$d/$name' 2>/dev/null; chmod 660 '$d/$name' 2>/dev/null; restorecon '$d/$name' 2>/dev/null; true; }"
        else ""
        val p = sh("mkdir -p '$d' && cat > '$d/$name'$fix")
        p.outputStream.use { it.write(text.toByteArray()) }
        if (p.waitFor() == 0) null else p.errorStream.bufferedReader().readText().ifBlank { "Gagal menulis $name" }
    } catch (e: Throwable) { e.message ?: "Error" }

    /** Isi file di folder config game, atau null kalau tidak ada / tidak bisa dibaca. */
    fun read(pkg: String, name: String): String? = try {
        val p = sh("cat '${dir(pkg)}/$name'")
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() == 0) out else null
    } catch (e: Throwable) { null }

    /** Tulis lalu baca ulang untuk memastikan isinya benar-benar sama. null = sukses. */
    fun writeVerified(pkg: String, name: String, text: String): String? {
        write(pkg, name, text)?.let { return it }
        val back = read(pkg, name) ?: return "$name tidak terbaca setelah ditulis"
        fun norm(s: String) = s.replace("\r\n", "\n").trim()
        return if (norm(back) == norm(text)) null else "$name tidak sesuai setelah ditulis"
    }

    /** Nama file config yang sekarang ada di folder game (urutan ALL_FILES). */
    fun existing(pkg: String): List<String>? = try {
        val p = sh("ls '${dir(pkg)}' 2>/dev/null")
        val out = p.inputStream.bufferedReader().readText().lines().map { it.trim() }.toSet()
        p.waitFor()
        Presets.ALL_FILES.filter { f -> out.any { it.equals(f, ignoreCase = true) } }
    } catch (e: Throwable) { null }

    fun delete(pkg: String, names: List<String>): String? = try {
        val d = dir(pkg)
        val p = sh(names.joinToString(" ; ") { "rm -f '$d/$it'" })
        if (p.waitFor() == 0) null else p.errorStream.bufferedReader().readText()
    } catch (e: Throwable) { e.message ?: "Error" }
}
