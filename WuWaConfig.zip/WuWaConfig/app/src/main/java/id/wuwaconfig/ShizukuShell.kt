package id.wuwaconfig

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateOf
import rikka.shizuku.Shizuku

/**
 * Akses file game lewat Shizuku (shell uid) atau Root (su). Keduanya bisa menulis ke Android/data.
 * Metode yang dipilih disimpan di prefs ("access_mode").
 */
object ShizukuShell {
    const val REQ = 4711
    const val MODE_SHIZUKU = 0
    const val MODE_ROOT = 1
    const val MODE_ADB = 2

    /** 0 = tidak berjalan / tidak tersedia, 1 = belum diizinkan, 2 = terhubung (untuk metode yang aktif) */
    val status = mutableStateOf(0)
    val mode = mutableStateOf(MODE_SHIZUKU)

    private var rootState = 1
    private var prefs: SharedPreferences? = null
    private var appCtx: Context? = null
    private var pendingRoot = false
    private var awaitingShizuku = false
    private val main = Handler(Looper.getMainLooper())

    /** Nama file terakhir yang gagal ditulis (dipakai untuk diagnosa). */
    @Volatile var lastFailedFile: String? = null

    private val PACKAGES = listOf(
        "com.kurogame.wutheringwaves.global", "com.kurogame.wutheringwaves.bilibili",
        "com.kurogame.wutheringwaves.kuro", "com.kurogame.wutheringwaves.tw",
        "com.kurogame.wutheringwaves.jp", "com.kurogame.wutheringwaves.kr",
        "com.kurogame.wutheringwaves"
    )

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        prefs = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        mode.value = prefs?.getInt("access_mode", MODE_SHIZUKU) ?: MODE_SHIZUKU
        if (mode.value == MODE_ROOT) checkRootAsync()
        if (mode.value == MODE_ADB) Thread { connectAdb(ctx.applicationContext) }.start()
    }

    fun isRoot() = mode.value == MODE_ROOT
    fun isAdb() = mode.value == MODE_ADB
    fun modeName() = when (mode.value) { MODE_ROOT -> "Root"; MODE_ADB -> "Wireless ADB"; else -> "Shizuku" }

    /** Pairing (port + kode) lalu langsung connect. Dipanggil dari thread background. null = sukses. */
    fun pairAdb(ctx: Context, port: Int, code: String): String? {
        AdbPair.pair(ctx, port, code)?.let { return it }
        setMode(MODE_ADB)
        return connectAdb(ctx)
    }

    /** Sambung ulang ke Wireless Debugging (tanpa pairing lagi). null = sukses. */
    fun connectAdb(ctx: Context): String? {
        val err = AdbPair.connect(ctx)
        main.post { refresh() }
        return err
    }

    /** Process palsu: kumpulkan stdin, jalankan lewat ADB saat waitFor(), lalu sajikan keluarannya. */
    private class AdbProcess(private val cmd: String) : Process() {
        private val sink = java.io.ByteArrayOutputStream()
        private var res: Pair<Int, String>? = null
        private fun run(): Pair<Int, String> = res ?: AdbPair.exec(cmd, sink.toByteArray().takeIf { it.isNotEmpty() }).also { res = it }
        override fun getOutputStream(): java.io.OutputStream = sink
        override fun getInputStream(): java.io.InputStream = object : java.io.InputStream() {
            private val d by lazy { run().second.toByteArray().inputStream() }
            override fun read() = d.read()
            override fun read(b: ByteArray, o: Int, l: Int) = d.read(b, o, l)
        }
        override fun getErrorStream(): java.io.InputStream = java.io.ByteArrayInputStream(
            if (run().first != 0) run().second.toByteArray() else ByteArray(0))
        override fun waitFor(): Int = run().first
        override fun exitValue(): Int = run().first
        override fun destroy() {}
    }

    fun setMode(m: Int) {
        rootKey = null
        mode.value = m
        prefs?.edit()?.putInt("access_mode", m)?.apply()
        if (m == MODE_ROOT) { rootState = 1; checkRootAsync() }
        refresh()
    }

    /** Minta su; Magisk/KernelSU/APatch akan menampilkan dialog izin kalau belum pernah diizinkan. */
    fun checkRootAsync() {
        Thread {
            val s = probeRoot()
            main.post {
                rootState = s; refresh()
                if (pendingRoot) {
                    pendingRoot = false
                    val c = appCtx
                    if (c != null) when (s) {
                        2 -> Notifier.accessSelected(c, "Root")
                        0 -> Notifier.accessFailed(c, "Root", "Root tidak tersedia di perangkat ini.")
                        else -> Notifier.accessFailed(c, "Root", "Izin root ditolak.")
                    }
                }
            }
        }.start()
    }

    /**
     * Dipanggil saat pengguna memilih metode di dialog "Izinkan Akses".
     * Berhasil -> suara + notif khusus. Gagal / ditolak -> notif dengan suara bawaan HP.
     */
    fun select(m: Int) {
        val c = appCtx ?: return
        awaitingShizuku = false
        if (m == MODE_ROOT) {
            pendingRoot = true
            setMode(MODE_ROOT)   // memicu pengecekan su; hasilnya dikabarkan di checkRootAsync
            return
        }
        pendingRoot = false
        if (m == MODE_ADB) { setMode(MODE_ADB); return }
        setMode(MODE_SHIZUKU)
        when (status.value) {
            2 -> Notifier.accessSelected(c, "Shizuku")
            1 -> {
                val blocked = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }
                if (blocked) Notifier.accessFailed(c, "Shizuku", "Izin Shizuku ditolak. Aktifkan lewat aplikasi Shizuku.")
                else { awaitingShizuku = true; requestPermission() }
            }
            else -> Notifier.accessFailed(c, "Shizuku", "Shizuku belum berjalan. Nyalakan dulu Shizuku.")
        }
    }

    /** Hasil dialog izin Shizuku. */
    fun onPermissionResult(granted: Boolean) {
        refresh()
        if (!awaitingShizuku) return
        awaitingShizuku = false
        val c = appCtx ?: return
        if (granted) Notifier.accessSelected(c, "Shizuku")
        else Notifier.accessFailed(c, "Shizuku", "Izin Shizuku ditolak.")
    }

    private fun probeRoot(): Int = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() == 0 && out.contains("uid=0")) { AppLog.i("Akses", "Root OK: ${out.trim()}"); 2 }
        else { AppLog.w("Akses", "Root ditolak / bukan uid 0: ${out.trim()}"); 1 }
    } catch (e: java.io.IOException) { AppLog.w("Akses", "Root tidak tersedia: ${e.message}"); 0 } catch (e: Throwable) { AppLog.e("Akses", "Cek root error: ${e.message}"); 1 }

    fun refresh() {
        status.value = if (isAdb()) (if (AdbPair.isConnected()) 2 else 1) else if (isRoot()) rootState else try {
            when {
                !Shizuku.pingBinder() -> 0
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
                else -> 1
            }
        } catch (e: Throwable) { 0 }
    }

    fun requestPermission() {
        if (isAdb()) { appCtx?.let { c -> Thread { connectAdb(c) }.start() }; return }
        if (isRoot()) { checkRootAsync(); return }
        try { if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun installedPackage(ctx: Context): String? = PACKAGES.firstOrNull {
        try { ctx.packageManager.getPackageInfo(it, 0); true } catch (_: Exception) { false }
    }

    private val ROOTS = listOf("/storage/emulated/0", "/mnt/pass_through/0/emulated/0", "/mnt/user/0/emulated/0", "/data/media/0")
    @Volatile private var rootKey: String? = null
    @Volatile private var rootVal: String? = null

    /**
     * Android 14+ / HyperOS kadang menolak shell masuk lewat /storage/emulated/0 (FUSE) tapi mengizinkan lewat
     * jalur lain ke penyimpanan yang sama. Coba tiap jalur dan pakai yang pertama bisa membuka folder data game.
     */
    private fun rootFor(pkg: String): String {
        val key = "$pkg|${mode.value}"
        if (rootKey == key) rootVal?.let { return it }
        val cmd = "for r in ${ROOTS.joinToString(" ")}; do if ls \"\$r/Android/data/$pkg\" >/dev/null 2>&1; then echo \"\$r\"; break; fi; done"
        val found = try {
            val p = sh(cmd)
            val out = p.inputStream.bufferedReader().readText().trim().lines().firstOrNull()?.trim()
            p.waitFor(); out?.takeIf { it.startsWith("/") }
        } catch (e: Throwable) { null }
        if (found != null) {
            rootKey = key; rootVal = found
            AppLog.i("Jalur", "Folder data game bisa dibuka lewat $found")
            return found
        }
        AppLog.w("Jalur", "Tidak ada jalur yang bisa membuka Android/data/$pkg; pakai ${ROOTS[0]}")
        return ROOTS[0]
    }

    private fun dir(pkg: String) =
        "${rootFor(pkg)}/Android/data/$pkg/files/UE4Game/Client/Client/Saved/Config/Android"

    /** Folder kedua: Engine.ini juga disalin ke sini dengan nama AndroidEngine.ini. */
    private const val ENGINE_SRC = "Engine.ini"
    private const val ENGINE_DST = "AndroidEngine.ini"
    private fun engineDir(pkg: String) =
        "${rootFor(pkg)}/Android/data/$pkg/files/UE4Game/Client/Engine/Platforms/Android/Config"

    // Shizuku 13 menyembunyikan newProcess(); dipanggil lewat reflection (cara umum dipakai).
    private fun shizukuProc(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    private fun sh(cmd: String): Process = when {
        isAdb() -> AdbProcess(cmd)
        isRoot() -> Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        else -> shizukuProc(cmd)
    }

    /** @return null jika sukses, atau pesan error */
    fun write(pkg: String, name: String, text: String, dirOverride: String? = null): String? = try {
        val d = dirOverride ?: dir(pkg)
        // Mode root: samakan pemilik/izin file dengan folder induknya agar game tetap bisa membacanya (best effort).
        val fix = if (isRoot())
            " && { chown \$(stat -c %u:%g '$d') '$d/$name' 2>/dev/null; chmod 660 '$d/$name' 2>/dev/null; restorecon '$d/$name' 2>/dev/null; true; }"
        else ""
        val p = sh("mkdir -p '$d' && cat > '$d/$name'$fix")
        p.outputStream.use { it.write(text.toByteArray()) }
        val code = p.waitFor()
        if (code == 0) {
            AppLog.i("Tulis", "OK $name (${text.length} karakter)")
            null
        } else {
            val err = p.errorStream.bufferedReader().readText().trim()
            lastFailedFile = name
            AppLog.e("Tulis", "GAGAL $name | exit=$code | $err")
            err.ifBlank { "Gagal menulis $name (exit $code)" }
        }
    } catch (e: Throwable) {
        lastFailedFile = name
        AppLog.e("Tulis", "EXCEPTION $name | ${e.javaClass.simpleName}: ${e.message}")
        e.message ?: "Error"
    }

    /** Isi file di folder config game, atau null kalau tidak ada / tidak bisa dibaca. */
    fun read(pkg: String, name: String): String? = try {
        val p = sh("cat '${dir(pkg)}/$name'")
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() == 0) out else null
    } catch (e: Throwable) { null }

    /** Tulis lalu baca ulang untuk memastikan isinya benar-benar sama. null = sukses. */
    fun writeVerified(pkg: String, name: String, text: String): String? {
        write(pkg, name, text)?.let { return it }
        val back = read(pkg, name) ?: run {
            AppLog.e("Verifikasi", "$name tidak terbaca setelah ditulis")
            return "$name tidak terbaca setelah ditulis"
        }
        fun norm(s: String) = s.replace("\r\n", "\n").trim()
        if (norm(back) != norm(text)) {
            AppLog.e("Verifikasi", "$name isinya beda setelah ditulis (asli ${text.length} krk, terbaca ${back.length} krk)")
            return "$name tidak sesuai setelah ditulis"
        }
        // Engine.ini juga ditulis sebagai AndroidEngine.ini di Engine/Platforms/Android/Config
        if (name.equals(ENGINE_SRC, ignoreCase = true)) {
            write(pkg, ENGINE_DST, text, engineDir(pkg))?.let { return "$ENGINE_SRC: $it" }
        }
        return null
    }

    /** Nama file config yang sekarang ada di folder game (urutan ALL_FILES). */
    fun existing(pkg: String): List<String>? = try {
        val p = sh("ls '${dir(pkg)}' 2>/dev/null")
        val out = p.inputStream.bufferedReader().readText().lines().map { it.trim() }.toSet()
        p.waitFor()
        Presets.ALL_FILES.filter { f -> out.any { it.equals(f, ignoreCase = true) } }
    } catch (e: Throwable) { null }

    /** Isi AndroidEngine.ini dari folder Engine/Platforms/Android/Config, atau null kalau tidak ada. */
    private fun readEngineDir(pkg: String, name: String): String? = try {
        val p = sh("cat '${engineDir(pkg)}/$name'")
        val out = p.inputStream.bufferedReader().readText()
        if (p.waitFor() == 0) out else null
    } catch (e: Throwable) { null }

    /**
     * Baca isi file config yang ada di folder game. Kunci: Engine.ini, DeviceProfiles.ini, GameUserSettings.ini,
     * AndroidEngine.ini. Nilai null = file tidak ada. Return null = folder game tidak bisa dibaca.
     */
    fun inspect(pkg: String): Map<String, String?>? {
        return try {
        val present = existing(pkg) ?: return null
        val m = linkedMapOf<String, String?>()
        for (f in listOf("Engine.ini", "DeviceProfiles.ini", "GameUserSettings.ini")) {
            m[f] = if (present.any { it.equals(f, true) }) read(pkg, f) else null
        }
        m[ENGINE_DST] = readEngineDir(pkg, ENGINE_DST)
        AppLog.i("Cek", m.entries.joinToString { "${it.key}=${it.value?.length ?: "tidak ada"}" })
        m
    } catch (e: Throwable) {
        AppLog.e("Cek", "EXCEPTION ${e.javaClass.simpleName}: ${e.message}")
        null
    }
    }

    fun delete(pkg: String, names: List<String>): String? = try {
        val d = dir(pkg)
        val cmds = names.map { "rm -f '$d/$it'" }.toMutableList()
        if (names.any { it.equals(ENGINE_SRC, ignoreCase = true) }) cmds += "rm -f '${engineDir(pkg)}/$ENGINE_DST' '${engineDir(pkg).removeSuffix("/Config")}/$ENGINE_DST'"
        val p = sh(cmds.joinToString(" ; "))
        val code = p.waitFor()
        if (code == 0) {
            AppLog.i("Hapus", "OK ${names.joinToString()}")
            null
        } else {
            val err = p.errorStream.bufferedReader().readText().trim()
            AppLog.e("Hapus", "GAGAL | exit=$code | $err")
            err.ifBlank { "Gagal menghapus (exit $code)" }
        }
    } catch (e: Throwable) {
        AppLog.e("Hapus", "EXCEPTION ${e.javaClass.simpleName}: ${e.message}")
        e.message ?: "Error"
    }

    /**
     * Pembersih di folder data game. [what]: "shader" (cache pipeline/PSO), "junk" (laporan crash).
     * Pencarian dibatasi di dalam folder data game dan tidak menyentuh folder Config.
     * @return (pesan error atau null, ringkasan hasil seperti "12 file · 3,4 MB")
     */
    fun sweep(pkg: String, what: String): Pair<String?, String> {
        return try {
        val files = "${rootFor(pkg)}/Android/data/$pkg/files"
        val saved = "$files/UE4Game/Client/Client/Saved"
        val (base, match, act) = when (what) {
            "shader" -> Triple(saved, "\\( -iname '*.upipelinecache' -o -iname '*pipelinecache*' -o -iname '*pso*' \\)", "-exec rm -f {} +")
            "junk" -> Triple(saved, "\\( -path '*/Crashes/*' -o -iname '*CrashClientReport*' \\)", "-exec rm -rf {} +")
            else -> return "Aksi tidak dikenal: $what" to ""
        }
        val f = "find '$base' -type f $match -not -path '*/Config/*'"
        val script = "n=\$($f 2>/dev/null | wc -l); k=\$($f -exec du -k {} + 2>/dev/null | awk '{s+=\$1} END{print s+0}'); $f $act 2>/dev/null; echo \"\$n \$k\""
        AppLog.i("Bersih", "Mulai $what | $base")
        val (code, out) = runStep(script)
        val last = out.lines().lastOrNull { it.matches(Regex("\\d+ \\d+")) }
        if (last == null) {
            AppLog.e("Bersih", "GAGAL $what | exit=$code | $out")
            "Gagal menjalankan pembersih. Buka Log untuk detail." to ""
        } else {
            val (n, kb) = last.split(" ").map { it.toLong() }
            val size = if (kb >= 1024) String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0) else "$kb KB"
            val sum = if (n == 0L) "tidak ada file ditemukan" else "$n file \u00B7 $size"
            AppLog.i("Bersih", "OK $what | $sum")
            null to sum
        }
    } catch (e: Throwable) {
        AppLog.e("Bersih", "EXCEPTION ${e.javaClass.simpleName}: ${e.message}")
        (e.message ?: "Error") to ""
    }
    }

    /** Mode kompilasi DEX2OAT yang ditawarkan (dipakai juga untuk memvalidasi argumen perintah). */
    val DEX_MODES = listOf("speed-profile", "speed")

    /** Jalankan satu perintah shell, kembalikan (exit code, keluaran). */
    private fun runStep(cmd: String): Pair<Int, String> = try {
        val p = sh("$cmd 2>&1")
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor() to out
    } catch (e: Throwable) { -1 to (e.message ?: "error") }

    /** Status kompilasi game saat ini (mis. "speed-profile", "verify"), atau null kalau tidak terbaca. */
    fun dexStatus(pkg: String): String? = try {
        val (_, out) = runStep("dumpsys package dexopt | grep -A6 '\\[$pkg\\]'")
        Regex("status=([a-zA-Z0-9_-]+)").find(out)?.groupValues?.get(1)
    } catch (e: Throwable) { null }

    /**
     * Kompilasi ulang game dengan dex2oat. Langkah mengikuti versi Android:
     *  - Android 14+: bersihkan profil lama, compile penuh, lalu jalankan dexopt latar.
     *  - Android 12-13: compile, lalu compile secondary dex.
     *  - Android 11: compile biasa.
     * [mode] salah satu dari [DEX_MODES], atau null untuk reset ke bawaan sistem.
     * @return null jika sukses, atau pesan error. Bisa beberapa menit; panggil dari thread IO.
     */
    fun dexopt(pkg: String, mode: String?): String? {
        if (mode != null && mode !in DEX_MODES) return "Mode DEX2OAT tidak dikenal: $mode"
        val sdk = android.os.Build.VERSION.SDK_INT
        AppLog.i("DEX2OAT", "Mulai: ${mode ?: "reset"} | $pkg | sdk=$sdk")
        fun step(label: String, cmd: String): Boolean {
            val (code, out) = runStep(cmd)
            val ok = code == 0
            if (ok) AppLog.i("DEX2OAT", "OK $label") else AppLog.w("DEX2OAT", "$label | exit=$code | ${out.lines().lastOrNull().orEmpty().take(160)}")
            return ok
        }
        if (mode == null) {
            val ok = step("reset", "cmd package compile --reset '$pkg'")
            if (sdk >= 34) { step("bersihkan profil", "cmd art clear-app-profiles '$pkg'"); step("cleanup", "cmd art cleanup '$pkg'") }
            return if (ok) null else "Reset DEX2OAT gagal. Buka Log untuk detail."
        }
        val ok: Boolean
        if (sdk >= 34) {
            step("verify awal", "cmd package compile -m verify -f '$pkg'")
            step("bersihkan profil", "cmd art clear-app-profiles '$pkg'")
            step("cleanup", "cmd art cleanup '$pkg'")
            ok = step("compile $mode", "cmd package compile -m $mode --full -f '$pkg'")
            if (ok) step("dexopt latar", "cmd art dexopt-packages -r bg-dexopt '$pkg'")
        } else {
            step("verify awal", "cmd package compile -m verify -f '$pkg'")
            ok = step("compile $mode", "cmd package compile -m $mode -f '$pkg'")
            if (ok && sdk >= 31) step("secondary dex", "cmd package compile -m $mode --secondary-dex '$pkg'")
        }
        if (!ok) return "Kompilasi $mode gagal. Buka Log untuk detail."
        AppLog.i("DEX2OAT", "Selesai | status sekarang: ${dexStatus(pkg) ?: "tidak terbaca"}")
        return null
    }

    /** Jalankan satu perintah diagnosa, kembalikan keluaran (stdout+stderr) yang sudah dirapikan. */
    private fun probe(cmd: String): String = try {
        val p = sh("$cmd 2>&1")
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        out.ifBlank { "(kosong)" }
    } catch (e: Throwable) { "(error: ${e.javaClass.simpleName}: ${e.message})" }

    /**
     * Dipanggil saat pemasangan gagal: kumpulkan fakta yang biasanya jadi penyebab dan tulis ke log.
     * Cek: identitas proses, folder Android/data game, folder Config, izin file yang gagal, SELinux, sisa ruang.
     */
    fun diagnose(pkg: String, failedFile: String? = null) {
        try {
            val d = dir(pkg)
            val base = "/storage/emulated/0/Android/data/$pkg"
            val sb = StringBuilder("Diagnosa otomatis (akses: ${modeName()})\n")
            sb.append("id            : ").append(probe("id")).append('\n')
            sb.append("SELinux       : ").append(probe("getenforce")).append('\n')
            sb.append("folder game   : ").append(probe("ls -ld '$base'")).append('\n')
            sb.append("jalur dipakai : ").append(rootFor(pkg)).append('\n')
            for (r in ROOTS) sb.append("  jalur $r : ")
                .append(probe("ls -ld '$r/Android/data/$pkg' ; ls '$r/Android/data/$pkg' | head -3").lines().joinToString(" | ")).append('\n')
            sb.append("folder config : ").append(probe("ls -ld '$d'")).append('\n')
            if (failedFile != null)
                sb.append("file gagal    : ").append(probe("ls -l '$d/$failedFile'")).append('\n')
            sb.append("isi config    : ").append(probe("ls -l '$d'").lines().take(12).joinToString(" | ")).append('\n')
            sb.append("ruang kosong  : ").append(probe("df /storage/emulated/0 | tail -1")).append('\n')
            sb.append("Petunjuk      : ").append(hint(pkg, failedFile))
            AppLog.w("Diagnosa", sb.toString())
        } catch (e: Throwable) {
            AppLog.e("Diagnosa", "Diagnosa gagal dijalankan: ${e.message}")
        }
    }

    /** Tebakan penyebab paling umum berdasarkan hasil cek folder. */
    private fun hint(pkg: String, failedFile: String?): String {
        val d = dir(pkg)
        val base = "/storage/emulated/0/Android/data/$pkg"
        val gameDir = probe("ls -ld '$base'")
        val cfgDir = probe("ls -ld '$d'")
        val file = if (failedFile != null) probe("ls -l '$d/$failedFile'") else ""
        return when {
            gameDir.contains("No such file") ->
                "Folder data game belum ada. Buka game sampai masuk menu utama sekali, tutup, lalu coba pasang lagi."
            cfgDir.contains("No such file") ->
                "Folder Config belum dibuat game. Buka game sampai selesai download resource, lalu coba lagi."
            gameDir.contains("Permission denied") || cfgDir.contains("Permission denied") ->
                "Akses ditolak untuk uid shell di folder data game. Kalau Shizuku/Wireless ADB sudah terhubung (uid=2000) tapi tetap ditolak di semua jalur, ROM (Android 14+/HyperOS) memblokirnya; satu-satunya jalan lewat HP ini adalah Root. Kalau belum terhubung, nyalakan ulang Wireless Debugging dan sambungkan lagi."
            file.contains("Permission denied") || file.contains("Operation not permitted") ->
                "File sudah ada tapi dikunci/dimiliki game. Coba 'Hapus config' di Settings, lalu pasang ulang."
            probe("df /storage/emulated/0 | tail -1").let { it.contains(" 100%") } ->
                "Penyimpanan penuh. Kosongkan ruang lalu coba lagi."
            else ->
                "Tidak ada penyebab pasti dari cek otomatis. Kemungkinan: Shizuku tidak aktif (mati setelah HP restart / Wi-Fi putus), atau ROM membatasi akses Android/data. Nyalakan ulang Shizuku lalu coba lagi."
        }
    }
}
