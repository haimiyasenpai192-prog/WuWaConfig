package id.wuwaconfig

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import rikka.shizuku.Shizuku
import android.content.pm.PackageManager

/** Akses file game lewat Shizuku (shell uid) — bisa menulis ke Android/data tanpa root. */
object ShizukuShell {
    const val REQ = 4711
    /** 0 = Shizuku tidak berjalan, 1 = belum diizinkan, 2 = terhubung */
    val status = mutableStateOf(0)

    private val PACKAGES = listOf(
        "com.kurogame.wutheringwaves.global", "com.kurogame.wutheringwaves.bilibili",
        "com.kurogame.wutheringwaves.kuro", "com.kurogame.wutheringwaves.tw",
        "com.kurogame.wutheringwaves.jp", "com.kurogame.wutheringwaves.kr",
        "com.kurogame.wutheringwaves"
    )

    fun refresh() {
        status.value = try {
            when {
                !Shizuku.pingBinder() -> 0
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
                else -> 1
            }
        } catch (e: Throwable) { 0 }
    }

    fun requestPermission() {
        try { if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun installedPackage(ctx: Context): String? = PACKAGES.firstOrNull {
        try { ctx.packageManager.getPackageInfo(it, 0); true } catch (_: Exception) { false }
    }

    private fun dir(pkg: String) =
        "/storage/emulated/0/Android/data/$pkg/files/UE4Game/Client/Client/Saved/Config/Android"

    // Shizuku 13 menyembunyikan newProcess(); dipanggil lewat reflection (cara umum dipakai).
    private fun sh(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    /** @return null jika sukses, atau pesan error */
    fun write(pkg: String, name: String, text: String): String? = try {
        val d = dir(pkg)
        val p = sh("mkdir -p '$d' && cat > '$d/$name'")
        p.outputStream.use { it.write(text.toByteArray()) }
        if (p.waitFor() == 0) null else p.errorStream.bufferedReader().readText().ifBlank { "Gagal menulis $name" }
    } catch (e: Throwable) { e.message ?: "Error" }

    fun delete(pkg: String, names: List<String>): String? = try {
        val d = dir(pkg)
        val p = sh(names.joinToString(" ; ") { "rm -f '$d/$it'" })
        if (p.waitFor() == 0) null else p.errorStream.bufferedReader().readText()
    } catch (e: Throwable) { e.message ?: "Error" }
}
