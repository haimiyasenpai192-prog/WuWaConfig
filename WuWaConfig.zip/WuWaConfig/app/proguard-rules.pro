# Shizuku.newProcess() dipanggil lewat reflection di ShizukuShell.kt, jadi harus dijaga dari R8.
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**

# libadb-android + Conscrypt + BouncyCastle (Wireless Debugging)
-keep class io.github.muntashirakon.adb.** { *; }
-keep class org.conscrypt.** { *; }
-keep class org.bouncycastle.** { *; }
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn javax.naming.**
