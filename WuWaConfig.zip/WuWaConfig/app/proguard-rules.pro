# Shizuku.newProcess() dipanggil lewat reflection di ShizukuShell.kt, jadi harus dijaga dari R8.
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**
