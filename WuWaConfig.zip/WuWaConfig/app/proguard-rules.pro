# Tidak ada aturan khusus; R8 default sudah cukup.
