# Layanan Shizuku dibuat lewat refleksi, jangan diubah/dihapus.
-keep class com.wuwaconfig.app.UserService { *; }
-keep class com.wuwaconfig.app.IUserService { *; }
-keep class com.wuwaconfig.app.IUserService$* { *; }
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**
