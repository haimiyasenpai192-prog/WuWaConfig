Taruh zip config di folder ini (satu zip = satu versi, contoh: v1.1-beta.zip).
Saat build di GitHub, semua zip di sini otomatis dimasukkan ke dalam APK
(app/src/main/assets/presets/) dan muncul di daftar "Pilih config" tanpa impor.
